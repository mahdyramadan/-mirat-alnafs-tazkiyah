(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.TazkiyahCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const SCHEMA_VERSION = 4;

  function nowIso(now) {
    return now instanceof Date ? now.toISOString() : (typeof now === 'string' ? now : new Date().toISOString());
  }

  function emptyState(now) {
    const stamp = nowIso(now);
    return {
      schemaVersion: SCHEMA_VERSION,
      createdAt: stamp,
      updatedAt: stamp,
      settings: { appName: 'تزكية', locale: 'ar', direction: 'rtl' },
      traits: [],
      activeTraitId: null,
      situations: [],
      rules: [],
      ruleTests: [],
      weeklyReviews: []
    };
  }

  function migrateState(candidate) {
    if (!candidate || typeof candidate !== 'object') return null;
    let next = candidate;
    if (next.schemaVersion === 1 && Array.isArray(next.traits)) {
      next = { ...next, schemaVersion: 2, situations: [] };
    }
    if (next.schemaVersion === 2 && Array.isArray(next.traits) && Array.isArray(next.situations)) {
      next = { ...next, schemaVersion: 3, rules: [], ruleTests: [] };
    }
    if (next.schemaVersion === 3 && Array.isArray(next.rules) && Array.isArray(next.ruleTests)) {
      next = { ...next, schemaVersion: SCHEMA_VERSION, weeklyReviews: [] };
    }
    return next;
  }

  function isValidState(candidate) {
    return Boolean(
      candidate && candidate.schemaVersion === SCHEMA_VERSION &&
      Array.isArray(candidate.traits) && Array.isArray(candidate.situations) &&
      Array.isArray(candidate.rules) && Array.isArray(candidate.ruleTests) &&
      Array.isArray(candidate.weeklyReviews) &&
      Object.prototype.hasOwnProperty.call(candidate, 'activeTraitId')
    );
  }

  function createSituation(overrides = {}, id = `situation-${Date.now()}`, now) {
    const stamp = nowIso(now);
    return {
      id, createdAt: stamp, updatedAt: stamp, reviewedAt: null,
      whatHappened: '', trigger: '', feelings: '', interpretation: '', deeperReflection: '',
      urge: '', action: '', consequence: '', betterResponse: '', prevention: '', linkedTraits: [],
      reviewStatus: 'pending', responseStage: null, ruleCandidate: '', ruleTestDraft: null,
      ...overrides
    };
  }

  function addSituation(state, situation) {
    if (!isValidState(state)) throw new Error('Invalid state');
    if (!situation || !situation.id) throw new Error('Invalid situation');
    if (state.situations.some((item) => item.id === situation.id)) throw new Error('Duplicate situation id');
    state.situations.push(situation);
    return situation;
  }

  function completeSituation(state, id, overrides = {}, now) {
    if (!isValidState(state)) throw new Error('Invalid state');
    const item = state.situations.find((s) => s.id === id);
    if (!item) return null;
    const stamp = nowIso(now);
    Object.assign(item, overrides, { reviewStatus: 'reviewed', reviewedAt: stamp, updatedAt: stamp });
    return item;
  }

  function setFocusTrait(state, id, now) {
    if (!isValidState(state)) throw new Error('Invalid state');
    const target = state.traits.find((trait) => trait.id === id);
    if (!target) return null;
    const stamp = nowIso(now);
    state.traits.forEach((trait) => {
      if (trait.id === id) return;
      if (trait.status === 'focus') { trait.status = 'reinforcement'; trait.updatedAt = stamp; }
    });
    target.status = 'focus'; target.updatedAt = stamp; state.activeTraitId = id;
    return target;
  }

  function setTraitStatus(state, id, status, now) {
    if (!['focus', 'reinforcement', 'watch'].includes(status)) throw new Error('Invalid trait status');
    if (status === 'focus') return setFocusTrait(state, id, now);
    const target = state.traits.find((trait) => trait.id === id);
    if (!target) return null;
    if (state.activeTraitId === id) throw new Error('Active focus cannot be demoted without selecting another focus');
    target.status = status; target.updatedAt = nowIso(now);
    return target;
  }

  function createRule(overrides = {}, id = `rule-${Date.now()}`, now) {
    const stamp = nowIso(now);
    return { id, text:'', reason:'', linkedTraitId:null, sourceSituationIds:[], active:true, createdAt:stamp, updatedAt:stamp, ...overrides };
  }

  function addRule(state, rule) {
    if (!isValidState(state)) throw new Error('Invalid state');
    if (!rule || !rule.id || !String(rule.text || '').trim()) throw new Error('Invalid rule');
    if (state.rules.some((item) => item.id === rule.id)) throw new Error('Duplicate rule id');
    state.rules.push(rule); return rule;
  }

  function createRuleTest(overrides = {}, id = `rule-test-${Date.now()}`, now) {
    const stamp = nowIso(now);
    return { id, ruleId:'', situationId:'', result:'', note:'', createdAt:stamp, updatedAt:stamp, ...overrides };
  }

  function upsertRuleTest(state, test, now) {
    if (!isValidState(state)) throw new Error('Invalid state');
    if (!test || !test.ruleId || !test.situationId || !['success','partial','failed'].includes(test.result)) throw new Error('Invalid rule test');
    const existing = state.ruleTests.find((item) => item.ruleId === test.ruleId && item.situationId === test.situationId);
    const stamp = nowIso(now);
    if (existing) {
      Object.assign(existing, test, { id: existing.id, createdAt: existing.createdAt, updatedAt: stamp });
      return existing;
    }
    const next = { ...test, updatedAt: stamp };
    state.ruleTests.push(next); return next;
  }

  function createWeeklyReview(overrides = {}, id = `week-${Date.now()}`, now) {
    const stamp = nowIso(now);
    return {
      id, weekStart:'', recurringPattern:'', improvements:'', struggles:'', preventionReality:'', mindsetShift:'', nextAdjustment:'', notes:'',
      createdAt: stamp, updatedAt: stamp, ...overrides
    };
  }

  function upsertWeeklyReview(state, review, now) {
    if (!isValidState(state)) throw new Error('Invalid state');
    if (!review || !review.weekStart) throw new Error('Invalid weekly review');
    const existing = state.weeklyReviews.find((item) => item.weekStart === review.weekStart);
    const stamp = nowIso(now);
    if (existing) {
      Object.assign(existing, review, { id: existing.id, createdAt: existing.createdAt, updatedAt: stamp });
      return existing;
    }
    const next = { ...review, updatedAt: stamp };
    state.weeklyReviews.push(next); return next;
  }

  function splitTerms(value) {
    return String(value || '').split(/[،,]/).map((v) => v.trim()).filter(Boolean);
  }

  function normalizeKey(value) {
    return String(value || '').trim().replace(/\s+/g, ' ').toLocaleLowerCase('ar');
  }

  function countValues(values) {
    const map = new Map();
    values.forEach((raw) => {
      const value = String(raw || '').trim();
      if (!value) return;
      const key = normalizeKey(value);
      if (!map.has(key)) map.set(key, { label:value, count:0 });
      map.get(key).count += 1;
    });
    return [...map.values()].sort((a,b) => b.count - a.count || a.label.localeCompare(b.label, 'ar'));
  }

  function summarizeSituations(situations) {
    const reviewed = situations.filter((s) => s.reviewStatus === 'reviewed');
    const pending = situations.filter((s) => s.reviewStatus !== 'reviewed');
    const responseStages = {};
    reviewed.forEach((s) => { if (s.responseStage) responseStages[s.responseStage] = (responseStages[s.responseStage] || 0) + 1; });
    return {
      total: situations.length,
      reviewed: reviewed.length,
      pending: pending.length,
      traits: countValues(situations.flatMap((s) => s.linkedTraits || [])),
      feelings: countValues(situations.flatMap((s) => splitTerms(s.feelings))),
      triggers: countValues(reviewed.map((s) => s.trigger)),
      interpretations: countValues(reviewed.map((s) => s.interpretation)),
      actions: countValues(reviewed.map((s) => s.action)),
      responseStages
    };
  }

  function ruleSummary(state, ruleId) {
    if (!isValidState(state)) throw new Error('Invalid state');
    const tests = state.ruleTests.filter((test) => test.ruleId === ruleId);
    const counts = { success:0, partial:0, failed:0 };
    tests.forEach((test) => { if (counts[test.result] !== undefined) counts[test.result] += 1; });
    return { total:tests.length, ...counts, latest:tests.slice().sort((a,b) => new Date(b.updatedAt) - new Date(a.updatedAt))[0] || null };
  }


  function makeBackup(state, now) {
    if (!isValidState(state)) throw new Error('Invalid state');
    return {
      format: 'mirat-alnafs-backup',
      backupVersion: 1,
      exportedAt: nowIso(now),
      data: JSON.parse(JSON.stringify(state))
    };
  }

  function readBackup(payload) {
    let parsed = payload;
    if (typeof payload === 'string') parsed = JSON.parse(payload);
    if (!parsed || typeof parsed !== 'object') throw new Error('Invalid backup');
    const candidate = parsed.format === 'mirat-alnafs-backup' ? parsed.data : parsed;
    const cloned = JSON.parse(JSON.stringify(candidate));
    const migrated = migrateState(cloned);
    if (!isValidState(migrated)) throw new Error('Unsupported or invalid backup');
    return migrated;
  }

  return {
    SCHEMA_VERSION, emptyState, migrateState, isValidState,
    createSituation, addSituation, completeSituation,
    setFocusTrait, setTraitStatus,
    createRule, addRule, createRuleTest, upsertRuleTest,
    createWeeklyReview, upsertWeeklyReview,
    splitTerms, countValues, summarizeSituations, ruleSummary,
    makeBackup, readBackup
  };
});
