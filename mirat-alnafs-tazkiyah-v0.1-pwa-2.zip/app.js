(() => {
  'use strict';

  const STORAGE_KEY = 'mirat-alnafs:v0.1';
  const Core = globalThis.TazkiyahCore;
  const Content = globalThis.TazkiyahContent;
  if (!Core) throw new Error('TazkiyahCore is required');
  if (!Content) throw new Error('TazkiyahContent is required');
  const SCHEMA_VERSION = Core.SCHEMA_VERSION;
  const RECOVERY_KEY = `${STORAGE_KEY}:recovery`;
  let storageHealthy = true;
  let loadWarning = '';
  let quickTags = new Set();
  let reviewTags = new Set();
  let currentReviewId = null;
  let reviewStep = 1;
  let autosaveTimer = null;
  let focusMode = 'edit';
  let currentRuleId = null;
  let currentView = 'home';
  let currentReminderKey = '';
  let reminderCursor = 0;

  const emptyState = Core.emptyState;
  // يجب تعريفهما قبل loadState(): كانا بعدها فيتعطل التطبيق عند فتحه مع بيانات محفوظة.
  const migrateState = Core.migrateState;
  const isValidState = Core.isValidState;

  const $ = (id) => document.getElementById(id);
  let state = loadState();

  const els = {
    negativeTrait: $('negativeTrait'), positiveTrait: $('positiveTrait'), oldMindset: $('oldMindset'),
    newMindset: $('newMindset'), dailyRuleTitle: $('dailyRuleTitle'), alternativeBehavior: $('alternativeBehavior'),
    preventionMethod: $('preventionMethod'), harmsText: $('harmsText'), statusPill: $('statusPill'), saveState: $('saveState'),
    focusModal: $('focusModal'), focusForm: $('focusForm'), editFocusBtn: $('editFocusBtn'), startFocusBtn: $('startFocusBtn'), closeModalBtn: $('closeModalBtn'),
    cancelBtn: $('cancelBtn'), whyToggle: $('whyToggle'), whyPanel: $('whyPanel'), toast: $('toast'), situationBtn: $('situationBtn'),
    pendingList: $('pendingList'), recentList: $('recentList'), pendingCount: $('pendingCount'),
    manageTraitsBtn: $('manageTraitsBtn'), traitPathSummary: $('traitPathSummary'), traitManagerModal: $('traitManagerModal'),
    closeTraitManagerBtn: $('closeTraitManagerBtn'), traitManagerList: $('traitManagerList'), newFocusBtn: $('newFocusBtn'),
    addRuleBtn: $('addRuleBtn'), rulesList: $('rulesList'), ruleModal: $('ruleModal'), closeRuleBtn: $('closeRuleBtn'), cancelRuleBtn: $('cancelRuleBtn'),
    ruleForm: $('ruleForm'), ruleTextInput: $('ruleTextInput'), ruleReasonInput: $('ruleReasonInput'), ruleTraitSelect: $('ruleTraitSelect'),
    focusModalKicker: $('focusModalKicker'), focusModalTitle: $('focusModalTitle'),
    todaySummaryCards: $('todaySummaryCards'), todaySituations: $('todaySituations'), patternPeriod: $('patternPeriod'),
    patternTraits: $('patternTraits'), patternFeelings: $('patternFeelings'), patternTriggers: $('patternTriggers'),
    patternInterpretations: $('patternInterpretations'), patternActions: $('patternActions'), responseStageSummary: $('responseStageSummary'),
    rulesMirrorList: $('rulesMirrorList'), weeklyReviewForm: $('weeklyReviewForm'), weekRangeLabel: $('weekRangeLabel'),
    weekComputedSummary: $('weekComputedSummary'), weekRecurring: $('weekRecurring'), weekImprovements: $('weekImprovements'),
    weekStruggles: $('weekStruggles'), weekPrevention: $('weekPrevention'), weekMindset: $('weekMindset'),
    weekAdjustment: $('weekAdjustment'), weekNotes: $('weekNotes'),
    sessionReminderText: $('sessionReminderText'), sessionReminderSource: $('sessionReminderSource'), newReminderBtn: $('newReminderBtn'),
    morningAdhkarBtn: $('morningAdhkarBtn'), eveningAdhkarBtn: $('eveningAdhkarBtn'), adhkarModal: $('adhkarModal'),
    closeAdhkarBtn: $('closeAdhkarBtn'), adhkarModalTitle: $('adhkarModalTitle'), adhkarList: $('adhkarList'),
    exportBackupBtn: $('exportBackupBtn'), importBackupBtn: $('importBackupBtn'), backupFileInput: $('backupFileInput'), backupStatus: $('backupStatus'),
    inputs: {
      negativeTrait: $('negativeInput'), positiveTrait: $('positiveInput'), oldMindset: $('oldMindsetInput'),
      newMindset: $('newMindsetInput'), rule: $('ruleInput'), alternativeBehavior: $('alternativeInput'),
      preventionMethod: $('preventionInput'), harms: $('harmsInput')
    },
    quickModal: $('quickModal'), quickForm: $('quickForm'), closeQuickBtn: $('closeQuickBtn'), cancelQuickBtn: $('cancelQuickBtn'),
    quickWhatHappened: $('quickWhatHappened'), quickFeelings: $('quickFeelings'), quickUrge: $('quickUrge'), quickAction: $('quickAction'),
    quickTraitChips: $('quickTraitChips'), quickTraitInput: $('quickTraitInput'), quickTraitAdd: $('quickTraitAdd'),
    reviewModal: $('reviewModal'), reviewForm: $('reviewForm'), closeReviewBtn: $('closeReviewBtn'), reviewAutosave: $('reviewAutosave'),
    reviewPrevBtn: $('reviewPrevBtn'), reviewNextBtn: $('reviewNextBtn'), reviewFinishBtn: $('reviewFinishBtn'),
    reviewWhatHappened: $('reviewWhatHappened'), reviewTrigger: $('reviewTrigger'), reviewFeelings: $('reviewFeelings'),
    reviewInterpretation: $('reviewInterpretation'), reviewDeeperReflection: $('reviewDeeperReflection'), reviewUrge: $('reviewUrge'),
    reviewAction: $('reviewAction'), reviewConsequence: $('reviewConsequence'), reviewBetterResponse: $('reviewBetterResponse'),
    reviewPrevention: $('reviewPrevention'), reviewTraitChips: $('reviewTraitChips'), reviewTraitInput: $('reviewTraitInput'),
    reviewTraitAdd: $('reviewTraitAdd'), reviewNewRule: $('reviewNewRule'), reviewRuleSelect: $('reviewRuleSelect'),
    ruleTestResultWrap: $('ruleTestResultWrap'), ruleTestNoteWrap: $('ruleTestNoteWrap'), reviewRuleTestNote: $('reviewRuleTestNote')
  };

  const statusLabels = { focus: 'تحت التركيز', reinforcement: 'تثبيت', watch: 'مراقبة' };
  const responseLabels = {
    old: 'عدت للنمط القديم', late: 'انتبهت بعد الموقف', during: 'انتبهت أثناءه',
    stopped: 'أوقفت الاستجابة القديمة', alternative: 'طبقت البديل الجديد'
  };
  const ruleTestLabels = { success: 'نجحت', partial: 'نجحت جزئيًا', failed: 'لم تنجح' };

  function safeParse(raw) { try { return JSON.parse(raw); } catch { return null; } }


  function storageGet(key) { try { return localStorage.getItem(key); } catch { storageHealthy = false; return null; } }
  function storageSet(key, value) { try { localStorage.setItem(key, value); storageHealthy = true; return true; } catch { storageHealthy = false; return false; } }
  function storageRemove(key) { try { localStorage.removeItem(key); return true; } catch { storageHealthy = false; return false; } }

  function loadState() {
    const raw = storageGet(STORAGE_KEY);
    if (!raw) return emptyState();
    const migrated = migrateState(safeParse(raw));
    if (!isValidState(migrated)) {
      storageSet(RECOVERY_KEY, raw);
      loadWarning = 'وجدت بيانات غير متوافقة؛ احتفظت بنسخة استرداد ولم أحذفها.';
      return emptyState();
    }
    if (migrated.schemaVersion !== safeParse(raw)?.schemaVersion) storageSet(STORAGE_KEY, JSON.stringify(migrated));
    return migrated;
  }

  function persistState({ quiet = false } = {}) {
    state.updatedAt = new Date().toISOString();
    const saved = storageSet(STORAGE_KEY, JSON.stringify(state));
    els.saveState.textContent = saved ? 'تم الحفظ على هذا الجهاز' : 'تعذر الحفظ — لا تغلق التطبيق قبل حل المشكلة';
    if (!saved && !quiet) showToast('تعذر حفظ البيانات على هذا الجهاز');
    return saved;
  }

  function makeId(prefix = 'item') {
    if (globalThis.crypto?.randomUUID) return crypto.randomUUID();
    return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  function activeTrait() { return state.traits.find((trait) => trait.id === state.activeTraitId) || null; }
  function situationById(id) { return state.situations.find((item) => item.id === id) || null; }
  function setText(element, value, fallback = '—') { element.textContent = String(value || '').trim() || fallback; }
  function escapeHtml(value = '') { return String(value).replace(/[&<>'"]/g, (char) => ({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' }[char])); }
  function truncate(value, max = 120) { const text = String(value || '').trim(); return text.length > max ? `${text.slice(0, max - 1)}…` : text; }
  function formatDate(iso) {
    try { return new Intl.DateTimeFormat('ar', { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' }).format(new Date(iso)); }
    catch { return ''; }
  }

  function render() {
    renderOpeningReminder();
    renderFocus();
    renderTraitPath();
    renderRules();
    renderSituations();
    renderMirrors();
    applyView();
  }

  function reminderCandidates() {
    const trait = activeTrait();
    const candidates = [];
    if (trait?.rule) candidates.push({ text: trait.rule, source: 'قاعدتك الحالية', url: '' });
    if (trait?.newMindset) candidates.push({ text: trait.newMindset, source: 'العقلية التي تبنيها', url: '' });
    state.rules.filter((rule) => rule.active !== false).forEach((rule) => candidates.push({ text: rule.text, source: 'من قواعدك العملية', url: '' }));
    if (trait?.negativeTrait) {
      Content.references.filter((ref) => (ref.tags || []).includes(trait.negativeTrait)).forEach((ref) => candidates.push({ text: ref.text, source: ref.source, url: ref.url }));
    }
    if (!candidates.length) {
      candidates.push({ text: 'ابدأ بالملاحظة الصادقة، ثم افهم قبل أن تحكم على الموقف.', source: 'منهج التطبيق', url: '' });
    }
    return candidates;
  }

  function renderOpeningReminder(forceNext = false) {
    const traitId = activeTrait()?.id || 'none';
    const candidates = reminderCandidates();
    if (currentReminderKey !== traitId) { currentReminderKey = traitId; reminderCursor = Math.floor(Math.random() * candidates.length); }
    else if (forceNext) reminderCursor = (reminderCursor + 1) % candidates.length;
    const item = candidates[reminderCursor % candidates.length];
    setText(els.sessionReminderText, item.text);
    if (item.url) {
      els.sessionReminderSource.textContent = item.source;
      els.sessionReminderSource.href = item.url;
      els.sessionReminderSource.hidden = false;
    } else {
      els.sessionReminderSource.hidden = true;
      els.sessionReminderSource.removeAttribute('href');
    }
  }

  function openAdhkar(kind) {
    const items = Content.adhkar[kind] || [];
    els.adhkarModalTitle.textContent = kind === 'evening' ? 'أذكار المساء' : 'أذكار الصباح';
    els.adhkarList.innerHTML = items.map((item) => `<article class="dhikr-item"><div class="dhikr-head"><span>${item.repeat > 1 ? `${item.repeat} مرات` : 'مرة واحدة'}</span><a href="${escapeHtml(item.url)}" target="_blank" rel="noopener">${escapeHtml(item.source)} · ${escapeHtml(item.grade)}</a></div><p>${escapeHtml(item.text)}</p></article>`).join('');
    els.adhkarModal.hidden = false;
    lockBody();
  }

  function closeAdhkar() { els.adhkarModal.hidden = true; unlockBody(); }

  function exportBackup() {
    try {
      const backup = Core.makeBackup(state);
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type:'application/json' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `mirat-alnafs-backup-${localDateKey(new Date())}.json`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
      els.backupStatus.textContent = `تم تصدير نسخة: ${new Intl.DateTimeFormat('ar',{dateStyle:'medium',timeStyle:'short'}).format(new Date())}`;
      showToast('تم إنشاء النسخة الاحتياطية.');
    } catch (error) {
      showToast('تعذر إنشاء النسخة الاحتياطية.');
    }
  }

  async function importBackupFile(file) {
    if (!file) return;
    try {
      const text = await file.text();
      const imported = Core.readBackup(text);
      const okay = confirm('سيتم استبدال بيانات التطبيق الحالية بالنسخة المختارة. احتُفظ بنسخة استرداد من بياناتك الحالية. هل تريد المتابعة؟');
      if (!okay) { els.backupFileInput.value = ''; return; }
      storageSet(`${RECOVERY_KEY}:before-import:${Date.now()}`, JSON.stringify(state));
      state = imported;
      if (!persistState()) return;
      currentReminderKey = '';
      render();
      els.backupStatus.textContent = `تمت الاستعادة: ${new Intl.DateTimeFormat('ar',{dateStyle:'medium',timeStyle:'short'}).format(new Date())}`;
      showToast('تمت استعادة النسخة بنجاح.');
    } catch (error) {
      showToast('ملف النسخة غير صالح أو غير مدعوم.');
    } finally {
      els.backupFileInput.value = '';
    }
  }

  function renderFocus() {
    const trait = activeTrait();
    if (!trait) {
      ['negativeTrait','positiveTrait','oldMindset','newMindset','dailyRuleTitle','alternativeBehavior','preventionMethod','harmsText']
        .forEach((key) => setText(els[key], '—'));
      els.statusPill.textContent = 'ابدأ رحلتك';
      if (els.startFocusBtn) els.startFocusBtn.hidden = false;
      return;
    }
    if (els.startFocusBtn) els.startFocusBtn.hidden = true;
    setText(els.negativeTrait, trait.negativeTrait);
    setText(els.positiveTrait, trait.positiveTrait);
    setText(els.oldMindset, trait.oldMindset);
    setText(els.newMindset, trait.newMindset);
    setText(els.dailyRuleTitle, trait.rule);
    setText(els.alternativeBehavior, trait.alternativeBehavior);
    setText(els.preventionMethod, trait.preventionMethod);
    setText(els.harmsText, trait.harms);
    els.statusPill.textContent = statusLabels[trait.status] || 'تحت التركيز';
  }

  function traitDisplay(trait) {
    return `${trait.negativeTrait || '—'} ← ${trait.positiveTrait || '—'}`;
  }

  function renderTraitPath() {
    const groups = {
      focus: state.traits.filter((t) => t.status === 'focus'),
      reinforcement: state.traits.filter((t) => t.status === 'reinforcement'),
      watch: state.traits.filter((t) => t.status === 'watch')
    };
    const block = (label, key) => {
      const items = groups[key];
      const body = items.length ? items.map((t) => `<span class="path-trait">${escapeHtml(traitDisplay(t))}</span>`).join('') : '<span class="path-empty">لا يوجد</span>';
      return `<div class="path-column ${key}"><small>${label}</small><div>${body}</div></div>`;
    };
    els.traitPathSummary.innerHTML = block('التركيز', 'focus') + block('التثبيت', 'reinforcement') + block('المراقبة', 'watch');

    els.traitManagerList.innerHTML = state.traits.length ? state.traits.map((trait) => {
      let actions = '';
      if (trait.status === 'focus') actions = '<span class="manager-current">التركيز الحالي</span>';
      if (trait.status === 'reinforcement') actions = `<button class="small-btn" data-trait-action="focus" data-trait-id="${escapeHtml(trait.id)}">اجعله التركيز</button><button class="small-btn" data-trait-action="watch" data-trait-id="${escapeHtml(trait.id)}">إلى المراقبة</button>`;
      if (trait.status === 'watch') actions = `<button class="small-btn" data-trait-action="focus" data-trait-id="${escapeHtml(trait.id)}">اجعله التركيز</button><button class="small-btn" data-trait-action="reinforcement" data-trait-id="${escapeHtml(trait.id)}">إلى التثبيت</button>`;
      return `<article class="manager-item"><div><strong>${escapeHtml(traitDisplay(trait))}</strong><span>${escapeHtml(statusLabels[trait.status] || trait.status)}</span></div><div class="manager-actions">${actions}</div></article>`;
    }).join('') : emptyCard('لا توجد صفات بعد.', 'ابدأ بصفة واحدة تحت التركيز.');
  }

  function renderRules() {
    const rules = state.rules.filter((rule) => rule.active !== false).sort((a,b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    if (!rules.length) {
      els.rulesList.innerHTML = emptyCard('لا توجد قواعد عملية بعد.', 'استخرج قاعدة من موقف حقيقي أو أضف قاعدة تريد اختبارها.');
      return;
    }
    els.rulesList.innerHTML = rules.map((rule) => {
      const tests = state.ruleTests.filter((test) => test.ruleId === rule.id);
      const counts = { success:0, partial:0, failed:0 };
      tests.forEach((test) => { if (counts[test.result] !== undefined) counts[test.result] += 1; });
      const trait = state.traits.find((item) => item.id === rule.linkedTraitId);
      const summary = tests.length
        ? `<div class="rule-stats"><span>جُرّبت ${tests.length}</span><span>نجحت ${counts.success}</span><span>جزئيًا ${counts.partial}</span><span>لم تنجح ${counts.failed}</span></div>`
        : '<div class="rule-stats"><span>لم تُختبر بعد</span></div>';
      return `<article class="rule-item"><div class="rule-item-head"><div><strong>${escapeHtml(rule.text)}</strong>${trait ? `<small>${escapeHtml(traitDisplay(trait))}</small>` : ''}</div><button class="small-btn" data-rule-edit="${escapeHtml(rule.id)}">تعديل</button></div>${rule.reason ? `<p>${escapeHtml(rule.reason)}</p>` : ''}${summary}</article>`;
    }).join('');
  }

  function localDateKey(date) {
    const d = date instanceof Date ? date : new Date(date);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  function startOfCurrentWeek(now = new Date()) {
    const d = new Date(now);
    d.setHours(0,0,0,0);
    d.setDate(d.getDate() - d.getDay());
    return d;
  }

  function weekSituations(now = new Date()) {
    const start = startOfCurrentWeek(now);
    const end = new Date(start); end.setDate(end.getDate() + 7);
    return state.situations.filter((s) => {
      const d = new Date(s.createdAt);
      return d >= start && d < end;
    });
  }

  function periodSituations() {
    const value = els.patternPeriod?.value || '30';
    if (value === 'all') return state.situations.slice();
    const days = Number(value) || 30;
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);
    return state.situations.filter((s) => new Date(s.createdAt) >= cutoff);
  }

  function countRows(items, { repeatOnly = false, limit = 5 } = {}) {
    const shown = items.filter((item) => !repeatOnly || item.count > 1).slice(0, limit);
    if (!shown.length) return '<span class="mirror-empty">لا يوجد تكرار مؤكد كافٍ.</span>';
    return shown.map((item) => `<div class="count-row"><span>${escapeHtml(item.label)}</span><strong>${item.count}</strong></div>`).join('');
  }

  function renderTodayMirror() {
    const today = localDateKey(new Date());
    const situations = state.situations.filter((s) => localDateKey(new Date(s.createdAt)) === today).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
    const stats = Core.summarizeSituations(situations);
    const better = (stats.responseStages.stopped || 0) + (stats.responseStages.alternative || 0);
    const needsAttention = (stats.responseStages.old || 0) + (stats.responseStages.late || 0);
    els.todaySummaryCards.innerHTML = [
      ['المواقف المسجلة', stats.total], ['راجعتها', stats.reviewed], ['تنتظر المراجعة', stats.pending],
      ['ظهرت استجابة أفضل', better], ['عاد النمط القديم/تأخر الانتباه', needsAttention]
    ].map(([label,value]) => `<div class="mirror-stat"><strong>${value}</strong><span>${label}</span></div>`).join('');
    els.todaySituations.innerHTML = situations.length ? situations.map((s) => {
      const stage = s.responseStage ? responseLabels[s.responseStage] : (s.reviewStatus === 'reviewed' ? 'مراجَع' : 'ينتظر المراجعة');
      return `<div class="mirror-event"><div><strong>${escapeHtml(truncate(s.whatHappened, 120))}</strong><span>${escapeHtml(stage)}</span></div><small>${(s.linkedTraits || []).map(escapeHtml).join(' · ') || 'بدون تصنيف'}</small></div>`;
    }).join('') : emptyCard('لا توجد مواقف مسجلة اليوم.', 'المرآة لا تخترع شيئًا عندما لا توجد بيانات.');
  }

  function renderPatternMirror() {
    const stats = Core.summarizeSituations(periodSituations());
    els.patternTraits.innerHTML = countRows(stats.traits);
    els.patternFeelings.innerHTML = countRows(stats.feelings);
    els.patternTriggers.innerHTML = countRows(stats.triggers, { repeatOnly:true });
    els.patternInterpretations.innerHTML = countRows(stats.interpretations, { repeatOnly:true });
    els.patternActions.innerHTML = countRows(stats.actions, { repeatOnly:true });
    const stageEntries = Object.entries(responseLabels).map(([key,label]) => ({ label, count:stats.responseStages[key] || 0 })).filter((x) => x.count > 0);
    els.responseStageSummary.innerHTML = stageEntries.length ? stageEntries.map((item) => `<div class="count-row"><span>${escapeHtml(item.label)}</span><strong>${item.count}</strong></div>`).join('') : '<span class="mirror-empty">لا توجد مراجعات كافية بعد.</span>';
  }

  function renderRulesMirror() {
    const rules = state.rules.filter((rule) => rule.active !== false);
    if (!rules.length) {
      els.rulesMirrorList.innerHTML = emptyCard('لا توجد قواعد بعد.', 'عندما تستخرج قاعدة، ستظهر هنا مع نتائج اختبارها في الواقع.');
      return;
    }
    els.rulesMirrorList.innerHTML = rules.map((rule) => {
      const summary = Core.ruleSummary(state, rule.id);
      const latestNote = summary.latest?.note ? `<p>آخر ملاحظة: ${escapeHtml(summary.latest.note)}</p>` : '';
      const status = summary.total ? `جُربت ${summary.total} · نجحت ${summary.success} · جزئيًا ${summary.partial} · لم تنجح ${summary.failed}` : 'لم تُختبر في موقف لاحق بعد';
      return `<div class="rule-mirror-item"><strong>${escapeHtml(rule.text)}</strong><span>${status}</span>${latestNote}</div>`;
    }).join('');
  }

  function currentWeekReview() {
    const key = localDateKey(startOfCurrentWeek());
    return state.weeklyReviews.find((item) => item.weekStart === key) || null;
  }

  function renderWeeklyMirror() {
    const start = startOfCurrentWeek();
    const end = new Date(start); end.setDate(end.getDate() + 6);
    const situations = weekSituations();
    const stats = Core.summarizeSituations(situations);
    const better = (stats.responseStages.stopped || 0) + (stats.responseStages.alternative || 0);
    const old = (stats.responseStages.old || 0) + (stats.responseStages.late || 0);
    const topTrait = stats.traits[0];
    const weekRuleTests = state.ruleTests.filter((test) => {
      const d = new Date(test.updatedAt || test.createdAt);
      const next = new Date(start); next.setDate(next.getDate()+7);
      return d >= start && d < next;
    });
    els.weekRangeLabel.textContent = `${new Intl.DateTimeFormat('ar',{day:'numeric',month:'short'}).format(start)} — ${new Intl.DateTimeFormat('ar',{day:'numeric',month:'short'}).format(end)}`;
    els.weekComputedSummary.innerHTML = [
      `سُجلت ${stats.total} مواقف، منها ${stats.reviewed} مراجعة مكتملة.`,
      `ظهرت استجابة أفضل في ${better} مواقف، وعاد النمط القديم أو تأخر الانتباه في ${old} مواقف.`,
      topTrait ? `أكثر صفة مرتبطة بالمواقف: ${topTrait.label} (${topTrait.count}).` : 'لا توجد صفة متكررة مسجلة هذا الأسبوع.',
      `اختبارات القواعد المسجلة هذا الأسبوع: ${weekRuleTests.length}.`
    ].map((text) => `<p>${escapeHtml(text)}</p>`).join('');

    const review = currentWeekReview();
    els.weekRecurring.value = review?.recurringPattern || '';
    els.weekImprovements.value = review?.improvements || '';
    els.weekStruggles.value = review?.struggles || '';
    els.weekPrevention.value = review?.preventionReality || '';
    els.weekMindset.value = review?.mindsetShift || '';
    els.weekAdjustment.value = review?.nextAdjustment || '';
    els.weekNotes.value = review?.notes || '';
  }

  function renderMirrors() {
    renderTodayMirror();
    renderPatternMirror();
    renderRulesMirror();
    renderWeeklyMirror();
  }

  function applyView() {
    document.querySelectorAll('[data-view]').forEach((element) => {
      element.hidden = element.dataset.view !== currentView;
    });
    document.querySelectorAll('[data-nav-view]').forEach((button) => {
      button.classList.toggle('active', button.dataset.navView === currentView);
      button.setAttribute('aria-current', button.dataset.navView === currentView ? 'page' : 'false');
    });
  }

  function setView(view) {
    if (!['home','mirrors','path'].includes(view)) return;
    currentView = view;
    if (view === 'mirrors') renderMirrors();
    if (view === 'path') { renderTraitPath(); renderRules(); }
    applyView();
    window.scrollTo({ top:0, behavior:'smooth' });
  }

  function saveWeeklyReview(event) {
    event.preventDefault();
    const existing = currentWeekReview();
    const review = Core.createWeeklyReview({
      id: existing?.id || makeId('week'),
      weekStart: localDateKey(startOfCurrentWeek()),
      recurringPattern: els.weekRecurring.value.trim(),
      improvements: els.weekImprovements.value.trim(),
      struggles: els.weekStruggles.value.trim(),
      preventionReality: els.weekPrevention.value.trim(),
      mindsetShift: els.weekMindset.value.trim(),
      nextAdjustment: els.weekAdjustment.value.trim(),
      notes: els.weekNotes.value.trim(),
      createdAt: existing?.createdAt || new Date().toISOString()
    });
    Core.upsertWeeklyReview(state, review);
    if (persistState()) {
      renderWeeklyMirror();
      showToast('تم حفظ المرآة الأسبوعية.');
    }
  }

  function renderSituations() {
    const pending = state.situations.filter((s) => s.reviewStatus !== 'reviewed').sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
    const reviewed = state.situations.filter((s) => s.reviewStatus === 'reviewed').sort((a,b) => new Date(b.reviewedAt || b.updatedAt) - new Date(a.reviewedAt || a.updatedAt)).slice(0, 4);
    els.pendingCount.textContent = String(pending.length);
    els.pendingList.innerHTML = pending.length ? pending.map((s) => situationCard(s, true)).join('') : emptyCard('لا يوجد شيء ينتظر المراجعة.', 'عندما يحدث موقف، سجّله بسرعة ثم عُد إليه بعد أن تهدأ.');
    els.recentList.innerHTML = reviewed.length ? reviewed.map((s) => situationCard(s, false)).join('') : emptyCard('لم تُنهِ مراجعة أي موقف بعد.', 'أول مراجعة حقيقية ستظهر هنا.');
  }

  function emptyCard(title, note) {
    return `<div class="empty-state"><strong>${escapeHtml(title)}</strong><span>${escapeHtml(note)}</span></div>`;
  }

  function situationCard(s, pending) {
    const tags = (s.linkedTraits || []).map((tag) => `<span class="mini-tag">${escapeHtml(tag)}</span>`).join('');
    const stage = !pending && s.responseStage ? `<span class="stage-badge">${escapeHtml(responseLabels[s.responseStage] || '')}</span>` : '';
    return `<article class="situation-item">
      <div class="situation-main">
        <div class="situation-meta"><span>${escapeHtml(formatDate(s.createdAt))}</span>${stage}</div>
        <p>${escapeHtml(truncate(s.whatHappened, 150))}</p>
        <div class="mini-tags">${tags}</div>
      </div>
      <button class="review-open-btn" data-review-id="${escapeHtml(s.id)}" type="button">${pending ? 'راجع الآن' : 'افتح المراجعة'}</button>
    </article>`;
  }

  function openFocusModal({ onboarding = false, newFocus = false } = {}) {
    focusMode = newFocus ? 'new' : 'edit';
    const trait = newFocus ? null : activeTrait();
    if (trait) Object.entries(els.inputs).forEach(([key, input]) => { input.value = trait[key] || ''; });
    else Object.values(els.inputs).forEach((input) => { input.value = ''; });
    els.focusModalKicker.textContent = newFocus ? 'انتقال منظم' : 'التركيز الحالي';
    els.focusModalTitle.textContent = newFocus ? 'ابدأ صفة جديدة للتركيز' : 'حدّد ما تريد بناءه';
    els.closeModalBtn.hidden = onboarding;
    els.cancelBtn.hidden = onboarding;
    els.focusModal.hidden = false;
    lockBody();
    setTimeout(() => els.inputs.negativeTrait.focus(), 0);
  }

  function closeFocusModal() { els.focusModal.hidden = true; unlockBody(); }

  function handleFocusSubmit(event) {
    event.preventDefault();
    const values = Object.fromEntries(new FormData(els.focusForm).entries());
    const now = new Date().toISOString();
    const current = focusMode === 'edit' ? activeTrait() : null;
    const trait = {
      id: current?.id || makeId('trait'), negativeTrait: String(values.negativeTrait || '').trim(),
      positiveTrait: String(values.positiveTrait || '').trim(), status: current?.status || 'focus',
      oldMindset: String(values.oldMindset || '').trim(), newMindset: String(values.newMindset || '').trim(),
      harms: String(values.harms || '').trim(), alternativeBehavior: String(values.alternativeBehavior || '').trim(),
      preventionMethod: String(values.preventionMethod || '').trim(), rule: String(values.rule || '').trim(),
      createdAt: current?.createdAt || now, updatedAt: now
    };
    if (current) {
      state.traits = state.traits.map((item) => item.id === current.id ? trait : item);
    } else {
      state.traits.push(trait);
      Core.setFocusTrait(state, trait.id, now);
    }
    if (persistState()) { render(); closeFocusModal(); showToast('تم حفظ تركيزك الحالي'); }
  }

  function openQuickModal() {
    els.quickForm.reset();
    quickTags = new Set();
    const focus = activeTrait();
    if (focus?.negativeTrait) quickTags.add(focus.negativeTrait);
    renderTagChips('quick');
    els.quickModal.hidden = false;
    lockBody();
    setTimeout(() => els.quickWhatHappened.focus(), 0);
  }

  function closeQuickModal() { els.quickModal.hidden = true; unlockBody(); }

  function handleQuickSubmit(event) {
    event.preventDefault();
    const whatHappened = els.quickWhatHappened.value.trim();
    if (!whatHappened) { els.quickWhatHappened.focus(); return; }
    const now = new Date().toISOString();
    const situation = Core.createSituation({
      whatHappened,
      feelings: els.quickFeelings.value.trim(),
      urge: els.quickUrge.value.trim(),
      action: els.quickAction.value.trim(),
      linkedTraits: Array.from(quickTags)
    }, makeId('situation'), now);
    Core.addSituation(state, situation);
    if (persistState()) {
      closeQuickModal();
      renderSituations();
      showToast('تم حفظ الموقف. راجعه عندما تهدأ.');
    }
  }

  function traitSuggestions(extra = []) {
    const values = [];
    state.traits.forEach((trait) => { if (trait.negativeTrait) values.push(trait.negativeTrait); });
    state.situations.forEach((s) => (s.linkedTraits || []).forEach((tag) => values.push(tag)));
    extra.forEach((tag) => values.push(tag));
    return [...new Set(values.map((v) => String(v).trim()).filter(Boolean))];
  }

  function renderTagChips(kind) {
    const selected = kind === 'quick' ? quickTags : reviewTags;
    const container = kind === 'quick' ? els.quickTraitChips : els.reviewTraitChips;
    const choices = traitSuggestions([...selected]);
    if (!choices.length) {
      container.innerHTML = '<span class="field-help">أضف أول صفة مرتبطة بهذا الموقف.</span>';
      return;
    }
    container.innerHTML = choices.map((tag) => `<button type="button" class="tag-chip ${selected.has(tag) ? 'selected' : ''}" data-tag-kind="${kind}" data-tag="${escapeHtml(tag)}" aria-pressed="${selected.has(tag)}">${escapeHtml(tag)}</button>`).join('');
  }

  function toggleTag(kind, tag) {
    const target = kind === 'quick' ? quickTags : reviewTags;
    target.has(tag) ? target.delete(tag) : target.add(tag);
    renderTagChips(kind);
    if (kind === 'review') queueReviewAutosave();
  }

  function addCustomTag(kind) {
    const input = kind === 'quick' ? els.quickTraitInput : els.reviewTraitInput;
    const value = input.value.trim();
    if (!value) return;
    (kind === 'quick' ? quickTags : reviewTags).add(value);
    input.value = '';
    renderTagChips(kind);
    if (kind === 'review') queueReviewAutosave();
  }

  function openReview(id) {
    clearTimeout(autosaveTimer);
    const s = situationById(id);
    if (!s) return;
    currentReviewId = id;
    reviewStep = 1;
    reviewTags = new Set(s.linkedTraits || []);
    els.reviewWhatHappened.value = s.whatHappened || '';
    els.reviewTrigger.value = s.trigger || '';
    els.reviewFeelings.value = s.feelings || '';
    els.reviewInterpretation.value = s.interpretation || '';
    els.reviewDeeperReflection.value = s.deeperReflection || '';
    els.reviewUrge.value = s.urge || '';
    els.reviewAction.value = s.action || '';
    els.reviewConsequence.value = s.consequence || '';
    els.reviewBetterResponse.value = s.betterResponse || '';
    els.reviewPrevention.value = s.prevention || '';
    els.reviewNewRule.value = s.ruleCandidate || '';
    populateReviewRuleSelect();
    const draftTest = s.ruleTestDraft || state.ruleTests.find((test) => test.situationId === s.id) || null;
    els.reviewRuleSelect.value = draftTest?.ruleId || '';
    els.reviewForm.querySelectorAll('input[name="ruleTestResult"]').forEach((radio) => { radio.checked = radio.value === draftTest?.result; });
    els.reviewRuleTestNote.value = draftTest?.note || '';
    toggleRuleTestFields();
    els.reviewForm.querySelectorAll('input[name="responseStage"]').forEach((radio) => { radio.checked = radio.value === s.responseStage; });
    renderTagChips('review');
    renderReviewStep();
    els.reviewAutosave.textContent = 'تُحفظ المسودة تلقائيًا على هذا الجهاز.';
    els.reviewModal.hidden = false;
    lockBody();
  }

  function closeReview() {
    clearTimeout(autosaveTimer);
    if (currentReviewId) snapshotReview(false, { quiet: true });
    els.reviewModal.hidden = true;
    currentReviewId = null;
    unlockBody();
    renderSituations();
  }

  function renderReviewStep() {
    els.reviewForm.querySelectorAll('.review-step').forEach((section) => { section.hidden = Number(section.dataset.step) !== reviewStep; });
    els.reviewModal.querySelectorAll('[data-dot]').forEach((dot) => dot.classList.toggle('active', Number(dot.dataset.dot) <= reviewStep));
    els.reviewPrevBtn.hidden = reviewStep === 1;
    els.reviewNextBtn.hidden = reviewStep === 3;
    els.reviewFinishBtn.hidden = reviewStep !== 3;
  }

  function selectedResponseStage() {
    return els.reviewForm.querySelector('input[name="responseStage"]:checked')?.value || null;
  }

  function snapshotReview(markReviewed = false, { quiet = true } = {}) {
    const s = situationById(currentReviewId);
    if (!s) return false;
    Object.assign(s, {
      whatHappened: els.reviewWhatHappened.value.trim(), trigger: els.reviewTrigger.value.trim(),
      feelings: els.reviewFeelings.value.trim(), interpretation: els.reviewInterpretation.value.trim(),
      deeperReflection: els.reviewDeeperReflection.value.trim(), urge: els.reviewUrge.value.trim(),
      action: els.reviewAction.value.trim(), consequence: els.reviewConsequence.value.trim(),
      betterResponse: els.reviewBetterResponse.value.trim(), prevention: els.reviewPrevention.value.trim(),
      linkedTraits: Array.from(reviewTags), responseStage: selectedResponseStage(),
      ruleCandidate: els.reviewNewRule.value.trim(),
      ruleTestDraft: els.reviewRuleSelect.value ? { ruleId: els.reviewRuleSelect.value, result: selectedRuleTestResult(), note: els.reviewRuleTestNote.value.trim() } : null,
      updatedAt: new Date().toISOString()
    });
    if (markReviewed) { s.reviewStatus = 'reviewed'; s.reviewedAt = new Date().toISOString(); }
    return persistState({ quiet });
  }

  function selectedRuleTestResult() {
    return els.reviewForm.querySelector('input[name="ruleTestResult"]:checked')?.value || '';
  }

  function populateReviewRuleSelect() {
    const current = els.reviewRuleSelect.value;
    const options = state.rules.filter((rule) => rule.active !== false).map((rule) => `<option value="${escapeHtml(rule.id)}">${escapeHtml(rule.text)}</option>`).join('');
    els.reviewRuleSelect.innerHTML = `<option value="">لم أختبر قاعدة سابقة</option>${options}`;
    if ([...els.reviewRuleSelect.options].some((option) => option.value === current)) els.reviewRuleSelect.value = current;
  }

  function toggleRuleTestFields() {
    const visible = Boolean(els.reviewRuleSelect.value);
    els.ruleTestResultWrap.hidden = !visible;
    els.ruleTestNoteWrap.hidden = !visible;
    if (!visible) {
      els.reviewForm.querySelectorAll('input[name="ruleTestResult"]').forEach((radio) => { radio.checked = false; });
      els.reviewRuleTestNote.value = '';
    }
  }

  function ensureRuleFromSituation(situation) {
    const text = String(situation.ruleCandidate || '').trim();
    if (!text) return null;
    const normalized = text.replace(/\s+/g, ' ').trim().toLocaleLowerCase('ar');
    let rule = state.rules.find((item) => String(item.text || '').replace(/\s+/g, ' ').trim().toLocaleLowerCase('ar') === normalized);
    if (rule) {
      if (!rule.sourceSituationIds.includes(situation.id)) rule.sourceSituationIds.push(situation.id);
      rule.updatedAt = new Date().toISOString();
      return rule;
    }
    const linkedTrait = state.traits.find((trait) => (situation.linkedTraits || []).includes(trait.negativeTrait)) || activeTrait();
    rule = Core.createRule({
      text,
      reason: 'مستخرجة من مراجعة موقف حقيقي',
      linkedTraitId: linkedTrait?.id || null,
      sourceSituationIds: [situation.id]
    }, makeId('rule'));
    Core.addRule(state, rule);
    return rule;
  }

  function applyRuleTestFromSituation(situation) {
    const draft = situation.ruleTestDraft;
    if (!draft?.ruleId || !draft?.result) return null;
    const test = Core.createRuleTest({
      ruleId: draft.ruleId,
      situationId: situation.id,
      result: draft.result,
      note: draft.note || ''
    }, makeId('rule-test'));
    return Core.upsertRuleTest(state, test);
  }

  function queueReviewAutosave() {
    if (!currentReviewId) return;
    els.reviewAutosave.textContent = 'جارٍ حفظ المسودة…';
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(() => {
      const saved = snapshotReview(false, { quiet: true });
      els.reviewAutosave.textContent = saved ? 'تم حفظ المسودة تلقائيًا.' : 'تعذر حفظ المسودة على هذا الجهاز.';
    }, 350);
  }

  function goReviewStep(delta) {
    snapshotReview(false, { quiet: true });
    reviewStep = Math.min(3, Math.max(1, reviewStep + delta));
    renderReviewStep();
    els.reviewModal.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function validateFinalReview() {
    const checks = [
      { el: els.reviewTrigger, step: 1, message: 'اكتب ما الذي حدث فعلًا قبل إنهاء المراجعة.' },
      { el: els.reviewInterpretation, step: 2, message: 'اكتب كيف فسرت الموقف.' },
      { el: els.reviewBetterResponse, step: 3, message: 'حدّد التصرف الأفضل للمرة القادمة.' }
    ];
    const missing = checks.find((item) => !item.el.value.trim());
    if (!missing) return true;
    reviewStep = missing.step;
    renderReviewStep();
    showToast(missing.message);
    setTimeout(() => missing.el.focus(), 0);
    return false;
  }

  function finishReview(event) {
    event.preventDefault();
    if (!validateFinalReview()) return;
    if (els.reviewRuleSelect.value && !selectedRuleTestResult()) {
      showToast('حدّد نتيجة اختبار القاعدة: نجحت، جزئيًا، أو لم تنجح.');
      reviewStep = 3;
      renderReviewStep();
      return;
    }
    if (snapshotReview(true, { quiet: true })) {
      const reviewed = situationById(currentReviewId);
      ensureRuleFromSituation(reviewed);
      applyRuleTestFromSituation(reviewed);
      const saved = persistState({ quiet: false });
      if (!saved) return;
      clearTimeout(autosaveTimer);
      els.reviewModal.hidden = true;
      currentReviewId = null;
      unlockBody();
      render();
      showToast('اكتملت المراجعة وحُفظت القواعد المرتبطة بها.');
    }
  }

  function openTraitManager() {
    renderTraitPath();
    els.traitManagerModal.hidden = false;
    lockBody();
  }

  function closeTraitManager() { els.traitManagerModal.hidden = true; unlockBody(); }

  function handleTraitAction(id, action) {
    try {
      if (action === 'focus') Core.setFocusTrait(state, id);
      else Core.setTraitStatus(state, id, action);
      if (persistState()) {
        render();
        showToast(action === 'focus' ? 'تم تغيير صفة التركيز، وانتقلت السابقة إلى التثبيت.' : 'تم تحديث حالة الصفة.');
      }
    } catch (error) {
      showToast('تعذر تحديث الصفة: ' + error.message);
    }
  }

  function fillRuleTraitSelect(selected = '') {
    const options = state.traits.map((trait) => `<option value="${escapeHtml(trait.id)}">${escapeHtml(traitDisplay(trait))}</option>`).join('');
    els.ruleTraitSelect.innerHTML = `<option value="">بدون ربط بصفة محددة</option>${options}`;
    els.ruleTraitSelect.value = selected || activeTrait()?.id || '';
  }

  function openRuleModal(id = null) {
    currentRuleId = id;
    const rule = id ? state.rules.find((item) => item.id === id) : null;
    els.ruleTextInput.value = rule?.text || '';
    els.ruleReasonInput.value = rule?.reason || '';
    fillRuleTraitSelect(rule?.linkedTraitId || '');
    $('ruleModalTitle').textContent = rule ? 'عدّل القاعدة العملية' : 'أضف قاعدة عملية';
    els.ruleModal.hidden = false;
    lockBody();
    setTimeout(() => els.ruleTextInput.focus(), 0);
  }

  function closeRuleModal() { els.ruleModal.hidden = true; currentRuleId = null; unlockBody(); }

  function handleRuleSubmit(event) {
    event.preventDefault();
    const text = els.ruleTextInput.value.trim();
    if (!text) return;
    const now = new Date().toISOString();
    if (currentRuleId) {
      const rule = state.rules.find((item) => item.id === currentRuleId);
      if (!rule) return;
      rule.text = text;
      rule.reason = els.ruleReasonInput.value.trim();
      rule.linkedTraitId = els.ruleTraitSelect.value || null;
      rule.updatedAt = now;
    } else {
      const duplicate = state.rules.find((item) => item.text.trim().toLocaleLowerCase('ar') === text.toLocaleLowerCase('ar'));
      if (duplicate) {
        showToast('هذه القاعدة موجودة بالفعل؛ يمكنك تعديلها بدل تكرارها.');
        return;
      }
      Core.addRule(state, Core.createRule({
        text,
        reason: els.ruleReasonInput.value.trim(),
        linkedTraitId: els.ruleTraitSelect.value || null
      }, makeId('rule'), now));
    }
    if (persistState()) {
      closeRuleModal();
      renderRules();
      showToast('تم حفظ القاعدة.');
    }
  }

  function showToast(message) {
    els.toast.textContent = message;
    els.toast.hidden = false;
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => { els.toast.hidden = true; }, 2400);
  }

  function toggleWhy() {
    const expanded = els.whyToggle.getAttribute('aria-expanded') === 'true';
    els.whyToggle.setAttribute('aria-expanded', String(!expanded));
    els.whyPanel.hidden = expanded;
  }

  function lockBody() { document.body.style.overflow = 'hidden'; }
  function unlockBody() {
    if ([els.focusModal, els.quickModal, els.reviewModal, els.traitManagerModal, els.ruleModal, els.adhkarModal].some((modal) => !modal.hidden)) return;
    document.body.style.overflow = '';
  }

  function handleDynamicClick(event) {
    const reviewButton = event.target.closest('[data-review-id]');
    if (reviewButton) { openReview(reviewButton.dataset.reviewId); return; }
    const tagButton = event.target.closest('[data-tag-kind][data-tag]');
    if (tagButton) { toggleTag(tagButton.dataset.tagKind, tagButton.dataset.tag); return; }
    const traitAction = event.target.closest('[data-trait-action][data-trait-id]');
    if (traitAction) { handleTraitAction(traitAction.dataset.traitId, traitAction.dataset.traitAction); return; }
    const ruleEdit = event.target.closest('[data-rule-edit]');
    if (ruleEdit) openRuleModal(ruleEdit.dataset.ruleEdit);
  }

  function bootstrap() {
    render();
    els.editFocusBtn.addEventListener('click', () => openFocusModal());
    if (els.startFocusBtn) els.startFocusBtn.addEventListener('click', () => openFocusModal({ newFocus: true }));
    els.closeModalBtn.addEventListener('click', closeFocusModal);
    els.cancelBtn.addEventListener('click', closeFocusModal);
    els.focusForm.addEventListener('submit', handleFocusSubmit);
    els.whyToggle.addEventListener('click', toggleWhy);
    els.newReminderBtn.addEventListener('click', () => renderOpeningReminder(true));
    els.morningAdhkarBtn.addEventListener('click', () => openAdhkar('morning'));
    els.eveningAdhkarBtn.addEventListener('click', () => openAdhkar('evening'));
    els.closeAdhkarBtn.addEventListener('click', closeAdhkar);
    els.exportBackupBtn.addEventListener('click', exportBackup);
    els.importBackupBtn.addEventListener('click', () => els.backupFileInput.click());
    els.backupFileInput.addEventListener('change', () => importBackupFile(els.backupFileInput.files?.[0]));
    els.manageTraitsBtn.addEventListener('click', openTraitManager);
    els.closeTraitManagerBtn.addEventListener('click', closeTraitManager);
    els.newFocusBtn.addEventListener('click', () => { closeTraitManager(); openFocusModal({ newFocus: true }); });
    els.addRuleBtn.addEventListener('click', () => openRuleModal());
    els.closeRuleBtn.addEventListener('click', closeRuleModal);
    els.cancelRuleBtn.addEventListener('click', closeRuleModal);
    els.ruleForm.addEventListener('submit', handleRuleSubmit);

    els.situationBtn.addEventListener('click', openQuickModal);
    els.closeQuickBtn.addEventListener('click', closeQuickModal);
    els.cancelQuickBtn.addEventListener('click', closeQuickModal);
    els.quickForm.addEventListener('submit', handleQuickSubmit);
    els.quickTraitAdd.addEventListener('click', () => addCustomTag('quick'));
    els.quickTraitInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addCustomTag('quick'); } });

    els.closeReviewBtn.addEventListener('click', closeReview);
    els.reviewPrevBtn.addEventListener('click', () => goReviewStep(-1));
    els.reviewNextBtn.addEventListener('click', () => goReviewStep(1));
    els.reviewForm.addEventListener('submit', finishReview);
    els.reviewForm.addEventListener('input', queueReviewAutosave);
    els.reviewForm.addEventListener('change', queueReviewAutosave);
    els.reviewRuleSelect.addEventListener('change', () => { toggleRuleTestFields(); queueReviewAutosave(); });
    els.reviewTraitAdd.addEventListener('click', () => addCustomTag('review'));
    els.reviewTraitInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addCustomTag('review'); } });

    document.addEventListener('click', handleDynamicClick);
    [els.focusModal, els.quickModal, els.traitManagerModal, els.ruleModal, els.adhkarModal].forEach((modal) => modal.addEventListener('click', (event) => {
      if (event.target !== modal) return;
      if (modal === els.focusModal) closeFocusModal();
      if (modal === els.quickModal) closeQuickModal();
      if (modal === els.traitManagerModal) closeTraitManager();
      if (modal === els.ruleModal) closeRuleModal();
      if (modal === els.adhkarModal) closeAdhkar();
    }));
    document.addEventListener('keydown', (event) => {
      if (event.key !== 'Escape') return;
      if (!els.reviewModal.hidden) closeReview();
      else if (!els.adhkarModal.hidden) closeAdhkar();
      else if (!els.quickModal.hidden) closeQuickModal();
      else if (!els.ruleModal.hidden) closeRuleModal();
      else if (!els.traitManagerModal.hidden) closeTraitManager();
      else if (!els.focusModal.hidden) closeFocusModal();
    });
    document.querySelectorAll('[data-nav-view]').forEach((button) => button.addEventListener('click', () => setView(button.dataset.navView)));
    els.patternPeriod.addEventListener('change', renderPatternMirror);
    els.weeklyReviewForm.addEventListener('submit', saveWeeklyReview);

    if (!storageHealthy) els.saveState.textContent = 'التخزين المحلي غير متاح';
    if (loadWarning) showToast(loadWarning);
    // لا نفتح نموذج إنشاء الصفة تلقائيًا عند أول دخول؛ المستخدم يبدأه من داخل التطبيق عندما يريد.
  }

  // واجهة اختبار غير مرئية للمستخدم للتحقق من الحفظ والترحيل والمواقف آليًا.
  window.TazkiyahApp = {
    storageKey: STORAGE_KEY,
    schemaVersion: SCHEMA_VERSION,
    getState: () => structuredClone(state),
    reset: () => { storageRemove(STORAGE_KEY); state = emptyState(); render(); },
    reloadFromStorage: () => { state = loadState(); render(); return structuredClone(state); },
    createSituation: (overrides = {}) => {
      const now = new Date().toISOString();
      const item = Core.createSituation({ whatHappened: 'موقف اختباري', ...overrides }, makeId('situation'), now);
      Core.addSituation(state, item); persistState({ quiet: true }); renderSituations(); return structuredClone(item);
    },
    completeSituation: (id, overrides = {}) => {
      const item = Core.completeSituation(state, id, { trigger:'اختبار', interpretation:'تفسير', betterResponse:'بديل', ...overrides });
      if (!item) return null;
      persistState({ quiet: true }); renderSituations(); return structuredClone(item);
    },
    addRule: (overrides = {}) => {
      const item = Core.createRule({ text:'قاعدة اختبارية', ...overrides }, makeId('rule'));
      Core.addRule(state, item); persistState({ quiet:true }); renderRules(); return structuredClone(item);
    },
    testRule: (ruleId, situationId, result = 'success', note = '') => {
      const item = Core.createRuleTest({ ruleId, situationId, result, note }, makeId('rule-test'));
      const saved = Core.upsertRuleTest(state, item); persistState({ quiet:true }); renderRules(); return structuredClone(saved);
    },
    setFocusTrait: (id) => { const item = Core.setFocusTrait(state, id); persistState({quiet:true}); render(); return item ? structuredClone(item) : null; },
    summarize: (ids = null) => Core.summarizeSituations(ids ? state.situations.filter((s) => ids.includes(s.id)) : state.situations),
    saveWeek: (overrides = {}) => {
      const existing = state.weeklyReviews.find((item) => item.weekStart === (overrides.weekStart || localDateKey(startOfCurrentWeek())));
      const item = Core.createWeeklyReview({ id: existing?.id || makeId('week'), weekStart: overrides.weekStart || localDateKey(startOfCurrentWeek()), ...overrides }, existing?.id || makeId('week'));
      const saved = Core.upsertWeeklyReview(state, item); persistState({quiet:true}); return structuredClone(saved);
    },
    makeBackup: () => Core.makeBackup(state),
    restoreBackup: (payload) => { state = Core.readBackup(payload); persistState({quiet:true}); render(); return structuredClone(state); }
  };

  bootstrap();
})();
