(function (root) {
  'use strict';

  root.TazkiyahContent = {
    adhkar: {
      morning: [
        {
          id: 'morning-5068',
          text: 'اللهم بك أصبحنا، وبك أمسينا، وبك نحيا، وبك نموت، وإليك النشور.',
          repeat: 1,
          source: 'صحيح أبي داود 5068',
          grade: 'صحيح',
          url: 'https://dorar.net/hadith/sharh/86428'
        },
        {
          id: 'morning-5088',
          text: 'بسم الله الذي لا يضر مع اسمه شيء في الأرض ولا في السماء وهو السميع العليم.',
          repeat: 3,
          source: 'صحيح أبي داود 5088',
          grade: 'صحيح',
          url: 'https://dorar.net/hadith/sharh/70266'
        },
        {
          id: 'morning-5082',
          text: 'اقرأ سورة الإخلاص وسورتي الفلق والناس.',
          repeat: 3,
          source: 'صحيح أبي داود 5082',
          grade: 'حسن',
          url: 'https://dorar.net/hadith/sharh/28801'
        }
      ],
      evening: [
        {
          id: 'evening-5068',
          text: 'اللهم بك أمسينا، وبك نحيا، وبك نموت، وإليك النشور.',
          repeat: 1,
          source: 'صحيح أبي داود 5068',
          grade: 'صحيح',
          url: 'https://dorar.net/hadith/sharh/86428'
        },
        {
          id: 'evening-5088',
          text: 'بسم الله الذي لا يضر مع اسمه شيء في الأرض ولا في السماء وهو السميع العليم.',
          repeat: 3,
          source: 'صحيح أبي داود 5088',
          grade: 'صحيح',
          url: 'https://dorar.net/hadith/sharh/70266'
        },
        {
          id: 'evening-5082',
          text: 'اقرأ سورة الإخلاص وسورتي الفلق والناس.',
          repeat: 3,
          source: 'صحيح أبي داود 5082',
          grade: 'حسن',
          url: 'https://dorar.net/hadith/sharh/28801'
        }
      ]
    },
    references: [
      {
        id: 'quran-3-134',
        type: 'quran',
        text: 'وَالْكَاظِمِينَ الْغَيْظَ وَالْعَافِينَ عَنِ النَّاسِ ۗ وَاللَّهُ يُحِبُّ الْمُحْسِنِينَ',
        source: 'آل عمران: 134',
        url: 'https://quran.com/3/134',
        tags: ['الغضب']
      },
      {
        id: 'bukhari-6116',
        type: 'hadith',
        text: 'لا تغضب.',
        source: 'صحيح البخاري 6116',
        url: 'https://sunnah.com/bukhari:6116',
        tags: ['الغضب']
      },
      {
        id: 'bukhari-6114',
        type: 'hadith',
        text: 'ليس الشديد بالصرعة، إنما الشديد الذي يملك نفسه عند الغضب.',
        source: 'صحيح البخاري 6114، وصحيح مسلم 2609',
        url: 'https://dorar.net/h/FKzk4Uek?osoul=1',
        tags: ['الغضب']
      },
      {
        id: 'quran-49-6',
        type: 'quran',
        text: 'إِن جَاءَكُمْ فَاسِقٌ بِنَبَإٍ فَتَبَيَّنُوا أَن تُصِيبُوا قَوْمًا بِجَهَالَةٍ فَتُصْبِحُوا عَلَىٰ مَا فَعَلْتُمْ نَادِمِينَ',
        source: 'الحجرات: 6',
        url: 'https://quran.com/49/6',
        tags: ['التسرع', 'إصدار الأحكام']
      },
      {
        id: 'quran-49-12',
        type: 'quran',
        text: 'اجْتَنِبُوا كَثِيرًا مِنَ الظَّنِّ إِنَّ بَعْضَ الظَّنِّ إِثْمٌ',
        source: 'الحجرات: 12',
        url: 'https://quran.com/49/12',
        tags: ['سوء الظن']
      },
      {
        id: 'bukhari-6018',
        type: 'hadith',
        text: 'فليقل خيرًا أو ليصمت.',
        source: 'صحيح البخاري 6018، وصحيح مسلم 47',
        url: 'https://dorar.net/hadith/sharh/4361',
        tags: ['حفظ اللسان', 'رفع الصوت']
      }
    ]
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
