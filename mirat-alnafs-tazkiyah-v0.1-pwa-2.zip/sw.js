/*
 * مرآة النفس — تزكية: Service Worker
 *
 * الغرض الوحيد: تشغيل واجهة التطبيق دون اتصال بعد أول تحميل ناجح.
 *
 * قواعد ثابتة:
 * - لا يلمس بيانات المستخدم. البيانات في localStorage، والـService Worker
 *   لا يستطيع الوصول إليها أصلًا، ولا يحذف إلا كاش ملفات الواجهة الخاص به.
 * - كل إصدار له كاش مستقل ومكتمل (تثبيت ذري): إن فشل تحميل أي ملف لا يُفعَّل
 *   الإصدار الجديد ويبقى السابق يعمل.
 * - عند كل نشر لتعديل في ملفات الواجهة: ارفع CACHE_VERSION.
 */
'use strict';

const CACHE_VERSION = 'v0.1-pwa-2';
const CACHE_PREFIX = 'tazkiyah-shell-';
const CACHE_NAME = CACHE_PREFIX + CACHE_VERSION;

const APP_SHELL = [
  './',
  'styles.css',
  'content.js',
  'core.js',
  'app.js',
  'manifest.webmanifest',
  'icons/icon-192.png',
  'icons/icon-512.png',
  'icons/icon-maskable-512.png',
  'icons/apple-touch-icon.png',
  'icons/favicon-32.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      // cache: 'reload' يتجاوز كاش HTTP كي لا يُخزَّن ملف قديم داخل إصدار جديد.
      .then((cache) => cache.addAll(APP_SHELL.map((url) => new Request(url, { cache: 'reload' }))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys
          .filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  // روابط المصادر الخارجية (الدرر السنية، sunnah.com، quran.com) لا تُعترض.
  if (url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    // أي فتح للصفحة (مع أو بدون ?query) يُخدم من الواجهة المخزنة.
    event.respondWith(
      caches.match('./', { ignoreSearch: true })
        .then((cached) => cached || fetch(request))
    );
    return;
  }

  event.respondWith(
    caches.match(request, { ignoreSearch: true })
      .then((cached) => cached || fetch(request))
  );
});
