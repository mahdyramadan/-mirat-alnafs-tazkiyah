// Tazkiyah v0.2 runtime configuration.
// Production binding for RC.1 push verification.
globalThis.TAZKIYAH_CONFIG = Object.freeze({
  pushApiBase: 'https://tazkiyah-push-v02-rc1-live.onrender.com',
  aiApiBase: ''
});
