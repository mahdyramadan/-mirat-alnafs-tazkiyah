// pushfix1 cache revision
/*
 * مرآة النفس — تزكية: Service Worker
 *
 * الغرض الوحيد: تشغيل واجهة التطبيق دون اتصال بعد أول تحميل ناجح.
 *
 * قواعد ثابتة:
 * - لا يلمس بيانات المستخدم. البيانات في localStorage، والـService Worker
 *   لا يستطيع الوصول إليها أصلًا، ولا يحذف إلا كاش ملفات الواجهة الخاص به.
 * - كل إصدار له كاش مستقل ومكتمل (تثبيت ذري): إن فشل تحميل أي ملف لا يُفعَّل
 *   الإصدار الجديد ويبقى السابق يعمل.
 * - عند كل نشر لتعديل في ملفات الواجهة: ارفع CACHE_VERSION.
 */
'use strict';

const CACHE_VERSION = 'v0.2-part8-2-push-binding';
const CACHE_PREFIX = 'tazkiyah-shell-';
const CACHE_NAME = CACHE_PREFIX + CACHE_VERSION;

const APP_SHELL = [
  './',
  'styles.css',
  'content.js',
  'core.js',
  'config.js',
  'app.js',
  'manifest.webmanifest',
  'icons/icon-192.png',
  'icons/icon-512.png',
  'icons/icon-maskable-512.png',
  'icons/apple-touch-icon.png',
  'icons/favicon-32.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      // cache: 'reload' يتجاوز كاش HTTP كي لا يُخزَّن ملف قديم داخل إصدار جديد.
      .then((cache) => cache.addAll(APP_SHELL.map((url) => new Request(url, { cache: 'reload' }))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys
          .filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  // روابط المصادر الخارجية (الدرر السنية، sunnah.com، quran.com) لا تُعترض.
  if (url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    // أي فتح للصفحة (مع أو بدون ?query) يُخدم من الواجهة المخزنة.
    event.respondWith(
      caches.match('./', { ignoreSearch: true })
        .then((cached) => cached || fetch(request))
    );
    return;
  }

  event.respondWith(
    caches.match(request, { ignoreSearch: true })
      .then((cached) => cached || fetch(request))
  );
});



// Part 6.3: Web Push الحقيقي. الحمولة لا تحتوي نصوص مواقف المستخدم؛
// الخادم يرسل نوع التذكير ونصًا عامًا فقط.
self.addEventListener('push', (event) => {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; } catch { payload = {}; }
  const title = typeof payload.title === 'string' && payload.title ? payload.title : 'تزكية';
  const options = {
    body: typeof payload.body === 'string' && payload.body ? payload.body : 'لديك تذكير من تزكية.',
    icon: 'icons/icon-192.png',
    badge: 'icons/favicon-32.png',
    tag: typeof payload.tag === 'string' && payload.tag ? payload.tag : 'tazkiyah-reminder',
    renotify: false,
    data: { url: typeof payload.url === 'string' && payload.url ? payload.url : './?from=push' }
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

// Part 6.2/6.3: النقر على إشعار النظام يعيد المستخدم إلى التطبيق.
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = event.notification?.data?.url || './';
  event.waitUntil(
    self.clients.matchAll({ type:'window', includeUncontrolled:true }).then((clients) => {
      for (const client of clients) {
        if ('focus' in client) {
          client.navigate(target).catch(() => {});
          return client.focus();
        }
      }
      return self.clients.openWindow ? self.clients.openWindow(target) : undefined;
    })
  );
});
