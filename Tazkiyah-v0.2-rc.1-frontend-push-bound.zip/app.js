(() => {
  'use strict';

  const STORAGE_KEY = 'mirat-alnafs:v0.1';
  const Core = globalThis.TazkiyahCore;
  const Content = globalThis.TazkiyahContent;
  if (!Core) throw new Error('TazkiyahCore is required');
  if (!Content) throw new Error('TazkiyahContent is required');
  const SCHEMA_VERSION = Core.SCHEMA_VERSION;
  const RECOVERY_KEY = `${STORAGE_KEY}:recovery`;
  const NOTIFICATION_PREFS_KEY = 'mirat-alnafs:v0.2:notification-preferences';
  const PUSH_CLIENT_KEY = 'mirat-alnafs:v0.2:push-client';
  const AI_PREFS_KEY = 'mirat-alnafs:v0.2:ai-preferences';
  const AI_PROPOSALS_KEY = 'mirat-alnafs:v0.2:ai-proposals';
  const AI_CONSENT_VERSION = 1;
  const DEFAULT_AI_PREFS = { enabled:false, consentVersion:0, consentedAt:'', shareFeelings:false, shareTrait:false, shareRule:false };
  const DEFAULT_NOTIFICATION_PREFS = {
    rule: { enabled:false, time:'13:00' },
    morning: { enabled:false, time:'08:00' },
    evening: { enabled:false, time:'20:00' },
    weekly: { enabled:false, day:'5', time:'19:00' }
  };
  let storageHealthy = true;
  let loadWarning = '';
  let quickTags = new Set();
  let reviewTags = new Set();
  let currentReviewId = null;
  let postCaptureSituationId = null;
  let reviewStep = 1;
  let autosaveTimer = null;
  let focusMode = 'edit';
  let currentRuleId = null;
  let currentView = 'home';
  let currentReminderKey = '';
  let reminderCursor = 0;
  let pushRuntime = { state:'idle', subscribed:false, message:'' };
  let pushSyncTimer = null;
  let currentAiProposal = null;
  let aiRuntime = { state:'idle', configured:false, provider:'', model:'', message:'' };

  const emptyState = Core.emptyState;
  // يجب تعريفهما قبل loadState(): كانا بعدها فيتعطل التطبيق عند فتحه مع بيانات محفوظة.
  const migrateState = Core.migrateState;
  const isValidState = Core.isValidState;

  const $ = (id) => document.getElementById(id);
  let state = loadState();

  const els = {
    negativeTrait: $('negativeTrait'), positiveTrait: $('positiveTrait'), oldMindset: $('oldMindset'),
    newMindset: $('newMindset'), dailyRuleTitle: $('dailyRuleTitle'), alternativeBehavior: $('alternativeBehavior'),
    preventionMethod: $('preventionMethod'), harmsText: $('harmsText'), statusPill: $('statusPill'), saveState: $('saveState'),
    focusModal: $('focusModal'), focusForm: $('focusForm'), editFocusBtn: $('editFocusBtn'), startFocusBtn: $('startFocusBtn'), closeModalBtn: $('closeModalBtn'),
    cancelBtn: $('cancelBtn'), whyToggle: $('whyToggle'), whyPanel: $('whyPanel'), toast: $('toast'), situationBtn: $('situationBtn'),
    pendingList: $('pendingList'), recentList: $('recentList'), pendingCount: $('pendingCount'),
    manageTraitsBtn: $('manageTraitsBtn'), traitPathSummary: $('traitPathSummary'), traitManagerModal: $('traitManagerModal'),
    closeTraitManagerBtn: $('closeTraitManagerBtn'), traitManagerList: $('traitManagerList'), newFocusBtn: $('newFocusBtn'),
    addRuleBtn: $('addRuleBtn'), rulesList: $('rulesList'), ruleModal: $('ruleModal'), closeRuleBtn: $('closeRuleBtn'), cancelRuleBtn: $('cancelRuleBtn'),
    ruleForm: $('ruleForm'), ruleTextInput: $('ruleTextInput'), ruleReasonInput: $('ruleReasonInput'), ruleTraitSelect: $('ruleTraitSelect'),
    focusModalKicker: $('focusModalKicker'), focusModalTitle: $('focusModalTitle'),
    todaySummaryCards: $('todaySummaryCards'), todaySituations: $('todaySituations'), patternPeriod: $('patternPeriod'),
    patternTraits: $('patternTraits'), patternFeelings: $('patternFeelings'), patternTriggers: $('patternTriggers'),
    patternInterpretations: $('patternInterpretations'), patternActions: $('patternActions'), responseStageSummary: $('responseStageSummary'),
    patternCoverageNote: $('patternCoverageNote'),
    rulesMirrorList: $('rulesMirrorList'), weeklyReviewForm: $('weeklyReviewForm'), weekRangeLabel: $('weekRangeLabel'),
    weekComputedSummary: $('weekComputedSummary'), weekRecurring: $('weekRecurring'), weekImprovements: $('weekImprovements'),
    weekStruggles: $('weekStruggles'), weekPrevention: $('weekPrevention'), weekMindset: $('weekMindset'),
    weekAdjustment: $('weekAdjustment'), weekNotes: $('weekNotes'),
    sessionReminderText: $('sessionReminderText'), sessionReminderSource: $('sessionReminderSource'), newReminderBtn: $('newReminderBtn'),
    morningAdhkarBtn: $('morningAdhkarBtn'), eveningAdhkarBtn: $('eveningAdhkarBtn'), adhkarModal: $('adhkarModal'),
    closeAdhkarBtn: $('closeAdhkarBtn'), adhkarModalTitle: $('adhkarModalTitle'), adhkarList: $('adhkarList'),
    exportBackupBtn: $('exportBackupBtn'), importBackupBtn: $('importBackupBtn'), backupFileInput: $('backupFileInput'), backupStatus: $('backupStatus'),
    notificationBadge: $('notificationBadge'), notificationStatus: $('notificationStatus'), notificationStatusTitle: $('notificationStatusTitle'),
    notificationStatusText: $('notificationStatusText'), enableNotificationsBtn: $('enableNotificationsBtn'), testNotificationBtn: $('testNotificationBtn'),
    testPushNotificationBtn: $('testPushNotificationBtn'), disablePushBtn: $('disablePushBtn'),
    pushDeliveryStatus: $('pushDeliveryStatus'), pushDeliveryTitle: $('pushDeliveryTitle'), pushDeliveryText: $('pushDeliveryText'),
    notificationPreferences: $('notificationPreferences'), notificationFootnote: $('notificationFootnote'),
    notifyRuleEnabled: $('notifyRuleEnabled'), notifyRuleTime: $('notifyRuleTime'),
    notifyMorningEnabled: $('notifyMorningEnabled'), notifyMorningTime: $('notifyMorningTime'),
    notifyEveningEnabled: $('notifyEveningEnabled'), notifyEveningTime: $('notifyEveningTime'),
    notifyWeeklyEnabled: $('notifyWeeklyEnabled'), notifyWeeklyDay: $('notifyWeeklyDay'), notifyWeeklyTime: $('notifyWeeklyTime'),
    aiBadge: $('aiBadge'), aiStatus: $('aiStatus'), aiStatusTitle: $('aiStatusTitle'), aiStatusText: $('aiStatusText'),
    enableAiBtn: $('enableAiBtn'), disableAiBtn: $('disableAiBtn'), aiPreferences: $('aiPreferences'),
    aiShareSituation: $('aiShareSituation'), aiShareFeelings: $('aiShareFeelings'), aiShareTrait: $('aiShareTrait'), aiShareRule: $('aiShareRule'),
    aiSituationSelect: $('aiSituationSelect'), aiContextPreview: $('aiContextPreview'), aiSampleProposalBtn: $('aiSampleProposalBtn'), aiGenerateBtn: $('aiGenerateBtn'),
    aiProviderStatus: $('aiProviderStatus'), aiProviderTitle: $('aiProviderTitle'), aiProviderText: $('aiProviderText'),
    aiProposalCard: $('aiProposalCard'), aiProposalType: $('aiProposalType'), aiProposalSource: $('aiProposalSource'), aiProposalText: $('aiProposalText'), aiProposalNote: $('aiProposalNote'),
    aiProposalAcceptBtn: $('aiProposalAcceptBtn'), aiProposalEditBtn: $('aiProposalEditBtn'), aiProposalRejectBtn: $('aiProposalRejectBtn'),
    aiConsentModal: $('aiConsentModal'), closeAiConsentBtn: $('closeAiConsentBtn'), cancelAiConsentBtn: $('cancelAiConsentBtn'),
    aiConsentCheck: $('aiConsentCheck'), confirmAiConsentBtn: $('confirmAiConsentBtn'),
    homePracticeRing: $('homePracticeRing'), homePracticeValue: $('homePracticeValue'),
    homeWeekCount: $('homeWeekCount'), homeReviewedCount: $('homeReviewedCount'), homeBetterCount: $('homeBetterCount'), homeRuleTestsCount: $('homeRuleTestsCount'),
    homeProgressStart: $('homeProgressStart'), homeProgressBetter: $('homeProgressBetter'), homeProgressRepeat: $('homeProgressRepeat'),
    homeResponseTrail: $('homeResponseTrail'), homeResponseTrailNote: $('homeResponseTrailNote'),
    inputs: {
      negativeTrait: $('negativeInput'), positiveTrait: $('positiveInput'), oldMindset: $('oldMindsetInput'),
      newMindset: $('newMindsetInput'), rule: $('ruleInput'), alternativeBehavior: $('alternativeInput'),
      preventionMethod: $('preventionInput'), harms: $('harmsInput')
    },
    quickModal: $('quickModal'), quickForm: $('quickForm'), closeQuickBtn: $('closeQuickBtn'), cancelQuickBtn: $('cancelQuickBtn'),
    quickWhatHappened: $('quickWhatHappened'), quickFeelings: $('quickFeelings'), quickUrge: $('quickUrge'), quickAction: $('quickAction'),
    quickTraitChips: $('quickTraitChips'), quickTraitInput: $('quickTraitInput'), quickTraitAdd: $('quickTraitAdd'), quickOptionalDetails: $('quickOptionalDetails'),
    postCaptureModal: $('postCaptureModal'), postCaptureLaterBtn: $('postCaptureLaterBtn'), analyzeNowBtn: $('analyzeNowBtn'),
    reviewModal: $('reviewModal'), reviewForm: $('reviewForm'), closeReviewBtn: $('closeReviewBtn'), reviewAutosave: $('reviewAutosave'),
    reviewPrevBtn: $('reviewPrevBtn'), reviewNextBtn: $('reviewNextBtn'), reviewFinishBtn: $('reviewFinishBtn'),
    reviewWhatHappened: $('reviewWhatHappened'), reviewTrigger: $('reviewTrigger'), reviewFeelings: $('reviewFeelings'),
    reviewInterpretation: $('reviewInterpretation'), reviewDeeperReflection: $('reviewDeeperReflection'), reviewUrge: $('reviewUrge'),
    reviewAction: $('reviewAction'), reviewConsequence: $('reviewConsequence'), reviewBetterResponse: $('reviewBetterResponse'),
    reviewPrevention: $('reviewPrevention'), reviewTraitChips: $('reviewTraitChips'), reviewTraitInput: $('reviewTraitInput'),
    reviewTraitAdd: $('reviewTraitAdd'), reviewNewRule: $('reviewNewRule'), reviewRuleSelect: $('reviewRuleSelect'),
    ruleTestResultWrap: $('ruleTestResultWrap'), ruleTestNoteWrap: $('ruleTestNoteWrap'), reviewRuleTestNote: $('reviewRuleTestNote')
  };

  const statusLabels = { focus: 'تحت التركيز', reinforcement: 'تثبيت', watch: 'مراقبة' };
  const responseLabels = {
    old: 'عدت للنمط القديم', late: 'انتبهت بعد الموقف', during: 'انتبهت أثناءه',
    stopped: 'أوقفت الاستجابة القديمة', alternative: 'طبقت البديل الجديد'
  };
  const ruleTestLabels = { success: 'نجحت', partial: 'نجحت جزئيًا', failed: 'لم تنجح' };

  function safeParse(raw) { try { return JSON.parse(raw); } catch { return null; } }


  function storageGet(key) { try { return localStorage.getItem(key); } catch { storageHealthy = false; return null; } }
  function storageSet(key, value) { try { localStorage.setItem(key, value); storageHealthy = true; return true; } catch { storageHealthy = false; return false; } }
  function storageRemove(key) { try { localStorage.removeItem(key); return true; } catch { storageHealthy = false; return false; } }


  function pushApiBase() {
    const raw = String(globalThis.TAZKIYAH_CONFIG?.pushApiBase || '').trim();
    return raw.replace(/\/+$/, '');
  }

  function aiApiBase() {
    const raw = String(globalThis.TAZKIYAH_CONFIG?.aiApiBase || '').trim();
    return raw.replace(/\/+$/, '');
  }

  function randomSecret(bytes = 24) {
    const data = new Uint8Array(bytes);
    crypto.getRandomValues(data);
    return Array.from(data, (b) => b.toString(16).padStart(2,'0')).join('');
  }

  function loadPushClient() {
    const parsed = safeParse(storageGet(PUSH_CLIENT_KEY));
    if (parsed?.clientId && parsed?.token) return parsed;
    const created = { clientId: crypto.randomUUID ? crypto.randomUUID() : `device-${Date.now()}-${randomSecret(8)}`, token: randomSecret(32) };
    storageSet(PUSH_CLIENT_KEY, JSON.stringify(created));
    return created;
  }

  function pushTimezone() {
    try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; }
  }

  function urlBase64ToUint8Array(value) {
    const padding = '='.repeat((4 - (value.length % 4)) % 4);
    const base64 = (value + padding).replace(/-/g, '+').replace(/_/g, '/');
    const raw = atob(base64);
    return Uint8Array.from(raw, (char) => char.charCodeAt(0));
  }

  async function pushRequest(path, { method='GET', body=null } = {}) {
    const base = pushApiBase();
    if (!base) throw new Error('PUSH_NOT_CONFIGURED');
    const client = loadPushClient();
    const response = await fetch(`${base}${path}`, {
      method,
      headers: {
        'content-type':'application/json',
        'x-tazkiyah-client-id':client.clientId,
        'x-tazkiyah-client-token':client.token
      },
      body: body == null ? undefined : JSON.stringify(body)
    });
    let payload = null;
    try { payload = await response.json(); } catch {}
    if (!response.ok) {
      const error = new Error(payload?.error || `PUSH_HTTP_${response.status}`);
      error.status = response.status;
      throw error;
    }
    return payload || {};
  }

  async function currentPushSubscription() {
    if (!('serviceWorker' in navigator)) return null;
    const registration = await navigator.serviceWorker.ready;
    if (!registration.pushManager) return null;
    return registration.pushManager.getSubscription();
  }

  async function refreshPushConnection() {
    if (!els.pushDeliveryStatus) return;
    const base = pushApiBase();
    if (!base) {
      pushRuntime = { state:'unconfigured', subscribed:false, message:'لم يتم وضع عنوان خدمة Push في config.js بعد.' };
      renderPushDeliveryStatus();
      return;
    }
    if (Notification.permission !== 'granted') {
      pushRuntime = { state:'permission', subscribed:false, message:'فعّل إذن الإشعارات أولًا.' };
      renderPushDeliveryStatus();
      return;
    }
    try {
      const subscription = await currentPushSubscription();
      if (!subscription) {
        pushRuntime = { state:'ready', subscribed:false, message:'الخدمة مربوطة ويمكن إنشاء اشتراك Push لهذا الجهاز.' };
      } else {
        pushRuntime = { state:'connected', subscribed:true, message:'هذا الجهاز مشترك في Web Push ويمكنه استقبال التذكير والتطبيق مغلق.' };
      }
    } catch {
      pushRuntime = { state:'error', subscribed:false, message:'تعذر فحص اشتراك Web Push الآن.' };
    }
    renderPushDeliveryStatus();
  }

  function renderPushDeliveryStatus() {
    if (!els.pushDeliveryStatus) return;
    els.pushDeliveryStatus.classList.remove('connected','warn','blocked');
    els.testPushNotificationBtn.hidden = true;
    els.disablePushBtn.hidden = true;
    if (pushRuntime.state === 'connected') {
      els.pushDeliveryTitle.textContent = 'Web Push متصل بهذا الجهاز';
      els.pushDeliveryText.textContent = pushRuntime.message;
      els.pushDeliveryStatus.classList.add('connected');
      els.testPushNotificationBtn.hidden = false;
      els.disablePushBtn.hidden = false;
      return;
    }
    if (pushRuntime.state === 'unconfigured') {
      els.pushDeliveryTitle.textContent = 'خدمة الإرسال جاهزة في الحزمة لكنها غير منشورة بعد';
      els.pushDeliveryText.textContent = 'سيبقى اختبار الإذن المحلي يعمل. بعد نشر push-server ووضع رابطه في config.js يصبح الإرسال المجدول فعالًا.';
      els.pushDeliveryStatus.classList.add('warn');
      return;
    }
    if (pushRuntime.state === 'error') {
      els.pushDeliveryTitle.textContent = 'تعذر الاتصال بخدمة Push';
      els.pushDeliveryText.textContent = pushRuntime.message;
      els.pushDeliveryStatus.classList.add('blocked');
      return;
    }
    els.pushDeliveryTitle.textContent = pushRuntime.subscribed ? 'Web Push متصل' : 'Web Push غير مشترك بعد';
    els.pushDeliveryText.textContent = pushRuntime.message || 'فعّل الإذن ثم اربط الجهاز بالخدمة.';
    els.pushDeliveryStatus.classList.add('warn');
  }

  async function ensurePushSubscription() {
    const base = pushApiBase();
    if (!base) { await refreshPushConnection(); return false; }
    if (Notification.permission !== 'granted') return false;
    const registration = await navigator.serviceWorker.ready;
    if (!registration.pushManager) throw new Error('PUSH_MANAGER_UNAVAILABLE');
    let subscription = await registration.pushManager.getSubscription();
    if (!subscription) {
      const { publicKey } = await pushRequest('/api/push/public-key');
      if (!publicKey) throw new Error('PUSH_PUBLIC_KEY_MISSING');
      subscription = await registration.pushManager.subscribe({ userVisibleOnly:true, applicationServerKey:urlBase64ToUint8Array(publicKey) });
    }
    await pushRequest('/api/push/subscribe', {
      method:'POST',
      body:{ subscription:subscription.toJSON(), timezone:pushTimezone(), preferences:loadNotificationPrefs() }
    });
    pushRuntime = { state:'connected', subscribed:true, message:'هذا الجهاز مشترك في Web Push ويمكنه استقبال التذكير والتطبيق مغلق.' };
    renderPushDeliveryStatus();
    return true;
  }

  async function syncPushPreferences() {
    const base = pushApiBase();
    if (!base || Notification.permission !== 'granted') return;
    const subscription = await currentPushSubscription();
    if (!subscription) return;
    await pushRequest('/api/push/preferences', { method:'PUT', body:{ timezone:pushTimezone(), preferences:loadNotificationPrefs() } });
  }

  function queuePushPreferencesSync() {
    clearTimeout(pushSyncTimer);
    pushSyncTimer = setTimeout(() => {
      syncPushPreferences().then(() => refreshPushConnection()).catch(() => {
        pushRuntime = { state:'error', subscribed:Boolean(pushRuntime.subscribed), message:'حُفظت الإعدادات على جهازك، لكن تعذر مزامنتها مع خدمة Push.' };
        renderPushDeliveryStatus();
      });
    }, 250);
  }

  async function sendExternalPushTest() {
    try {
      await ensurePushSubscription();
      await pushRequest('/api/push/test', { method:'POST', body:{} });
      showToast('أرسلنا اختبار Web Push من الخادم. يمكنك إغلاق التطبيق ورؤية وصوله.');
    } catch (error) {
      showToast(error.message === 'PUSH_NOT_CONFIGURED' ? 'خدمة Push لم تُنشر بعد.' : 'تعذر إرسال اختبار Web Push الخارجي.');
      await refreshPushConnection();
    }
  }

  async function disableExternalPush() {
    try {
      const subscription = await currentPushSubscription();
      if (pushApiBase()) await pushRequest('/api/push/subscription', { method:'DELETE', body:{} }).catch(() => {});
      if (subscription) await subscription.unsubscribe();
      pushRuntime = { state:'ready', subscribed:false, message:'تم إلغاء اشتراك Web Push على هذا الجهاز.' };
      renderPushDeliveryStatus();
      showToast('أوقفت الإشعارات الخارجية لهذا الجهاز.');
    } catch {
      showToast('تعذر إيقاف الاشتراك بالكامل. حاول مرة أخرى عند توفر الاتصال.');
    }
  }

  function notificationDefaults() { return JSON.parse(JSON.stringify(DEFAULT_NOTIFICATION_PREFS)); }
  function loadNotificationPrefs() {
    const parsed = safeParse(storageGet(NOTIFICATION_PREFS_KEY));
    const defaults = notificationDefaults();
    if (!parsed || typeof parsed !== 'object') return defaults;
    for (const key of ['rule','morning','evening','weekly']) {
      if (!parsed[key] || typeof parsed[key] !== 'object') continue;
      defaults[key] = { ...defaults[key], ...parsed[key], enabled: parsed[key].enabled === true };
    }
    return defaults;
  }
  function saveNotificationPrefs() {
    if (!els.notifyRuleEnabled) return;
    const prefs = {
      rule: { enabled:els.notifyRuleEnabled.checked, time:els.notifyRuleTime.value || '13:00' },
      morning: { enabled:els.notifyMorningEnabled.checked, time:els.notifyMorningTime.value || '08:00' },
      evening: { enabled:els.notifyEveningEnabled.checked, time:els.notifyEveningTime.value || '20:00' },
      weekly: { enabled:els.notifyWeeklyEnabled.checked, day:String(els.notifyWeeklyDay.value || '5'), time:els.notifyWeeklyTime.value || '19:00' }
    };
    storageSet(NOTIFICATION_PREFS_KEY, JSON.stringify(prefs));
    renderNotificationSettings();
    queuePushPreferencesSync();
  }

  function loadAiPrefs() {
    const parsed = safeParse(storageGet(AI_PREFS_KEY));
    return {
      ...DEFAULT_AI_PREFS,
      ...(parsed && typeof parsed === 'object' ? parsed : {}),
      enabled: parsed?.enabled === true && parsed?.consentVersion === AI_CONSENT_VERSION,
      shareFeelings: parsed?.shareFeelings === true,
      shareTrait: parsed?.shareTrait === true,
      shareRule: parsed?.shareRule === true
    };
  }

  function saveAiPrefs(next) {
    const merged = { ...loadAiPrefs(), ...next };
    storageSet(AI_PREFS_KEY, JSON.stringify(merged));
    return merged;
  }

  function loadAiProposals() {
    const parsed = safeParse(storageGet(AI_PROPOSALS_KEY));
    return Array.isArray(parsed) ? parsed.slice(-20) : [];
  }

  function saveAiProposal(proposal) {
    const list = loadAiProposals();
    const index = list.findIndex((item) => item.id === proposal.id);
    if (index >= 0) list[index] = proposal;
    else list.push(proposal);
    storageSet(AI_PROPOSALS_KEY, JSON.stringify(list.slice(-20)));
  }

  function latestRuleText() {
    const trait = activeTrait();
    if (trait?.rule) return trait.rule;
    const linked = state.rules.filter((rule) => rule.active !== false && (!trait || rule.linkedTraitId === trait.id));
    return linked[linked.length - 1]?.text || '';
  }

  const aiProposalTypeLabels = {
    reflection_question:'سؤال تأملي',
    alternative_interpretation:'تفسير بديل محتمل',
    better_response:'استجابة أفضل مقترحة',
    rule_draft:'مسودة قاعدة',
    pattern_hypothesis:'فرضية نمط'
  };

  function aiErrorMessage(code) {
    const map = {
      AI_PROVIDER_NOT_CONFIGURED:'خدمة AI موجودة لكن مفتاح المزود غير مهيأ على الخادم.',
      AI_RATE_LIMITED:'تم الوصول إلى حد الطلبات مؤقتًا. جرّب بعد قليل.',
      AI_TIMEOUT:'تأخر المزود أكثر من الحد المسموح. لم يتغير شيء في بياناتك.',
      AI_PROVIDER_FAILED:'تعذر الحصول على رد من مزود AI. التطبيق ما زال يعمل بدون AI.',
      AI_PROVIDER_EMPTY:'عاد المزود برد فارغ. لم يتغير شيء.',
      AI_PROVIDER_INVALID_JSON:'عاد المزود برد غير صالح. تم رفضه ولم يتغير شيء.',
      AI_PROVIDER_UNAVAILABLE:'تعذر الاتصال بمزود AI. لم يتغير شيء في بياناتك.',
      AI_PROVIDER_REFUSED:'لم يُنتج المزود اقتراحًا لهذا الموقف. لم يتغير شيء في بياناتك.',
      AI_PROVIDER_UNSAFE_OUTPUT:'تم رفض نتيجة AI لأنها خالفت حدود الأمان أو الخصوصية.',
      AI_PROVIDER_OVERCONFIDENT_OUTPUT:'تم رفض نتيجة AI لأنها صيغت كحقيقة مؤكدة بدل اقتراح محتمل.',
      INVALID_PROVIDER_OUTPUT:'تم رفض نتيجة AI لأنها لم تطابق البنية الآمنة.',
      ORIGIN_DENIED:'خدمة AI رفضت مصدر التطبيق الحالي.',
      ORIGIN_REQUIRED:'خدمة AI رفضت الطلب لأنه لم يصدر من التطبيق المسموح.',
      CONTENT_TYPE_REQUIRED:'تم رفض الطلب لأن صيغة الإرسال غير صحيحة.',
      BODY_TOO_LARGE:'السياق أكبر من الحد المسموح. قلّل النص ثم أعد المحاولة.'
    };
    return map[code] || 'تعذر تشغيل AI الآن. لم يتغير شيء في بيانات تزكية.';
  }

  async function aiRequest(path, { method='GET', body=null, timeoutMs=22000 } = {}) {
    const base = aiApiBase();
    if (!base) throw new Error('AI_NOT_CONFIGURED');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(`${base}${path}`, {
        method,
        headers:{ 'content-type':'application/json' },
        body:body == null ? undefined : JSON.stringify(body),
        signal:controller.signal
      });
      let payload = null;
      try { payload = await response.json(); } catch {}
      if (!response.ok) {
        const error = new Error(payload?.error || `AI_HTTP_${response.status}`);
        error.status = response.status;
        throw error;
      }
      return payload || {};
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error('AI_TIMEOUT');
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  function buildAiContext() {
    const prefs = loadAiPrefs();
    const situation = situationById(els.aiSituationSelect.value);
    if (!situation) return null;
    const context = { situation:String(situation.whatHappened || '').trim() };
    if (prefs.shareFeelings && situation.feelings) context.feelings = String(situation.feelings).trim();
    if (prefs.shareTrait) {
      const trait = activeTrait();
      if (trait) context.trait = traitDisplay(trait);
    }
    if (prefs.shareRule) {
      const rule = latestRuleText();
      if (rule) context.rule = rule;
    }
    return context.situation ? context : null;
  }

  function updateAiGenerateAvailability() {
    if (!els.aiGenerateBtn) return;
    const prefs = loadAiPrefs();
    const hasSituation = Boolean(els.aiSituationSelect?.value);
    els.aiGenerateBtn.disabled = !prefs.enabled || !aiApiBase() || !hasSituation || aiRuntime.state === 'generating';
  }

  function renderAiProviderStatus() {
    if (!els.aiProviderStatus) return;
    const base = aiApiBase();
    els.aiProviderStatus.classList.remove('ok','warn','error');
    if (!base) {
      els.aiProviderStatus.classList.add('warn');
      els.aiProviderTitle.textContent = 'خدمة AI غير مربوطة بعد';
      els.aiProviderText.textContent = 'ضع عنوان خدمة AI المنشورة في config.js. التطبيق يعمل طبيعيًا بدونها.';
    } else if (aiRuntime.state === 'ready') {
      els.aiProviderStatus.classList.add('ok');
      els.aiProviderTitle.textContent = aiRuntime.configured ? 'خدمة AI جاهزة' : 'الخادم يعمل لكن المزود غير مهيأ';
      els.aiProviderText.textContent = aiRuntime.configured
        ? `${aiRuntime.provider || 'AI'} · ${aiRuntime.model || 'النموذج المهيأ'} · المفتاح يبقى على الخادم.`
        : 'الخادم متصل، لكن يجب وضع مفتاح المزود في متغيرات البيئة على الخادم.';
    } else if (aiRuntime.state === 'checking') {
      els.aiProviderStatus.classList.add('warn');
      els.aiProviderTitle.textContent = 'جارٍ التحقق من خدمة AI…';
      els.aiProviderText.textContent = 'لا يُرسل أي موقف أثناء فحص الصحة.';
    } else if (aiRuntime.state === 'error') {
      els.aiProviderStatus.classList.add('error');
      els.aiProviderTitle.textContent = 'خدمة AI غير متاحة حاليًا';
      els.aiProviderText.textContent = aiRuntime.message || 'يمكنك متابعة استخدام التطبيق بدون AI.';
    } else {
      els.aiProviderStatus.classList.add('warn');
      els.aiProviderTitle.textContent = 'خدمة AI لم تُفحص بعد';
      els.aiProviderText.textContent = 'سيتم التحقق منها دون إرسال أي بيانات شخصية.';
    }
    updateAiGenerateAvailability();
  }

  async function refreshAiProviderStatus() {
    const base = aiApiBase();
    if (!base) {
      aiRuntime = { state:'unconfigured', configured:false, provider:'', model:'', message:'' };
      renderAiProviderStatus();
      return;
    }
    aiRuntime = { ...aiRuntime, state:'checking', message:'' };
    renderAiProviderStatus();
    try {
      const health = await aiRequest('/api/ai/health', { timeoutMs:7000 });
      aiRuntime = {
        state:'ready',
        configured:health.configured === true,
        provider:String(health.provider || ''),
        model:String(health.model || ''),
        message:''
      };
    } catch (error) {
      aiRuntime = { state:'error', configured:false, provider:'', model:'', message:aiErrorMessage(error.message) };
    }
    renderAiProviderStatus();
  }

  function renderAiContextPreview() {
    if (!els.aiContextPreview || !els.aiSituationSelect) return;
    const prefs = loadAiPrefs();
    const situation = situationById(els.aiSituationSelect.value);
    if (!situation) {
      els.aiContextPreview.innerHTML = '<span class="ai-empty">لم تختر موقفًا بعد. لا يوجد شيء جاهز للإرسال.</span>';
      updateAiGenerateAvailability();
      return;
    }
    const rows = [['الموقف', situation.whatHappened || '—']];
    if (prefs.shareFeelings) rows.push(['المشاعر', situation.feelings || 'لم تُسجل']);
    if (prefs.shareTrait) {
      const trait = activeTrait();
      rows.push(['صفة التركيز', trait ? traitDisplay(trait) : 'لا توجد صفة تركيز']);
    }
    if (prefs.shareRule) rows.push(['القاعدة الحالية', latestRuleText() || 'لا توجد قاعدة حالية']);
    els.aiContextPreview.innerHTML = rows.map(([label,value]) => `<div><small>${escapeHtml(label)}</small><span>${escapeHtml(truncate(value, 180))}</span></div>`).join('') +
      '<p>لن يُرسل باقي السجل أو المرايا أو النسخ الاحتياطية.</p>';
    updateAiGenerateAvailability();
  }

  function renderAiProposal() {
    if (!els.aiProposalCard) return;
    if (!currentAiProposal) {
      const last = loadAiProposals().slice().reverse()[0];
      currentAiProposal = last || null;
    }
    if (!currentAiProposal) {
      els.aiProposalCard.hidden = true;
      return;
    }
    els.aiProposalCard.hidden = false;
    els.aiProposalType.textContent = currentAiProposal.type || 'اقتراح تأملي';
    if (els.aiProposalSource) {
      els.aiProposalSource.textContent = currentAiProposal.source === 'external-ai'
        ? `${currentAiProposal.provider || 'AI'}${currentAiProposal.model ? ` · ${currentAiProposal.model}` : ''} · اقتراح فقط`
        : 'نموذج محلي · ليس AI';
    }
    els.aiProposalText.value = currentAiProposal.text || '';
    els.aiProposalText.readOnly = currentAiProposal.editing !== true;
    els.aiProposalEditBtn.textContent = currentAiProposal.editing ? 'حفظ التعديل' : 'تعديل';
    const statusMap = {
      accepted:'تم قبول الاقتراح محليًا. لم يُكتب شيء تلقائيًا في بيانات تزكية.',
      rejected:'تم رفض الاقتراح. لم يتغير شيء في بياناتك.',
      draft:currentAiProposal.note || 'هذا اقتراح يحتاج مراجعتك. لا يغيّر بياناتك تلقائيًا.'
    };
    els.aiProposalNote.textContent = statusMap[currentAiProposal.status] || statusMap.draft;
    els.aiProposalAcceptBtn.disabled = currentAiProposal.status === 'accepted';
    els.aiProposalRejectBtn.disabled = currentAiProposal.status === 'rejected';
  }

  function renderAiCenter() {
    if (!els.aiBadge) return;
    const prefs = loadAiPrefs();
    const base = aiApiBase();
    if (!prefs.enabled) els.aiBadge.textContent = 'مغلق';
    else if (base && aiRuntime.state === 'ready' && aiRuntime.configured) els.aiBadge.textContent = 'جاهز';
    else els.aiBadge.textContent = 'مفعّل';
    els.aiStatus.classList.toggle('ok', prefs.enabled);
    els.aiStatus.classList.toggle('warn', !prefs.enabled);
    els.aiStatusTitle.textContent = prefs.enabled ? 'موافقتك مفعّلة — أنت من يبدأ كل طلب' : 'الذكاء الاصطناعي مغلق افتراضيًا';
    els.aiStatusText.textContent = prefs.enabled
      ? 'يمكنك اختيار موقف، معاينة ما سيغادر الجهاز، ثم طلب اقتراح واحد. لا كتابة تلقائية في بياناتك.'
      : 'التطبيق كامل الاستخدام بدونه، ولا يرسل أي موقف إلى خدمة AI.';
    els.enableAiBtn.hidden = prefs.enabled;
    els.disableAiBtn.hidden = !prefs.enabled;
    els.aiPreferences.hidden = !prefs.enabled;
    els.aiShareFeelings.checked = prefs.shareFeelings;
    els.aiShareTrait.checked = prefs.shareTrait;
    els.aiShareRule.checked = prefs.shareRule;

    const currentValue = els.aiSituationSelect.value;
    const recent = state.situations.slice().sort((a,b) => new Date(b.updatedAt || b.createdAt) - new Date(a.updatedAt || a.createdAt)).slice(0, 30);
    els.aiSituationSelect.innerHTML = '<option value="">اختر موقفًا…</option>' + recent.map((s) =>
      `<option value="${escapeHtml(s.id)}">${escapeHtml(truncate(s.whatHappened || 'موقف بلا عنوان', 72))}</option>`
    ).join('');
    if (recent.some((s) => s.id === currentValue)) els.aiSituationSelect.value = currentValue;
    renderAiProviderStatus();
    renderAiContextPreview();
    renderAiProposal();
  }

  function openAiConsent() {
    els.aiConsentCheck.checked = false;
    els.confirmAiConsentBtn.disabled = true;
    els.aiConsentModal.hidden = false;
    lockBody();
  }

  function closeAiConsent() {
    els.aiConsentModal.hidden = true;
    unlockBody();
  }

  function confirmAiConsent() {
    if (!els.aiConsentCheck.checked) return;
    saveAiPrefs({ enabled:true, consentVersion:AI_CONSENT_VERSION, consentedAt:new Date().toISOString() });
    closeAiConsent();
    renderAiCenter();
    refreshAiProviderStatus().catch(() => {});
    showToast('تم تفعيل قسم AI. لن يُرسل شيء إلا عندما تطلب التحليل بنفسك.');
  }

  function disableAi() {
    saveAiPrefs({ enabled:false });
    renderAiCenter();
    showToast('تم إيقاف AI. بيانات تزكية الأساسية لم تتغير.');
  }

  function saveAiSharingPrefs() {
    saveAiPrefs({
      shareFeelings:els.aiShareFeelings.checked,
      shareTrait:els.aiShareTrait.checked,
      shareRule:els.aiShareRule.checked
    });
    renderAiContextPreview();
  }

  function createLocalAiProposalSample() {
    const situation = situationById(els.aiSituationSelect.value);
    currentAiProposal = {
      id: makeId('ai-proposal'),
      source:'local-ui-sample',
      type:'اقتراح تأملي',
      status:'draft',
      editing:false,
      createdAt:new Date().toISOString(),
      situationId:situation?.id || null,
      text:'قد يكون من المفيد قبل الحكم على الموقف أن تفرّق بين ما حدث فعلًا وبين التفسير الذي أضفته إليه.',
      note:'نموذج محلي لا يستخدم أي مزود AI.'
    };
    saveAiProposal(currentAiProposal);
    renderAiProposal();
  }

  async function requestAiProposal() {
    const prefs = loadAiPrefs();
    if (!prefs.enabled || prefs.consentVersion !== AI_CONSENT_VERSION) {
      showToast('راجع الخصوصية وفعّل AI أولًا.');
      return;
    }
    const context = buildAiContext();
    if (!context) {
      showToast('اختر موقفًا أولًا.');
      return;
    }
    if (!aiApiBase()) {
      showToast('خدمة AI لم تُنشر أو تُربط بعد.');
      return;
    }
    const original = els.aiGenerateBtn.textContent;
    aiRuntime = { ...aiRuntime, state:'generating' };
    els.aiGenerateBtn.textContent = 'جارٍ التحليل…';
    updateAiGenerateAvailability();
    try {
      const result = await aiRequest('/api/ai/proposal', { method:'POST', body:{ context }, timeoutMs:30000 });
      const proposal = result?.proposal;
      if (!proposal || proposal.needs_human_confirmation !== true || !proposal.proposal_text) throw new Error('INVALID_PROVIDER_OUTPUT');
      currentAiProposal = {
        id:makeId('ai-proposal'),
        source:'external-ai',
        provider:String(result.provider || 'AI'),
        model:String(result.model || ''),
        type:aiProposalTypeLabels[proposal.proposal_type] || 'اقتراح تأملي',
        proposalType:String(proposal.proposal_type || ''),
        status:'draft',
        editing:false,
        createdAt:new Date().toISOString(),
        situationId:els.aiSituationSelect.value,
        text:String(proposal.proposal_text).trim(),
        note:String(proposal.note || 'اقتراح يحتاج مراجعتك.').trim()
      };
      saveAiProposal(currentAiProposal);
      aiRuntime = { ...aiRuntime, state:'ready', configured:true, provider:String(result.provider || aiRuntime.provider || 'AI'), model:String(result.model || aiRuntime.model || '') };
      renderAiProposal();
      renderAiProviderStatus();
      showToast('وصل اقتراح AI. راجعه ثم اقبله أو عدّله أو ارفضه.');
    } catch (error) {
      aiRuntime = { ...aiRuntime, state:'error', message:aiErrorMessage(error.message) };
      renderAiProviderStatus();
      showToast(aiErrorMessage(error.message));
    } finally {
      els.aiGenerateBtn.textContent = original;
      if (aiRuntime.state === 'generating') aiRuntime = { ...aiRuntime, state:'ready' };
      updateAiGenerateAvailability();
    }
  }

  function toggleAiProposalEdit() {
    if (!currentAiProposal) return;
    if (currentAiProposal.editing) {
      currentAiProposal.text = els.aiProposalText.value.trim();
      currentAiProposal.editing = false;
      saveAiProposal(currentAiProposal);
      showToast('حُفظ تعديل الاقتراح محليًا.');
    } else {
      currentAiProposal.editing = true;
    }
    renderAiProposal();
    if (currentAiProposal.editing) els.aiProposalText.focus();
  }

  function setAiProposalStatus(status) {
    if (!currentAiProposal || !['accepted','rejected'].includes(status)) return;
    if (currentAiProposal.editing) currentAiProposal.text = els.aiProposalText.value.trim();
    currentAiProposal.editing = false;
    currentAiProposal.status = status;
    currentAiProposal.updatedAt = new Date().toISOString();
    saveAiProposal(currentAiProposal);
    renderAiProposal();
    showToast(status === 'accepted'
      ? 'تم قبول الاقتراح وحفظه كاقتراح منفصل فقط؛ لم نغيّر الموقف أو الصفة أو القاعدة.'
      : 'تم رفض الاقتراح؛ لم يتغير شيء في بياناتك.');
  }

  function loadState() {
    const raw = storageGet(STORAGE_KEY);
    if (!raw) return emptyState();
    const migrated = migrateState(safeParse(raw));
    if (!isValidState(migrated)) {
      storageSet(RECOVERY_KEY, raw);
      loadWarning = 'وجدت بيانات غير متوافقة؛ احتفظت بنسخة استرداد ولم أحذفها.';
      return emptyState();
    }
    if (migrated.schemaVersion !== safeParse(raw)?.schemaVersion) storageSet(STORAGE_KEY, JSON.stringify(migrated));
    return migrated;
  }

  function persistState({ quiet = false } = {}) {
    state.updatedAt = new Date().toISOString();
    const saved = storageSet(STORAGE_KEY, JSON.stringify(state));
    els.saveState.textContent = saved ? 'تم الحفظ على هذا الجهاز' : 'تعذر الحفظ — لا تغلق التطبيق قبل حل المشكلة';
    if (!saved && !quiet) showToast('تعذر حفظ البيانات على هذا الجهاز');
    return saved;
  }

  function makeId(prefix = 'item') {
    if (globalThis.crypto?.randomUUID) return crypto.randomUUID();
    return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  function activeTrait() { return state.traits.find((trait) => trait.id === state.activeTraitId) || null; }
  function situationById(id) { return state.situations.find((item) => item.id === id) || null; }
  function setText(element, value, fallback = '—') { element.textContent = String(value || '').trim() || fallback; }
  function escapeHtml(value = '') { return String(value).replace(/[&<>'"]/g, (char) => ({ '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;' }[char])); }
  function truncate(value, max = 120) { const text = String(value || '').trim(); return text.length > max ? `${text.slice(0, max - 1)}…` : text; }
  function formatDate(iso) {
    try { return new Intl.DateTimeFormat('ar', { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' }).format(new Date(iso)); }
    catch { return ''; }
  }

  function render() {
    renderOpeningReminder();
    renderHomeDashboard();
    renderFocus();
    renderTraitPath();
    renderRules();
    renderSituations();
    renderMirrors();
    renderNotificationSettings();
    renderAiCenter();
    applyView();
  }

  function reminderCandidates() {
    const trait = activeTrait();
    const candidates = [];
    if (trait?.rule) candidates.push({ text: trait.rule, source: 'قاعدتك الحالية', url: '' });
    if (trait?.newMindset) candidates.push({ text: trait.newMindset, source: 'العقلية التي تبنيها', url: '' });
    state.rules.filter((rule) => rule.active !== false).forEach((rule) => candidates.push({ text: rule.text, source: 'من قواعدك العملية', url: '' }));
    if (trait?.negativeTrait) {
      Content.references.filter((ref) => (ref.tags || []).includes(trait.negativeTrait)).forEach((ref) => candidates.push({ text: ref.text, source: ref.source, url: ref.url }));
    }
    if (!candidates.length) {
      candidates.push({ text: 'ابدأ بالملاحظة الصادقة، ثم افهم قبل أن تحكم على الموقف.', source: 'منهج التطبيق', url: '' });
    }
    return candidates;
  }

  function renderOpeningReminder(forceNext = false) {
    const traitId = activeTrait()?.id || 'none';
    const candidates = reminderCandidates();
    if (currentReminderKey !== traitId) { currentReminderKey = traitId; reminderCursor = Math.floor(Math.random() * candidates.length); }
    else if (forceNext) reminderCursor = (reminderCursor + 1) % candidates.length;
    const item = candidates[reminderCursor % candidates.length];
    setText(els.sessionReminderText, item.text);
    if (item.url) {
      els.sessionReminderSource.textContent = item.source;
      els.sessionReminderSource.href = item.url;
      els.sessionReminderSource.hidden = false;
    } else {
      els.sessionReminderSource.hidden = true;
      els.sessionReminderSource.removeAttribute('href');
    }
  }


  function renderHomeDashboard() {
    if (!els.homeWeekCount) return;
    const start = startOfCurrentWeek();
    const next = new Date(start); next.setDate(next.getDate() + 7);
    const situations = weekSituations();
    const stats = Core.summarizeSituations(situations);
    const weekRuleTests = state.ruleTests.filter((test) => {
      const when = new Date(test.updatedAt || test.createdAt || 0);
      return when >= start && when < next;
    });
    const progress = Core.progressSnapshot(situations, weekRuleTests);
    const response = progress.response;

    els.homeWeekCount.textContent = String(progress.evidence.total || 0);
    els.homeReviewedCount.textContent = String(progress.evidence.reviewed || 0);
    els.homeBetterCount.textContent = String(response.better || 0);
    els.homeRuleTestsCount.textContent = String(progress.rules.total || 0);
    els.homePracticeValue.textContent = response.betterRate === null ? '—' : `${response.betterRate}%`;
    els.homePracticeRing.style.setProperty('--practice-progress', `${(response.betterRate || 0) * 3.6}deg`);
    els.homePracticeRing.setAttribute('aria-label', response.betterRate === null
      ? (response.rated
          ? `سُجلت استجابة في ${response.rated} من المواقف المراجعة. نعرض النسبة بعد ${response.minimumForRate} مواقف مقيمة لتجنب دقة زائفة.`
          : 'لم تُقيّم الاستجابة في مواقف كافية هذا الأسبوع بعد.')
      : `ظهرت استجابة أفضل في ${response.betterRate} بالمئة من ${response.rated} مواقف تم تقييم الاستجابة فيها هذا الأسبوع.`);

    renderProgressGlance(stats, progress);
  }

  function renderProgressGlance(stats, progress) {
    if (!els.homeProgressStart) return;
    const trait = activeTrait();
    const response = progress.response;

    if (trait?.negativeTrait || trait?.positiveTrait) {
      const from = String(trait.negativeTrait || 'سلوك سابق').trim();
      const to = String(trait.positiveTrait || 'استجابة بديلة').trim();
      els.homeProgressStart.textContent = `${from} ← ${to}`;
    } else {
      els.homeProgressStart.textContent = 'حدّد صفة واحدة ليظهر مسارك هنا';
    }

    if (!response.rated) {
      els.homeProgressBetter.textContent = 'أكمل مراجعة وحدد ما حدث في الواقع';
    } else if (response.better > 0) {
      els.homeProgressBetter.textContent = `استجابة أفضل في ${response.better} من ${response.rated} مواقف مقيمة`;
    } else if (response.awareness > 0) {
      els.homeProgressBetter.textContent = `الانتباه بدأ يظهر في ${response.awareness} من ${response.rated} مواقف`;
    } else {
      els.homeProgressBetter.textContent = 'لدينا خط أساس الآن؛ لم تُسجل استجابة أفضل بعد';
    }

    const repeatedCandidates = [
      ...(stats.triggers || []).map((item) => ({ ...item, kind:'محفز' })),
      ...(stats.actions || []).map((item) => ({ ...item, kind:'تصرف' })),
      ...(stats.traits || []).map((item) => ({ ...item, kind:'صفة مرتبطة' }))
    ].sort((a,b) => b.count - a.count || a.label.localeCompare(b.label, 'ar'));
    const repeated = repeatedCandidates.find((item) => item.count >= 2);
    const firstSignal = repeatedCandidates[0];
    if (repeated) {
      els.homeProgressRepeat.textContent = `${repeated.kind}: ${truncate(repeated.label, 46)} · تكرر ${repeated.count} مرات`;
    } else if (firstSignal) {
      els.homeProgressRepeat.textContent = `ملاحظة أولية: ${truncate(firstSignal.label, 52)}`;
    } else {
      els.homeProgressRepeat.textContent = 'لا توجد بيانات كافية بعد لاستخراج تكرار';
    }

    const trail = [
      ['old','قديم'], ['late','بعده'], ['during','أثناءه'], ['stopped','أوقفت'], ['alternative','بديل']
    ];
    const maxCount = Math.max(1, ...trail.map(([key]) => Number(response[key] || 0)));
    els.homeResponseTrail.innerHTML = trail.map(([key,label]) => {
      const count = Number(response[key] || 0);
      const width = count ? Math.max(18, Math.round((count / maxCount) * 100)) : 0;
      return `<div class="response-trail-item">
        <div class="response-trail-label"><span>${escapeHtml(label)}</span><strong>${count}</strong></div>
        <div class="response-trail-track"><i class="response-trail-fill stage-${key}" style="width:${width}%"></i></div>
      </div>`;
    }).join('');
    els.homeResponseTrailNote.textContent = response.rated
      ? `${response.rated} ${response.rated === 1 ? 'موقف مقيم' : 'مواقف مقيمة'} · نعرض التوزيع لا الحكم`
      : 'يظهر بعد تقييم الاستجابة في المراجعات';
  }

  function openAdhkar(kind) {
    const items = Content.adhkar[kind] || [];
    els.adhkarModalTitle.textContent = kind === 'evening' ? 'أذكار المساء' : 'أذكار الصباح';
    els.adhkarList.innerHTML = items.map((item) => `<article class="dhikr-item"><div class="dhikr-head"><span>${item.repeat > 1 ? `${item.repeat} مرات` : 'مرة واحدة'}</span><a href="${escapeHtml(item.url)}" target="_blank" rel="noopener">${escapeHtml(item.source)} · ${escapeHtml(item.grade)}</a></div><p>${escapeHtml(item.text)}</p></article>`).join('');
    els.adhkarModal.hidden = false;
    lockBody();
  }

  function closeAdhkar() { els.adhkarModal.hidden = true; unlockBody(); }

  function exportBackup() {
    try {
      const backup = Core.makeBackup(state);
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type:'application/json' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `mirat-alnafs-backup-${localDateKey(new Date())}.json`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
      els.backupStatus.textContent = `تم تصدير نسخة: ${new Intl.DateTimeFormat('ar',{dateStyle:'medium',timeStyle:'short'}).format(new Date())}`;
      showToast('تم إنشاء النسخة الاحتياطية.');
    } catch (error) {
      showToast('تعذر إنشاء النسخة الاحتياطية.');
    }
  }

  async function importBackupFile(file) {
    if (!file) return;
    try {
      const text = await file.text();
      const imported = Core.readBackup(text);
      const okay = confirm('سيتم استبدال بيانات التطبيق الحالية بالنسخة المختارة. احتُفظ بنسخة استرداد من بياناتك الحالية. هل تريد المتابعة؟');
      if (!okay) { els.backupFileInput.value = ''; return; }
      storageSet(`${RECOVERY_KEY}:before-import:${Date.now()}`, JSON.stringify(state));
      state = imported;
      if (!persistState()) return;
      currentReminderKey = '';
      render();
      els.backupStatus.textContent = `تمت الاستعادة: ${new Intl.DateTimeFormat('ar',{dateStyle:'medium',timeStyle:'short'}).format(new Date())}`;
      showToast('تمت استعادة النسخة بنجاح.');
    } catch (error) {
      showToast('ملف النسخة غير صالح أو غير مدعوم.');
    } finally {
      els.backupFileInput.value = '';
    }
  }

  function renderFocus() {
    const trait = activeTrait();
    if (!trait) {
      ['negativeTrait','positiveTrait','oldMindset','newMindset','dailyRuleTitle','alternativeBehavior','preventionMethod','harmsText']
        .forEach((key) => setText(els[key], '—'));
      els.statusPill.textContent = 'ابدأ رحلتك';
      if (els.startFocusBtn) els.startFocusBtn.hidden = false;
      return;
    }
    if (els.startFocusBtn) els.startFocusBtn.hidden = true;
    setText(els.negativeTrait, trait.negativeTrait);
    setText(els.positiveTrait, trait.positiveTrait);
    setText(els.oldMindset, trait.oldMindset);
    setText(els.newMindset, trait.newMindset);
    setText(els.dailyRuleTitle, trait.rule);
    setText(els.alternativeBehavior, trait.alternativeBehavior);
    setText(els.preventionMethod, trait.preventionMethod);
    setText(els.harmsText, trait.harms);
    els.statusPill.textContent = statusLabels[trait.status] || 'تحت التركيز';
  }

  function traitDisplay(trait) {
    return `${trait.negativeTrait || '—'} ← ${trait.positiveTrait || '—'}`;
  }

  function renderTraitPath() {
    const groups = {
      focus: state.traits.filter((t) => t.status === 'focus'),
      reinforcement: state.traits.filter((t) => t.status === 'reinforcement'),
      watch: state.traits.filter((t) => t.status === 'watch')
    };
    const block = (label, key) => {
      const items = groups[key];
      const body = items.length ? items.map((t) => `<span class="path-trait">${escapeHtml(traitDisplay(t))}</span>`).join('') : '<span class="path-empty">لا يوجد</span>';
      return `<div class="path-column ${key}"><small>${label}</small><div>${body}</div></div>`;
    };
    els.traitPathSummary.innerHTML = block('التركيز', 'focus') + block('التثبيت', 'reinforcement') + block('المراقبة', 'watch');

    els.traitManagerList.innerHTML = state.traits.length ? state.traits.map((trait) => {
      let actions = '';
      if (trait.status === 'focus') actions = '<span class="manager-current">التركيز الحالي</span>';
      if (trait.status === 'reinforcement') actions = `<button class="small-btn" data-trait-action="focus" data-trait-id="${escapeHtml(trait.id)}">اجعله التركيز</button><button class="small-btn" data-trait-action="watch" data-trait-id="${escapeHtml(trait.id)}">إلى المراقبة</button>`;
      if (trait.status === 'watch') actions = `<button class="small-btn" data-trait-action="focus" data-trait-id="${escapeHtml(trait.id)}">اجعله التركيز</button><button class="small-btn" data-trait-action="reinforcement" data-trait-id="${escapeHtml(trait.id)}">إلى التثبيت</button>`;
      return `<article class="manager-item"><div><strong>${escapeHtml(traitDisplay(trait))}</strong><span>${escapeHtml(statusLabels[trait.status] || trait.status)}</span></div><div class="manager-actions">${actions}</div></article>`;
    }).join('') : emptyCard('لا توجد صفات بعد.', 'ابدأ بصفة واحدة تحت التركيز.');
  }

  function renderRules() {
    const rules = state.rules.filter((rule) => rule.active !== false).sort((a,b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    if (!rules.length) {
      els.rulesList.innerHTML = emptyCard('لا توجد قواعد عملية بعد.', 'استخرج قاعدة من موقف حقيقي أو أضف قاعدة تريد اختبارها.');
      return;
    }
    els.rulesList.innerHTML = rules.map((rule) => {
      const tests = state.ruleTests.filter((test) => test.ruleId === rule.id);
      const counts = { success:0, partial:0, failed:0 };
      tests.forEach((test) => { if (counts[test.result] !== undefined) counts[test.result] += 1; });
      const trait = state.traits.find((item) => item.id === rule.linkedTraitId);
      const summary = tests.length
        ? `<div class="rule-stats"><span>جُرّبت ${tests.length}</span><span>نجحت ${counts.success}</span><span>جزئيًا ${counts.partial}</span><span>لم تنجح ${counts.failed}</span></div>`
        : '<div class="rule-stats"><span>لم تُختبر بعد</span></div>';
      return `<article class="rule-item"><div class="rule-item-head"><div><strong>${escapeHtml(rule.text)}</strong>${trait ? `<small>${escapeHtml(traitDisplay(trait))}</small>` : ''}</div><button class="small-btn" data-rule-edit="${escapeHtml(rule.id)}">تعديل</button></div>${rule.reason ? `<p>${escapeHtml(rule.reason)}</p>` : ''}${summary}</article>`;
    }).join('');
  }

  function localDateKey(date) {
    const d = date instanceof Date ? date : new Date(date);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  function startOfCurrentWeek(now = new Date()) {
    const d = new Date(now);
    d.setHours(0,0,0,0);
    d.setDate(d.getDate() - d.getDay());
    return d;
  }

  function weekSituations(now = new Date()) {
    const start = startOfCurrentWeek(now);
    const end = new Date(start); end.setDate(end.getDate() + 7);
    return state.situations.filter((s) => {
      const d = new Date(s.createdAt);
      return d >= start && d < end;
    });
  }

  function periodSituations() {
    const value = els.patternPeriod?.value || '30';
    if (value === 'all') return state.situations.slice();
    const days = Number(value) || 30;
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);
    return state.situations.filter((s) => new Date(s.createdAt) >= cutoff);
  }

  function countRows(items, { limit = 5, emptyMessage = 'لا توجد بيانات مسجلة بعد.' } = {}) {
    const shown = items.slice(0, limit);
    if (!shown.length) return `<span class="mirror-empty">${escapeHtml(emptyMessage)}</span>`;
    return shown.map((item) => `<div class="count-row"><span title="${escapeHtml(item.label)}">${escapeHtml(item.label)}</span><strong>${item.count}</strong></div>`).join('');
  }

  function patternRows(items, { limit = 5, emptyMessage = 'لم تُسجّل هذه المعلومة بعد.' } = {}) {
    const shown = items.slice(0, limit);
    if (!shown.length) return `<span class="mirror-empty">${escapeHtml(emptyMessage)}</span>`;
    return shown.map((item) => {
      const repeated = item.count > 1;
      const status = repeated ? `متكرر ×${item.count}` : 'ملاحظة واحدة';
      const kind = repeated ? 'confirmed' : 'observed';
      return `<div class="count-row pattern-observation"><span title="${escapeHtml(item.label)}">${escapeHtml(item.label)}</span><strong class="pattern-status ${kind}">${status}</strong></div>`;
    }).join('');
  }

  function renderTodayMirror() {
    const today = localDateKey(new Date());
    const situations = state.situations.filter((s) => localDateKey(new Date(s.createdAt)) === today).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
    const stats = Core.summarizeSituations(situations);
    const better = (stats.responseStages.stopped || 0) + (stats.responseStages.alternative || 0);
    const needsAttention = (stats.responseStages.old || 0) + (stats.responseStages.late || 0);
    els.todaySummaryCards.innerHTML = [
      ['المواقف المسجلة', stats.total], ['راجعتها', stats.reviewed], ['تنتظر المراجعة', stats.pending],
      ['ظهرت استجابة أفضل', better], ['عاد النمط القديم/تأخر الانتباه', needsAttention]
    ].map(([label,value]) => `<div class="mirror-stat"><strong>${value}</strong><span>${label}</span></div>`).join('');
    els.todaySituations.innerHTML = situations.length ? situations.map((s) => {
      const reviewed = s.reviewStatus === 'reviewed';
      const stage = s.responseStage ? responseLabels[s.responseStage] : (reviewed ? 'مراجَع' : 'ينتظر المراجعة');
      const actionLabel = reviewed ? 'افتح المراجعة' : 'راجع الآن';
      return `<article class="mirror-event mirror-event-actionable">
        <div class="mirror-event-head"><strong>${escapeHtml(truncate(s.whatHappened, 120))}</strong><span>${escapeHtml(stage)}</span></div>
        <div class="mirror-event-footer"><small>${(s.linkedTraits || []).map(escapeHtml).join(' · ') || 'بدون تصنيف'}</small><button class="review-open-btn mirror-open-btn" data-review-id="${escapeHtml(s.id)}" type="button">${actionLabel}</button></div>
      </article>`;
    }).join('') : emptyCard('لا توجد مواقف مسجلة اليوم.', 'المرآة لا تخترع شيئًا عندما لا توجد بيانات.');
  }

  function renderPatternMirror() {
    const stats = Core.summarizeSituations(periodSituations());
    const periodLabel = els.patternPeriod?.selectedOptions?.[0]?.textContent || 'الفترة المختارة';
    if (els.patternCoverageNote) {
      if (!stats.total) {
        els.patternCoverageNote.textContent = `لا توجد مواقف في ${periodLabel}. عندما تسجل موقفًا سيظهر هنا فورًا، ولا نحوله إلى «نمط» إلا عند تكراره.`;
      } else if (stats.pending) {
        els.patternCoverageNote.textContent = `في ${periodLabel}: ${stats.total} موقف · ${stats.reviewed} مراجع · ${stats.pending} ينتظر المراجعة. الملاحظة تظهر من أول مرة، أما المحفز والتفسير والتصرف فيظهر ما دوّنته أثناء المراجعة.`;
      } else {
        els.patternCoverageNote.textContent = `في ${periodLabel}: ${stats.total} موقف · جميعها مراجعة. «ملاحظة واحدة» تعني أنها ظهرت مرة، و«متكرر» يعني أن العبارة نفسها تكررت دون دمج آلي لعبارات متشابهة.`;
      }
    }
    els.patternTraits.innerHTML = patternRows(stats.traits, { emptyMessage:'لم تربط صفة بأي موقف بعد.' });
    els.patternFeelings.innerHTML = patternRows(stats.feelings, { emptyMessage:'لم تسجل مشاعر بعد.' });
    els.patternTriggers.innerHTML = patternRows(stats.triggers, { emptyMessage: stats.reviewed ? 'لم تسجل محفزًا في المراجعات بعد.' : 'يظهر المحفز بعد مراجعة موقف واحد على الأقل.' });
    els.patternInterpretations.innerHTML = patternRows(stats.interpretations, { emptyMessage: stats.reviewed ? 'لم تسجل تفسيرًا في المراجعات بعد.' : 'يظهر التفسير بعد مراجعة موقف واحد على الأقل.' });
    els.patternActions.innerHTML = patternRows(stats.actions, { emptyMessage: stats.reviewed ? 'لم تسجل تصرفًا في المراجعات بعد.' : 'يظهر التصرف بعد مراجعة موقف واحد على الأقل.' });
    const stageEntries = Object.entries(responseLabels).map(([key,label]) => ({ label, count:stats.responseStages[key] || 0 })).filter((x) => x.count > 0);
    els.responseStageSummary.innerHTML = stageEntries.length ? stageEntries.map((item) => `<div class="count-row"><span>${escapeHtml(item.label)}</span><strong>${item.count}</strong></div>`).join('') : '<span class="mirror-empty">يظهر تغير الاستجابة عندما تكمل مراجعة وتحدد ما حدث في الواقع.</span>';
  }

  function currentRuleIdForMirror() {
    const trait = activeTrait();
    if (!trait) return null;
    const traitRule = normalizedRuleText(trait.rule);
    if (traitRule) {
      const exactLinked = state.rules.find((rule) =>
        rule.active !== false &&
        rule.linkedTraitId === trait.id &&
        normalizedRuleText(rule.text) === traitRule
      );
      if (exactLinked) return exactLinked.id;
      const exact = state.rules.find((rule) =>
        rule.active !== false &&
        normalizedRuleText(rule.text) === traitRule
      );
      if (exact) return exact.id;
    }
    return state.rules.find((rule) => rule.active !== false && rule.linkedTraitId === trait.id)?.id || null;
  }

  function ruleLatestResultLabel(result) {
    return result ? (ruleTestLabels[result] || result) : 'لم تُختبر بعد';
  }

  function renderRulesMirror() {
    const rules = state.rules.filter((rule) => rule.active !== false);
    if (!rules.length) {
      els.rulesMirrorList.innerHTML = emptyCard('لا توجد قواعد بعد.', 'عندما تستخرج قاعدة، ستظهر هنا مع نتائج اختبارها في الواقع.');
      return;
    }
    const currentRuleId = currentRuleIdForMirror();
    const ordered = rules.slice().sort((a, b) => {
      if (a.id === currentRuleId) return -1;
      if (b.id === currentRuleId) return 1;
      return new Date(b.updatedAt) - new Date(a.updatedAt);
    });
    els.rulesMirrorList.innerHTML = ordered.map((rule) => {
      const summary = Core.ruleSummary(state, rule.id);
      const isCurrent = rule.id === currentRuleId;
      const total = summary.total || 0;
      const latestResult = ruleLatestResultLabel(summary.latest?.result);
      const latestNote = summary.latest?.note ? `<p class="rule-latest-note"><span>آخر ملاحظة</span>${escapeHtml(summary.latest.note)}</p>` : '';
      const trait = state.traits.find((item) => item.id === rule.linkedTraitId);
      const relation = trait ? `<small class="rule-mirror-trait">${escapeHtml(traitDisplay(trait))}</small>` : '';
      return `<article class="rule-mirror-item${isCurrent ? ' current' : ''}">
        <div class="rule-mirror-head">
          <div><strong>${escapeHtml(rule.text)}</strong>${relation}</div>
          ${isCurrent ? '<span class="current-rule-badge">القاعدة الحالية</span>' : ''}
        </div>
        <div class="rule-mirror-quick">
          <div><small>مرات الاختبار</small><strong>${total}</strong></div>
          <div><small>آخر نتيجة</small><strong>${escapeHtml(latestResult)}</strong></div>
        </div>
        <div class="rule-result-breakdown" aria-label="نتائج اختبارات القاعدة">
          <span><b>${summary.success}</b> نجحت</span>
          <span><b>${summary.partial}</b> جزئيًا</span>
          <span><b>${summary.failed}</b> لم تنجح</span>
        </div>
        ${total ? latestNote : '<p class="rule-not-tested">لم تُختبر هذه القاعدة في موقف لاحق بعد.</p>'}
      </article>`;
    }).join('');
  }

  function currentWeekReview() {
    const key = localDateKey(startOfCurrentWeek());
    return state.weeklyReviews.find((item) => item.weekStart === key) || null;
  }

  function renderWeeklyMirror() {
    const start = startOfCurrentWeek();
    const end = new Date(start); end.setDate(end.getDate() + 6);
    const situations = weekSituations();
    const stats = Core.summarizeSituations(situations);
    const topTrait = stats.traits[0];
    const weekRuleTests = state.ruleTests.filter((test) => {
      const d = new Date(test.updatedAt || test.createdAt);
      const next = new Date(start); next.setDate(next.getDate()+7);
      return d >= start && d < next;
    });
    const progress = Core.progressSnapshot(situations, weekRuleTests);
    const response = progress.response;
    els.weekRangeLabel.textContent = `${new Intl.DateTimeFormat('ar',{day:'numeric',month:'short'}).format(start)} — ${new Intl.DateTimeFormat('ar',{day:'numeric',month:'short'}).format(end)}`;
    const reviewed = progress.evidence.reviewed || 0;
    const practiceLabel = response.betterRate === null ? '—' : `${response.betterRate}%`;
    const responseEvidence = response.rated
      ? `${response.better} من ${response.rated} مقيمة`
      : 'لم تُقيّم الاستجابة بعد';
    const responseNote = response.rated < response.minimumForRate
      ? `لدينا ${response.rated} ${response.rated === 1 ? 'موقف مقيم' : 'مواقف مقيمة'} فقط؛ نؤجل النسبة حتى ${response.minimumForRate} مواقف لتجنب دقة زائفة.`
      : `الانتباه أو الإيقاف أو البديل ظهر في ${response.awareness} من ${response.rated} مواقف مقيمة. هذه مؤشرات ممارسة وليست درجة أخلاقية.`;
    els.weekComputedSummary.innerHTML = `
      <div class="weekly-stat-grid">
        <article class="weekly-stat"><small>المواقف</small><strong>${progress.evidence.total}</strong><span>هذا الأسبوع</span></article>
        <article class="weekly-stat"><small>المراجعات</small><strong>${reviewed}</strong><span>${progress.evidence.pending || 0} تنتظر</span></article>
        <article class="weekly-stat"><small>استجابة أفضل</small><strong>${escapeHtml(practiceLabel)}</strong><span>${escapeHtml(responseEvidence)}</span></article>
        <article class="weekly-stat"><small>اختبار قاعدة</small><strong>${progress.rules.total}</strong><span>في الواقع</span></article>
      </div>
      <div class="weekly-insight">
        <span>أبرز صفة</span>
        <strong>${topTrait ? escapeHtml(topTrait.label) : 'لا توجد بيانات كافية'}</strong>
        <small>${topTrait ? `${topTrait.count} ارتباطات مسجلة` : 'ستظهر بعد تسجيل مواقف وربطها بالصفة'}</small>
      </div>
      <p class="weekly-evidence-note">${escapeHtml(responseNote)}</p>`;

    const review = currentWeekReview();
    els.weekRecurring.value = review?.recurringPattern || '';
    els.weekImprovements.value = review?.improvements || '';
    els.weekStruggles.value = review?.struggles || '';
    els.weekPrevention.value = review?.preventionReality || '';
    els.weekMindset.value = review?.mindsetShift || '';
    els.weekAdjustment.value = review?.nextAdjustment || '';
    els.weekNotes.value = review?.notes || '';
  }

  function renderMirrors() {
    renderTodayMirror();
    renderPatternMirror();
    renderRulesMirror();
    renderWeeklyMirror();
  }

  function applyView() {
    document.querySelectorAll('[data-view]').forEach((element) => {
      element.hidden = element.dataset.view !== currentView;
    });
    document.querySelectorAll('[data-nav-view]').forEach((button) => {
      button.classList.toggle('active', button.dataset.navView === currentView);
      button.setAttribute('aria-current', button.dataset.navView === currentView ? 'page' : 'false');
    });
  }

  function setView(view) {
    if (!['home','mirrors','path','ai'].includes(view)) return;
    currentView = view;
    if (view === 'mirrors') renderMirrors();
    if (view === 'path') { renderTraitPath(); renderRules(); }
    if (view === 'ai') { renderAiCenter(); refreshAiProviderStatus().catch(() => {}); }
    applyView();
    window.scrollTo({ top:0, behavior:'smooth' });
  }

  function saveWeeklyReview(event) {
    event.preventDefault();
    const existing = currentWeekReview();
    const review = Core.createWeeklyReview({
      id: existing?.id || makeId('week'),
      weekStart: localDateKey(startOfCurrentWeek()),
      recurringPattern: els.weekRecurring.value.trim(),
      improvements: els.weekImprovements.value.trim(),
      struggles: els.weekStruggles.value.trim(),
      preventionReality: els.weekPrevention.value.trim(),
      mindsetShift: els.weekMindset.value.trim(),
      nextAdjustment: els.weekAdjustment.value.trim(),
      notes: els.weekNotes.value.trim(),
      createdAt: existing?.createdAt || new Date().toISOString()
    });
    Core.upsertWeeklyReview(state, review);
    if (persistState()) {
      renderWeeklyMirror();
      showToast('تم حفظ المرآة الأسبوعية.');
    }
  }

  function renderSituations() {
    const pending = state.situations.filter((s) => s.reviewStatus !== 'reviewed').sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
    const reviewed = state.situations.filter((s) => s.reviewStatus === 'reviewed').sort((a,b) => new Date(b.reviewedAt || b.updatedAt) - new Date(a.reviewedAt || a.updatedAt)).slice(0, 4);
    els.pendingCount.textContent = String(pending.length);
    els.pendingList.innerHTML = pending.length ? pending.map((s) => situationCard(s, true)).join('') : emptyCard('لا يوجد شيء ينتظر المراجعة.', 'عندما يحدث موقف، سجّله بسرعة ثم عُد إليه بعد أن تهدأ.');
    els.recentList.innerHTML = reviewed.length ? reviewed.map((s) => situationCard(s, false)).join('') : emptyCard('لم تُنهِ مراجعة أي موقف بعد.', 'أول مراجعة حقيقية ستظهر هنا.');
  }

  function emptyCard(title, note) {
    return `<div class="empty-state"><strong>${escapeHtml(title)}</strong><span>${escapeHtml(note)}</span></div>`;
  }

  function situationCard(s, pending) {
    const tags = (s.linkedTraits || []).map((tag) => `<span class="mini-tag">${escapeHtml(tag)}</span>`).join('');
    const stage = !pending && s.responseStage ? `<span class="stage-badge">${escapeHtml(responseLabels[s.responseStage] || '')}</span>` : '';
    return `<article class="situation-item">
      <div class="situation-main">
        <div class="situation-meta"><span>${escapeHtml(formatDate(s.createdAt))}</span>${stage}</div>
        <p>${escapeHtml(truncate(s.whatHappened, 150))}</p>
        <div class="mini-tags">${tags}</div>
      </div>
      <button class="review-open-btn" data-review-id="${escapeHtml(s.id)}" type="button">${pending ? 'راجع الآن' : 'افتح المراجعة'}</button>
    </article>`;
  }

  function openFocusModal({ onboarding = false, newFocus = false } = {}) {
    focusMode = newFocus ? 'new' : 'edit';
    const trait = newFocus ? null : activeTrait();
    if (trait) Object.entries(els.inputs).forEach(([key, input]) => { input.value = trait[key] || ''; });
    else Object.values(els.inputs).forEach((input) => { input.value = ''; });
    els.focusModalKicker.textContent = newFocus ? 'انتقال منظم' : 'التركيز الحالي';
    els.focusModalTitle.textContent = newFocus ? 'ابدأ صفة جديدة للتركيز' : 'حدّد ما تريد بناءه';
    els.closeModalBtn.hidden = onboarding;
    els.cancelBtn.hidden = onboarding;
    els.focusModal.hidden = false;
    lockBody();
    setTimeout(() => els.inputs.negativeTrait.focus(), 0);
  }

  function closeFocusModal() { els.focusModal.hidden = true; unlockBody(); }

  function normalizedRuleText(value) {
    return String(value || '').trim().replace(/\s+/g, ' ').toLocaleLowerCase('ar');
  }

  function syncTraitPrimaryRule(trait, previousRuleText = '') {
    const text = String(trait?.rule || '').trim();
    if (!trait?.id || !text) return null;
    const now = trait.updatedAt || new Date().toISOString();
    const previousKey = normalizedRuleText(previousRuleText);
    const nextKey = normalizedRuleText(text);

    const previousLinked = previousKey
      ? state.rules.find((rule) =>
          rule.active !== false &&
          rule.linkedTraitId === trait.id &&
          normalizedRuleText(rule.text) === previousKey
        )
      : null;
    if (previousLinked) {
      previousLinked.text = text;
      previousLinked.updatedAt = now;
      return previousLinked;
    }

    const exactLinked = state.rules.find((rule) =>
      rule.active !== false &&
      rule.linkedTraitId === trait.id &&
      normalizedRuleText(rule.text) === nextKey
    );
    if (exactLinked) return exactLinked;

    const reusable = state.rules.find((rule) =>
      rule.active !== false &&
      !rule.linkedTraitId &&
      normalizedRuleText(rule.text) === nextKey
    );
    if (reusable) {
      reusable.linkedTraitId = trait.id;
      reusable.updatedAt = now;
      return reusable;
    }

    const created = Core.createRule({ text, linkedTraitId: trait.id }, makeId('rule'), now);
    Core.addRule(state, created);
    return created;
  }

  function handleFocusSubmit(event) {
    event.preventDefault();
    const values = Object.fromEntries(new FormData(els.focusForm).entries());
    const now = new Date().toISOString();
    const current = focusMode === 'edit' ? activeTrait() : null;
    const previousRuleText = current?.rule || '';
    const trait = {
      id: current?.id || makeId('trait'), negativeTrait: String(values.negativeTrait || '').trim(),
      positiveTrait: String(values.positiveTrait || '').trim(), status: current?.status || 'focus',
      oldMindset: String(values.oldMindset || '').trim(), newMindset: String(values.newMindset || '').trim(),
      harms: String(values.harms || '').trim(), alternativeBehavior: String(values.alternativeBehavior || '').trim(),
      preventionMethod: String(values.preventionMethod || '').trim(), rule: String(values.rule || '').trim(),
      createdAt: current?.createdAt || now, updatedAt: now
    };
    if (current) {
      state.traits = state.traits.map((item) => item.id === current.id ? trait : item);
    } else {
      state.traits.push(trait);
      Core.setFocusTrait(state, trait.id, now);
    }
    syncTraitPrimaryRule(trait, previousRuleText);
    if (persistState()) { render(); closeFocusModal(); showToast('تم حفظ تركيزك الحالي'); }
  }

  function openQuickModal() {
    els.quickForm.reset();
    quickTags = new Set();
    const focus = activeTrait();
    if (focus?.negativeTrait) quickTags.add(focus.negativeTrait);
    renderTagChips('quick');
    if (els.quickOptionalDetails) els.quickOptionalDetails.open = false;
    els.quickModal.hidden = false;
    lockBody();
    setTimeout(() => els.quickWhatHappened.focus(), 0);
  }

  function closeQuickModal() { els.quickModal.hidden = true; unlockBody(); }

  function openPostCaptureDecision(situationId) {
    postCaptureSituationId = situationId;
    els.postCaptureModal.hidden = false;
    lockBody();
    setTimeout(() => els.analyzeNowBtn.focus(), 0);
  }

  function closePostCaptureDecision({ notify = true } = {}) {
    els.postCaptureModal.hidden = true;
    postCaptureSituationId = null;
    unlockBody();
    if (notify) showToast('تم حفظ الموقف. ستجده في المرايا للمراجعة لاحقًا.');
  }

  function analyzePostCaptureNow() {
    const situationId = postCaptureSituationId;
    if (!situationId || !situationById(situationId)) {
      closePostCaptureDecision({ notify: false });
      showToast('تم حفظ الموقف، لكن تعذر فتح المراجعة الآن.');
      return;
    }
    els.postCaptureModal.hidden = true;
    postCaptureSituationId = null;
    unlockBody();
    openReview(situationId);
  }

  function handleQuickSubmit(event) {
    event.preventDefault();
    const whatHappened = els.quickWhatHappened.value.trim();
    if (!whatHappened) { els.quickWhatHappened.focus(); return; }
    const now = new Date().toISOString();
    const situation = Core.createSituation({
      whatHappened,
      feelings: els.quickFeelings.value.trim(),
      urge: els.quickUrge.value.trim(),
      action: els.quickAction.value.trim(),
      linkedTraits: Array.from(quickTags)
    }, makeId('situation'), now);
    Core.addSituation(state, situation);
    if (persistState()) {
      closeQuickModal();
      renderSituations();
      renderHomeDashboard();
      openPostCaptureDecision(situation.id);
    }
  }

  function traitSuggestions(extra = []) {
    const values = [];
    state.traits.forEach((trait) => { if (trait.negativeTrait) values.push(trait.negativeTrait); });
    state.situations.forEach((s) => (s.linkedTraits || []).forEach((tag) => values.push(tag)));
    extra.forEach((tag) => values.push(tag));
    return [...new Set(values.map((v) => String(v).trim()).filter(Boolean))];
  }

  function renderTagChips(kind) {
    const selected = kind === 'quick' ? quickTags : reviewTags;
    const container = kind === 'quick' ? els.quickTraitChips : els.reviewTraitChips;
    const choices = traitSuggestions([...selected]);
    if (!choices.length) {
      container.innerHTML = '<span class="field-help">أضف أول صفة مرتبطة بهذا الموقف.</span>';
      return;
    }
    container.innerHTML = choices.map((tag) => `<button type="button" class="tag-chip ${selected.has(tag) ? 'selected' : ''}" data-tag-kind="${kind}" data-tag="${escapeHtml(tag)}" aria-pressed="${selected.has(tag)}">${escapeHtml(tag)}</button>`).join('');
  }

  function toggleTag(kind, tag) {
    const target = kind === 'quick' ? quickTags : reviewTags;
    target.has(tag) ? target.delete(tag) : target.add(tag);
    renderTagChips(kind);
    if (kind === 'review') queueReviewAutosave();
  }

  function addCustomTag(kind) {
    const input = kind === 'quick' ? els.quickTraitInput : els.reviewTraitInput;
    const value = input.value.trim();
    if (!value) return;
    (kind === 'quick' ? quickTags : reviewTags).add(value);
    input.value = '';
    renderTagChips(kind);
    if (kind === 'review') queueReviewAutosave();
  }

  function openReview(id) {
    clearTimeout(autosaveTimer);
    const s = situationById(id);
    if (!s) return;
    currentReviewId = id;
    reviewStep = 1;
    reviewTags = new Set(s.linkedTraits || []);
    els.reviewWhatHappened.value = s.whatHappened || '';
    els.reviewTrigger.value = s.trigger || s.whatHappened || '';
    els.reviewFeelings.value = s.feelings || '';
    els.reviewInterpretation.value = s.interpretation || '';
    els.reviewDeeperReflection.value = s.deeperReflection || '';
    els.reviewUrge.value = s.urge || '';
    els.reviewAction.value = s.action || '';
    els.reviewConsequence.value = s.consequence || '';
    els.reviewBetterResponse.value = s.betterResponse || '';
    els.reviewPrevention.value = s.prevention || '';
    els.reviewNewRule.value = s.ruleCandidate || '';
    populateReviewRuleSelect();
    const draftTest = s.ruleTestDraft || state.ruleTests.find((test) => test.situationId === s.id) || null;
    els.reviewRuleSelect.value = draftTest?.ruleId || '';
    els.reviewForm.querySelectorAll('input[name="ruleTestResult"]').forEach((radio) => { radio.checked = radio.value === draftTest?.result; });
    els.reviewRuleTestNote.value = draftTest?.note || '';
    toggleRuleTestFields();
    els.reviewForm.querySelectorAll('input[name="responseStage"]').forEach((radio) => { radio.checked = radio.value === s.responseStage; });
    renderTagChips('review');
    els.reviewForm.querySelectorAll('.review-optional').forEach((details) => { details.open = false; });
    renderReviewStep();
    els.reviewAutosave.textContent = 'تُحفظ المسودة تلقائيًا على هذا الجهاز.';
    els.reviewModal.hidden = false;
    lockBody();
  }

  function closeReview() {
    clearTimeout(autosaveTimer);
    if (currentReviewId) snapshotReview(false, { quiet: true });
    els.reviewModal.hidden = true;
    currentReviewId = null;
    unlockBody();
    renderSituations();
    renderHomeDashboard();
  }

  function renderReviewStep() {
    els.reviewForm.querySelectorAll('.review-step').forEach((section) => { section.hidden = Number(section.dataset.step) !== reviewStep; });
    els.reviewModal.querySelectorAll('[data-dot]').forEach((dot) => dot.classList.toggle('active', Number(dot.dataset.dot) <= reviewStep));
    els.reviewPrevBtn.hidden = reviewStep === 1;
    els.reviewNextBtn.hidden = reviewStep === 3;
    els.reviewFinishBtn.hidden = reviewStep !== 3;
    if (reviewStep === 1) els.reviewNextBtn.textContent = 'التالي: كيف فهمته؟';
    if (reviewStep === 2) els.reviewNextBtn.textContent = 'التالي: ما البديل؟';
  }

  function selectedResponseStage() {
    return els.reviewForm.querySelector('input[name="responseStage"]:checked')?.value || null;
  }

  function snapshotReview(markReviewed = false, { quiet = true } = {}) {
    const s = situationById(currentReviewId);
    if (!s) return false;
    Object.assign(s, {
      whatHappened: els.reviewWhatHappened.value.trim(), trigger: els.reviewTrigger.value.trim(),
      feelings: els.reviewFeelings.value.trim(), interpretation: els.reviewInterpretation.value.trim(),
      deeperReflection: els.reviewDeeperReflection.value.trim(), urge: els.reviewUrge.value.trim(),
      action: els.reviewAction.value.trim(), consequence: els.reviewConsequence.value.trim(),
      betterResponse: els.reviewBetterResponse.value.trim(), prevention: els.reviewPrevention.value.trim(),
      linkedTraits: Array.from(reviewTags), responseStage: selectedResponseStage(),
      ruleCandidate: els.reviewNewRule.value.trim(),
      ruleTestDraft: els.reviewRuleSelect.value ? { ruleId: els.reviewRuleSelect.value, result: selectedRuleTestResult(), note: els.reviewRuleTestNote.value.trim() } : null,
      updatedAt: new Date().toISOString()
    });
    if (markReviewed) { s.reviewStatus = 'reviewed'; s.reviewedAt = new Date().toISOString(); }
    return persistState({ quiet });
  }

  function selectedRuleTestResult() {
    return els.reviewForm.querySelector('input[name="ruleTestResult"]:checked')?.value || '';
  }

  function populateReviewRuleSelect() {
    const current = els.reviewRuleSelect.value;
    const options = state.rules.filter((rule) => rule.active !== false).map((rule) => `<option value="${escapeHtml(rule.id)}">${escapeHtml(rule.text)}</option>`).join('');
    els.reviewRuleSelect.innerHTML = `<option value="">لم أختبر قاعدة سابقة</option>${options}`;
    if ([...els.reviewRuleSelect.options].some((option) => option.value === current)) els.reviewRuleSelect.value = current;
  }

  function toggleRuleTestFields() {
    const visible = Boolean(els.reviewRuleSelect.value);
    els.ruleTestResultWrap.hidden = !visible;
    els.ruleTestNoteWrap.hidden = !visible;
    if (!visible) {
      els.reviewForm.querySelectorAll('input[name="ruleTestResult"]').forEach((radio) => { radio.checked = false; });
      els.reviewRuleTestNote.value = '';
    }
  }

  function ensureRuleFromSituation(situation) {
    const text = String(situation.ruleCandidate || '').trim();
    if (!text) return null;
    const normalized = text.replace(/\s+/g, ' ').trim().toLocaleLowerCase('ar');
    let rule = state.rules.find((item) => String(item.text || '').replace(/\s+/g, ' ').trim().toLocaleLowerCase('ar') === normalized);
    if (rule) {
      if (!rule.sourceSituationIds.includes(situation.id)) rule.sourceSituationIds.push(situation.id);
      rule.updatedAt = new Date().toISOString();
      return rule;
    }
    const linkedTrait = state.traits.find((trait) => (situation.linkedTraits || []).includes(trait.negativeTrait)) || activeTrait();
    rule = Core.createRule({
      text,
      reason: 'مستخرجة من مراجعة موقف حقيقي',
      linkedTraitId: linkedTrait?.id || null,
      sourceSituationIds: [situation.id]
    }, makeId('rule'));
    Core.addRule(state, rule);
    return rule;
  }

  function applyRuleTestFromSituation(situation) {
    const draft = situation.ruleTestDraft;
    if (!draft?.ruleId || !draft?.result) return null;
    const test = Core.createRuleTest({
      ruleId: draft.ruleId,
      situationId: situation.id,
      result: draft.result,
      note: draft.note || ''
    }, makeId('rule-test'));
    return Core.upsertRuleTest(state, test);
  }

  function queueReviewAutosave() {
    if (!currentReviewId) return;
    els.reviewAutosave.textContent = 'جارٍ حفظ المسودة…';
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(() => {
      const saved = snapshotReview(false, { quiet: true });
      els.reviewAutosave.textContent = saved ? 'تم حفظ المسودة تلقائيًا.' : 'تعذر حفظ المسودة على هذا الجهاز.';
    }, 350);
  }

  function goReviewStep(delta) {
    snapshotReview(false, { quiet: true });
    reviewStep = Math.min(3, Math.max(1, reviewStep + delta));
    renderReviewStep();
    els.reviewModal.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function validateFinalReview() {
    const checks = [
      { el: els.reviewTrigger, step: 1, message: 'اكتب ما الذي حدث فعلًا قبل إنهاء المراجعة.' },
      { el: els.reviewInterpretation, step: 2, message: 'اكتب كيف فسرت الموقف.' },
      { el: els.reviewBetterResponse, step: 3, message: 'حدّد التصرف الأفضل للمرة القادمة.' }
    ];
    const missing = checks.find((item) => !item.el.value.trim());
    if (!missing) return true;
    reviewStep = missing.step;
    renderReviewStep();
    showToast(missing.message);
    setTimeout(() => missing.el.focus(), 0);
    return false;
  }

  function finishReview(event) {
    event.preventDefault();
    if (!validateFinalReview()) return;
    if (els.reviewRuleSelect.value && !selectedRuleTestResult()) {
      showToast('حدّد نتيجة اختبار القاعدة: نجحت، جزئيًا، أو لم تنجح.');
      reviewStep = 3;
      renderReviewStep();
      return;
    }
    if (snapshotReview(true, { quiet: true })) {
      const reviewed = situationById(currentReviewId);
      ensureRuleFromSituation(reviewed);
      applyRuleTestFromSituation(reviewed);
      const saved = persistState({ quiet: false });
      if (!saved) return;
      clearTimeout(autosaveTimer);
      els.reviewModal.hidden = true;
      currentReviewId = null;
      unlockBody();
      render();
      showToast('اكتملت المراجعة وحُفظت القواعد المرتبطة بها.');
    }
  }

  function openTraitManager() {
    renderTraitPath();
    els.traitManagerModal.hidden = false;
    lockBody();
  }

  function closeTraitManager() { els.traitManagerModal.hidden = true; unlockBody(); }

  function handleTraitAction(id, action) {
    try {
      if (action === 'focus') Core.setFocusTrait(state, id);
      else Core.setTraitStatus(state, id, action);
      if (persistState()) {
        render();
        showToast(action === 'focus' ? 'تم تغيير صفة التركيز، وانتقلت السابقة إلى التثبيت.' : 'تم تحديث حالة الصفة.');
      }
    } catch (error) {
      showToast('تعذر تحديث الصفة: ' + error.message);
    }
  }

  function fillRuleTraitSelect(selected = '') {
    const options = state.traits.map((trait) => `<option value="${escapeHtml(trait.id)}">${escapeHtml(traitDisplay(trait))}</option>`).join('');
    els.ruleTraitSelect.innerHTML = `<option value="">بدون ربط بصفة محددة</option>${options}`;
    els.ruleTraitSelect.value = selected || activeTrait()?.id || '';
  }

  function openRuleModal(id = null) {
    currentRuleId = id;
    const rule = id ? state.rules.find((item) => item.id === id) : null;
    els.ruleTextInput.value = rule?.text || '';
    els.ruleReasonInput.value = rule?.reason || '';
    fillRuleTraitSelect(rule?.linkedTraitId || '');
    $('ruleModalTitle').textContent = rule ? 'عدّل القاعدة العملية' : 'أضف قاعدة عملية';
    els.ruleModal.hidden = false;
    lockBody();
    setTimeout(() => els.ruleTextInput.focus(), 0);
  }

  function closeRuleModal() { els.ruleModal.hidden = true; currentRuleId = null; unlockBody(); }

  function handleRuleSubmit(event) {
    event.preventDefault();
    const text = els.ruleTextInput.value.trim();
    if (!text) return;
    const now = new Date().toISOString();
    if (currentRuleId) {
      const rule = state.rules.find((item) => item.id === currentRuleId);
      if (!rule) return;
      rule.text = text;
      rule.reason = els.ruleReasonInput.value.trim();
      rule.linkedTraitId = els.ruleTraitSelect.value || null;
      rule.updatedAt = now;
    } else {
      const duplicate = state.rules.find((item) => item.text.trim().toLocaleLowerCase('ar') === text.toLocaleLowerCase('ar'));
      if (duplicate) {
        showToast('هذه القاعدة موجودة بالفعل؛ يمكنك تعديلها بدل تكرارها.');
        return;
      }
      Core.addRule(state, Core.createRule({
        text,
        reason: els.ruleReasonInput.value.trim(),
        linkedTraitId: els.ruleTraitSelect.value || null
      }, makeId('rule'), now));
    }
    if (persistState()) {
      closeRuleModal();
      renderRules();
      showToast('تم حفظ القاعدة.');
    }
  }

  function showToast(message) {
    els.toast.textContent = message;
    els.toast.hidden = false;
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => { els.toast.hidden = true; }, 2400);
  }

  function isStandaloneApp() {
    return Boolean(window.matchMedia?.('(display-mode: standalone)').matches || window.navigator.standalone === true);
  }

  function notificationCapability() {
    const supported = 'Notification' in window && 'serviceWorker' in navigator && location.protocol !== 'file:';
    const permission = supported ? Notification.permission : 'unsupported';
    return { supported, permission, standalone:isStandaloneApp(), pushSupported:supported && 'PushManager' in window };
  }

  function renderNotificationSettings() {
    if (!els.notificationBadge) return;
    const prefs = loadNotificationPrefs();
    els.notifyRuleEnabled.checked = prefs.rule.enabled;
    els.notifyRuleTime.value = prefs.rule.time || '13:00';
    els.notifyMorningEnabled.checked = prefs.morning.enabled;
    els.notifyMorningTime.value = prefs.morning.time || '08:00';
    els.notifyEveningEnabled.checked = prefs.evening.enabled;
    els.notifyEveningTime.value = prefs.evening.time || '20:00';
    els.notifyWeeklyEnabled.checked = prefs.weekly.enabled;
    els.notifyWeeklyDay.value = String(prefs.weekly.day ?? '5');
    els.notifyWeeklyTime.value = prefs.weekly.time || '19:00';

    const cap = notificationCapability();
    els.notificationStatus.classList.remove('ok','warn','blocked');
    if (!cap.supported) {
      els.notificationBadge.textContent = 'غير مدعومة هنا';
      els.notificationStatusTitle.textContent = 'هذا الوضع لا يدعم إشعارات النظام';
      els.notificationStatusText.textContent = location.protocol === 'file:'
        ? 'افتح النسخة المنشورة عبر HTTPS لاختبار الإشعارات.'
        : 'يمكنك متابعة استخدام التذكيرات داخل التطبيق دون مشكلة.';
      els.notificationStatus.classList.add('blocked');
      els.enableNotificationsBtn.hidden = true;
      els.testNotificationBtn.hidden = true;
      return;
    }

    els.enableNotificationsBtn.hidden = cap.permission === 'granted' && pushRuntime.subscribed;
    els.testNotificationBtn.hidden = cap.permission !== 'granted';
    if (cap.permission === 'granted') {
      els.enableNotificationsBtn.disabled = false;
      els.enableNotificationsBtn.textContent = pushRuntime.subscribed ? 'Web Push متصل' : 'ربط Web Push';
      els.notificationBadge.textContent = 'الإذن مفعّل';
      els.notificationStatusTitle.textContent = 'إشعارات النظام مفعّلة على هذا الجهاز';
      els.notificationStatusText.textContent = cap.standalone
        ? 'إذن النظام مفعّل. حالة Web Push الحقيقية تظهر في البطاقة التالية.'
        : 'الإذن موجود. على iPhone افتح التطبيق من الشاشة الرئيسية كي يعمل Web Push عند اكتمال الربط.';
      els.notificationStatus.classList.add('ok');
      return;
    }

    if (cap.permission === 'denied') {
      els.notificationBadge.textContent = 'محظورة';
      els.notificationStatusTitle.textContent = 'تم رفض إذن الإشعارات';
      els.notificationStatusText.textContent = 'لن يعيد التطبيق إظهار طلب الإذن. غيّر الإذن من إعدادات النظام/المتصفح ثم عد إلى هنا.';
      els.notificationStatus.classList.add('blocked');
      els.enableNotificationsBtn.textContent = 'الإذن محظور';
      els.enableNotificationsBtn.disabled = true;
      return;
    }

    els.notificationBadge.textContent = 'غير مفعّلة';
    els.notificationStatusTitle.textContent = 'الإشعارات اختيارية بالكامل';
    els.notificationStatusText.textContent = cap.standalone
      ? 'اضغط «تفعيل الإشعارات» فقط إذا أردت تذكيرات خارج التطبيق.'
      : 'إن كنت على iPhone، ثبّت التطبيق على الشاشة الرئيسية وافتحه منها قبل التفعيل.';
    els.notificationStatus.classList.add('warn');
    els.enableNotificationsBtn.textContent = 'تفعيل الإشعارات';
    els.enableNotificationsBtn.disabled = false;
  }

  async function enableNotifications() {
    const cap = notificationCapability();
    if (!cap.supported) { showToast('الإشعارات غير مدعومة في هذا الوضع'); return; }
    if (!cap.standalone && /iPhone|iPad|iPod/i.test(navigator.userAgent || '')) {
      showToast('على iPhone افتح التطبيق من الشاشة الرئيسية أولًا، ثم فعّل الإشعارات.');
      renderNotificationSettings();
      return;
    }
    try {
      const permission = await Notification.requestPermission();
      renderNotificationSettings();
      if (permission === 'granted') {
        showToast('تم تفعيل إذن الإشعارات. نفحص Web Push الآن.');
        try { await ensurePushSubscription(); renderNotificationSettings(); } catch { await refreshPushConnection(); }
      } else if (permission === 'denied') showToast('تم رفض الإذن. يمكنك تغييره لاحقًا من إعدادات الجهاز.');
    } catch {
      showToast('تعذر طلب إذن الإشعارات على هذا الجهاز.');
    }
  }

  async function sendTestNotification() {
    const cap = notificationCapability();
    if (!cap.supported || cap.permission !== 'granted') { showToast('فعّل إذن الإشعارات أولًا'); return; }
    try {
      const registration = await navigator.serviceWorker.ready;
      await registration.showNotification('تزكية', {
        body: 'تم تفعيل الإشعارات بنجاح. لن نعرض تفاصيل شخصية حساسة افتراضيًا.',
        icon: 'icons/icon-192.png',
        badge: 'icons/favicon-32.png',
        tag: 'tazkiyah-test-notification',
        data: { url:'./?from=notification-test' }
      });
      showToast('أرسلنا إشعارًا تجريبيًا إلى جهازك.');
    } catch {
      showToast('تعذر إرسال الإشعار التجريبي. تأكد من فتح النسخة المنشورة كتطبيق.');
    }
  }

  function toggleWhy() {
    const expanded = els.whyToggle.getAttribute('aria-expanded') === 'true';
    els.whyToggle.setAttribute('aria-expanded', String(!expanded));
    els.whyPanel.hidden = expanded;
  }

  function lockBody() { document.body.style.overflow = 'hidden'; }
  function unlockBody() {
    if ([els.focusModal, els.quickModal, els.reviewModal, els.traitManagerModal, els.ruleModal, els.adhkarModal, els.aiConsentModal].some((modal) => modal && !modal.hidden)) return;
    document.body.style.overflow = '';
  }

  function handleDynamicClick(event) {
    const reviewButton = event.target.closest('[data-review-id]');
    if (reviewButton) { openReview(reviewButton.dataset.reviewId); return; }
    const tagButton = event.target.closest('[data-tag-kind][data-tag]');
    if (tagButton) { toggleTag(tagButton.dataset.tagKind, tagButton.dataset.tag); return; }
    const traitAction = event.target.closest('[data-trait-action][data-trait-id]');
    if (traitAction) { handleTraitAction(traitAction.dataset.traitId, traitAction.dataset.traitAction); return; }
    const ruleEdit = event.target.closest('[data-rule-edit]');
    if (ruleEdit) openRuleModal(ruleEdit.dataset.ruleEdit);
  }

  function bootstrap() {
    render();
    els.editFocusBtn.addEventListener('click', () => openFocusModal());
    if (els.startFocusBtn) els.startFocusBtn.addEventListener('click', () => openFocusModal({ newFocus: true }));
    els.closeModalBtn.addEventListener('click', closeFocusModal);
    els.cancelBtn.addEventListener('click', closeFocusModal);
    els.focusForm.addEventListener('submit', handleFocusSubmit);
    els.whyToggle.addEventListener('click', toggleWhy);
    els.newReminderBtn.addEventListener('click', () => renderOpeningReminder(true));
    els.morningAdhkarBtn.addEventListener('click', () => openAdhkar('morning'));
    els.eveningAdhkarBtn.addEventListener('click', () => openAdhkar('evening'));
    els.closeAdhkarBtn.addEventListener('click', closeAdhkar);
    els.exportBackupBtn.addEventListener('click', exportBackup);
    els.importBackupBtn.addEventListener('click', () => els.backupFileInput.click());
    els.backupFileInput.addEventListener('change', () => importBackupFile(els.backupFileInput.files?.[0]));
    els.enableNotificationsBtn.addEventListener('click', enableNotifications);
    els.testNotificationBtn.addEventListener('click', sendTestNotification);
    els.testPushNotificationBtn.addEventListener('click', sendExternalPushTest);
    els.disablePushBtn.addEventListener('click', disableExternalPush);
    [els.notifyRuleEnabled, els.notifyRuleTime, els.notifyMorningEnabled, els.notifyMorningTime, els.notifyEveningEnabled, els.notifyEveningTime, els.notifyWeeklyEnabled, els.notifyWeeklyDay, els.notifyWeeklyTime]
      .forEach((control) => control.addEventListener('change', saveNotificationPrefs));
    els.enableAiBtn.addEventListener('click', openAiConsent);
    els.disableAiBtn.addEventListener('click', disableAi);
    els.closeAiConsentBtn.addEventListener('click', closeAiConsent);
    els.cancelAiConsentBtn.addEventListener('click', closeAiConsent);
    els.aiConsentCheck.addEventListener('change', () => { els.confirmAiConsentBtn.disabled = !els.aiConsentCheck.checked; });
    els.confirmAiConsentBtn.addEventListener('click', confirmAiConsent);
    [els.aiShareFeelings, els.aiShareTrait, els.aiShareRule].forEach((control) => control.addEventListener('change', saveAiSharingPrefs));
    els.aiSituationSelect.addEventListener('change', renderAiContextPreview);
    els.aiSampleProposalBtn.addEventListener('click', createLocalAiProposalSample);
    els.aiGenerateBtn.addEventListener('click', requestAiProposal);
    els.aiProposalEditBtn.addEventListener('click', toggleAiProposalEdit);
    els.aiProposalAcceptBtn.addEventListener('click', () => setAiProposalStatus('accepted'));
    els.aiProposalRejectBtn.addEventListener('click', () => setAiProposalStatus('rejected'));
    els.manageTraitsBtn.addEventListener('click', openTraitManager);
    els.closeTraitManagerBtn.addEventListener('click', closeTraitManager);
    els.newFocusBtn.addEventListener('click', () => { closeTraitManager(); openFocusModal({ newFocus: true }); });
    els.addRuleBtn.addEventListener('click', () => openRuleModal());
    els.closeRuleBtn.addEventListener('click', closeRuleModal);
    els.cancelRuleBtn.addEventListener('click', closeRuleModal);
    els.ruleForm.addEventListener('submit', handleRuleSubmit);

    els.situationBtn.addEventListener('click', openQuickModal);
    els.closeQuickBtn.addEventListener('click', closeQuickModal);
    els.cancelQuickBtn.addEventListener('click', closeQuickModal);
    els.quickForm.addEventListener('submit', handleQuickSubmit);
    els.postCaptureLaterBtn.addEventListener('click', () => closePostCaptureDecision());
    els.analyzeNowBtn.addEventListener('click', analyzePostCaptureNow);
    els.quickTraitAdd.addEventListener('click', () => addCustomTag('quick'));
    els.quickTraitInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addCustomTag('quick'); } });

    els.closeReviewBtn.addEventListener('click', closeReview);
    els.reviewPrevBtn.addEventListener('click', () => goReviewStep(-1));
    els.reviewNextBtn.addEventListener('click', () => goReviewStep(1));
    els.reviewForm.addEventListener('submit', finishReview);
    els.reviewForm.addEventListener('input', queueReviewAutosave);
    els.reviewForm.addEventListener('change', queueReviewAutosave);
    els.reviewRuleSelect.addEventListener('change', () => { toggleRuleTestFields(); queueReviewAutosave(); });
    els.reviewTraitAdd.addEventListener('click', () => addCustomTag('review'));
    els.reviewTraitInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addCustomTag('review'); } });

    document.addEventListener('click', handleDynamicClick);
    [els.focusModal, els.quickModal, els.postCaptureModal, els.traitManagerModal, els.ruleModal, els.adhkarModal, els.aiConsentModal].forEach((modal) => modal.addEventListener('click', (event) => {
      if (event.target !== modal) return;
      if (modal === els.focusModal) closeFocusModal();
      if (modal === els.quickModal) closeQuickModal();
      if (modal === els.postCaptureModal) closePostCaptureDecision();
      if (modal === els.traitManagerModal) closeTraitManager();
      if (modal === els.ruleModal) closeRuleModal();
      if (modal === els.adhkarModal) closeAdhkar();
      if (modal === els.aiConsentModal) closeAiConsent();
    }));
    document.addEventListener('keydown', (event) => {
      if (event.key !== 'Escape') return;
      if (!els.aiConsentModal.hidden) closeAiConsent();
      else if (!els.reviewModal.hidden) closeReview();
      else if (!els.postCaptureModal.hidden) closePostCaptureDecision();
      else if (!els.adhkarModal.hidden) closeAdhkar();
      else if (!els.quickModal.hidden) closeQuickModal();
      else if (!els.ruleModal.hidden) closeRuleModal();
      else if (!els.traitManagerModal.hidden) closeTraitManager();
      else if (!els.focusModal.hidden) closeFocusModal();
    });
    document.querySelectorAll('[data-nav-view]').forEach((button) => button.addEventListener('click', () => setView(button.dataset.navView)));
    els.patternPeriod.addEventListener('change', renderPatternMirror);
    els.weeklyReviewForm.addEventListener('submit', saveWeeklyReview);

    if (!storageHealthy) els.saveState.textContent = 'التخزين المحلي غير متاح';
    if (loadWarning) showToast(loadWarning);
    refreshPushConnection().catch(() => {});
    refreshAiProviderStatus().catch(() => {});
    // لا نفتح نموذج إنشاء الصفة تلقائيًا عند أول دخول؛ المستخدم يبدأه من داخل التطبيق عندما يريد.
  }

  // واجهة اختبار غير مرئية للمستخدم للتحقق من الحفظ والترحيل والمواقف آليًا.
  window.TazkiyahApp = {
    storageKey: STORAGE_KEY,
    schemaVersion: SCHEMA_VERSION,
    getState: () => structuredClone(state),
    reset: () => { storageRemove(STORAGE_KEY); state = emptyState(); render(); },
    reloadFromStorage: () => { state = loadState(); render(); return structuredClone(state); },
    createSituation: (overrides = {}) => {
      const now = new Date().toISOString();
      const item = Core.createSituation({ whatHappened: 'موقف اختباري', ...overrides }, makeId('situation'), now);
      Core.addSituation(state, item); persistState({ quiet: true }); renderSituations(); renderHomeDashboard(); return structuredClone(item);
    },
    completeSituation: (id, overrides = {}) => {
      const item = Core.completeSituation(state, id, { trigger:'اختبار', interpretation:'تفسير', betterResponse:'بديل', ...overrides });
      if (!item) return null;
      persistState({ quiet: true }); renderSituations(); renderHomeDashboard(); return structuredClone(item);
    },
    addRule: (overrides = {}) => {
      const item = Core.createRule({ text:'قاعدة اختبارية', ...overrides }, makeId('rule'));
      Core.addRule(state, item); persistState({ quiet:true }); renderRules(); return structuredClone(item);
    },
    testRule: (ruleId, situationId, result = 'success', note = '') => {
      const item = Core.createRuleTest({ ruleId, situationId, result, note }, makeId('rule-test'));
      const saved = Core.upsertRuleTest(state, item); persistState({ quiet:true }); renderRules(); return structuredClone(saved);
    },
    setFocusTrait: (id) => { const item = Core.setFocusTrait(state, id); persistState({quiet:true}); render(); return item ? structuredClone(item) : null; },
    summarize: (ids = null) => Core.summarizeSituations(ids ? state.situations.filter((s) => ids.includes(s.id)) : state.situations),
    saveWeek: (overrides = {}) => {
      const existing = state.weeklyReviews.find((item) => item.weekStart === (overrides.weekStart || localDateKey(startOfCurrentWeek())));
      const item = Core.createWeeklyReview({ id: existing?.id || makeId('week'), weekStart: overrides.weekStart || localDateKey(startOfCurrentWeek()), ...overrides }, existing?.id || makeId('week'));
      const saved = Core.upsertWeeklyReview(state, item); persistState({quiet:true}); return structuredClone(saved);
    },
    getAiPrefs: () => structuredClone(loadAiPrefs()),
    getAiProposals: () => structuredClone(loadAiProposals()),
    getAiRuntime: () => structuredClone(aiRuntime),
    buildAiContext: () => structuredClone(buildAiContext()),
    makeBackup: () => Core.makeBackup(state),
    restoreBackup: (payload) => { state = Core.readBackup(payload); persistState({quiet:true}); render(); return structuredClone(state); }
  };

  bootstrap();
})();
