export const VALID_KINDS = ['rule','morning','evening','weekly'];

export function sanitizePreferences(input = {}) {
  const time = (value, fallback) => /^([01]\d|2[0-3]):[0-5]\d$/.test(String(value||'')) ? String(value) : fallback;
  const row = (key, fallback) => ({ enabled: input?.[key]?.enabled === true, time: time(input?.[key]?.time, fallback) });
  return {
    rule: row('rule','13:00'),
    morning: row('morning','08:00'),
    evening: row('evening','20:00'),
    weekly: { ...row('weekly','19:00'), day: /^[0-6]$/.test(String(input?.weekly?.day)) ? String(input.weekly.day) : '5' }
  };
}

export function localParts(date, timeZone) {
  const fmt = new Intl.DateTimeFormat('en-US', { timeZone, year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', hourCycle:'h23', weekday:'short' });
  const parts = Object.fromEntries(fmt.formatToParts(date).filter(p => p.type !== 'literal').map(p => [p.type,p.value]));
  const weekday = {Sun:'0',Mon:'1',Tue:'2',Wed:'3',Thu:'4',Fri:'5',Sat:'6'}[parts.weekday];
  return { date:`${parts.year}-${parts.month}-${parts.day}`, time:`${parts.hour}:${parts.minute}`, weekday };
}

export function dueReminders({ now = new Date(), timeZone = 'UTC', preferences = {} }) {
  let local;
  try { local = localParts(now, timeZone); } catch { return []; }
  const prefs = sanitizePreferences(preferences);
  const due = [];
  for (const kind of ['rule','morning','evening']) {
    if (prefs[kind].enabled && prefs[kind].time === local.time) due.push({ kind, slotKey:`${local.date}:${kind}:${local.time}` });
  }
  if (prefs.weekly.enabled && prefs.weekly.day === local.weekday && prefs.weekly.time === local.time) due.push({ kind:'weekly', slotKey:`${local.date}:weekly:${local.time}` });
  return due;
}

export function notificationPayload(kind) {
  const map = {
    rule: { title:'تزكية — تذكير لطيف', body:'افتح التطبيق وراجع قاعدتك الحالية.', url:'./?reminder=rule' },
    morning: { title:'تزكية — أذكار الصباح', body:'حان وقت أذكار الصباح.', url:'./?reminder=morning' },
    evening: { title:'تزكية — أذكار المساء', body:'حان وقت أذكار المساء.', url:'./?reminder=evening' },
    weekly: { title:'تزكية — مراجعة الأسبوع', body:'خصص دقائق لمراجعة أسبوعك.', url:'./?reminder=weekly' }
  };
  const item = map[kind] || { title:'تزكية', body:'لديك تذكير من تزكية.', url:'./?reminder=general' };
  return { ...item, tag:`tazkiyah-${kind || 'general'}` };
}
