# Tazkiyah Push Service — Part 6.3

خدمة صغيرة منفصلة عن بيانات التطبيق المحلية. تحفظ فقط Push subscription + timezone + تفضيلات المواعيد. لا تستقبل المواقف أو المرايا أو الصفات أو النصوص الشخصية.

## التشغيل
1. Node 22.16+.
2. `npm install`
3. `npm run generate-vapid` ثم ضع المفاتيح في متغيرات البيئة.
4. اضبط `TAZKIYAH_ALLOWED_ORIGIN` على أصل GitHub Pages، مثال: `https://mahdyramadan.github.io`.
5. استخدم قرصًا دائمًا للملف `TAZKIYAH_DB_PATH`.
6. شغّل `npm start` خلف HTTPS.
7. ضع رابط الخدمة HTTPS في `config.js` داخل `pushApiBase` ثم ارفع نسخة التطبيق.

## الخصوصية
الحمولات عامة فقط: تذكير قاعدة / أذكار صباح / أذكار مساء / مراجعة أسبوعية. لا تُرسل تفاصيل المواقف إلى الخادم أو شاشة القفل.

## الجدولة
الخادم يفحص التذكيرات كل 30 ثانية مع منع التكرار عبر `slot_key`. يمكن بدل ذلك استدعاء `POST /api/push/run-due` من cron خارجي مع `Authorization: Bearer <TAZKIYAH_CRON_SECRET>`.

## ملاحظة iPhone
Web Push يحتاج أن يكون الـPWA مضافًا إلى Home Screen وأن يمنح المستخدم الإذن من داخل التطبيق.
