import assert from 'node:assert/strict';
import { sanitizePreferences, dueReminders, notificationPayload } from './scheduler.mjs';
const prefs=sanitizePreferences({morning:{enabled:true,time:'08:00'},evening:{enabled:true,time:'20:00'},weekly:{enabled:true,day:'5',time:'19:00'},rule:{enabled:true,time:'13:00'}});
assert.equal(prefs.morning.time,'08:00'); assert.equal(sanitizePreferences({morning:{enabled:true,time:'99:99'}}).morning.time,'08:00');
const friday=new Date('2026-10-02T16:00:00Z'); // 19:00 Asia/Jerusalem (DST)
const due=dueReminders({now:friday,timeZone:'Asia/Jerusalem',preferences:prefs});
assert(due.some(x=>x.kind==='weekly'));
assert.equal(notificationPayload('rule').body.includes('قاعدتك'),true);
for(const kind of ['rule','morning','evening','weekly']){ const p=notificationPayload(kind); assert(!/موقف|غضب|استهزاء/.test(p.body)); }
console.log('push scheduler tests: PASS');
