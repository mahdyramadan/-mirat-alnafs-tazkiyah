import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import webpush from 'web-push';
import { dueReminders, notificationPayload, sanitizePreferences } from './scheduler.mjs';

const PORT = Number(process.env.PORT || 8788);
const ALLOWED_ORIGIN = String(process.env.TAZKIYAH_ALLOWED_ORIGIN || '').replace(/\/$/, '');
const DB_PATH = process.env.TAZKIYAH_DB_PATH || './data/tazkiyah-push.sqlite';
const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY || '';
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || '';
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || '';
const CRON_SECRET = process.env.TAZKIYAH_CRON_SECRET || '';
const SCHEDULER_ENABLED = String(process.env.PUSH_SCHEDULER_ENABLED || 'true') === 'true';
if (!ALLOWED_ORIGIN || !VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY || !VAPID_SUBJECT) throw new Error('Missing required push service environment variables');
webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
fs.mkdirSync(path.dirname(DB_PATH), { recursive:true });
const db = new DatabaseSync(DB_PATH);
db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;
CREATE TABLE IF NOT EXISTS subscriptions (
 client_id TEXT PRIMARY KEY, token_hash TEXT NOT NULL, endpoint TEXT NOT NULL, p256dh TEXT NOT NULL, auth TEXT NOT NULL,
 timezone TEXT NOT NULL, preferences_json TEXT NOT NULL, disabled INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS deliveries (
 client_id TEXT NOT NULL, kind TEXT NOT NULL, slot_key TEXT NOT NULL, sent_at TEXT NOT NULL, status TEXT NOT NULL,
 PRIMARY KEY(client_id, kind, slot_key)
);`);

const rates = new Map();
function rateAllowed(key, limit=40, windowMs=60_000) {
  const now=Date.now(); const current=rates.get(key);
  if (!current || now-current.start>windowMs) { rates.set(key,{start:now,count:1}); return true; }
  current.count += 1; return current.count <= limit;
}
function hash(value){ return crypto.createHash('sha256').update(String(value)).digest('hex'); }
function safeEqual(a,b){ const aa=Buffer.from(String(a)); const bb=Buffer.from(String(b)); return aa.length===bb.length && crypto.timingSafeEqual(aa,bb); }
function json(res,status,payload,origin){
  const headers={'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'};
  if(origin===ALLOWED_ORIGIN){ headers['access-control-allow-origin']=origin; headers['vary']='Origin'; }
  res.writeHead(status,headers); res.end(JSON.stringify(payload));
}
function cors(req,res){
  const origin=String(req.headers.origin||'');
  if(origin && origin!==ALLOWED_ORIGIN){ json(res,403,{error:'ORIGIN_DENIED'}); return false; }
  if(req.method==='OPTIONS'){
    res.writeHead(204,{'access-control-allow-origin':ALLOWED_ORIGIN,'access-control-allow-methods':'GET,POST,PUT,DELETE,OPTIONS','access-control-allow-headers':'content-type,x-tazkiyah-client-id,x-tazkiyah-client-token','access-control-max-age':'600','vary':'Origin'}); res.end(); return false;
  }
  return true;
}
async function body(req){
  let size=0, chunks=[];
  for await (const c of req){ size+=c.length; if(size>32_768) throw Object.assign(new Error('BODY_TOO_LARGE'),{status:413}); chunks.push(c); }
  if(!chunks.length) return {};
  try { const value=JSON.parse(Buffer.concat(chunks).toString('utf8')); if(!value || typeof value!=='object' || Array.isArray(value)) throw new Error(); return value; }
  catch { throw Object.assign(new Error('INVALID_JSON'),{status:400}); }
}
function credentials(req){ return {clientId:String(req.headers['x-tazkiyah-client-id']||''), token:String(req.headers['x-tazkiyah-client-token']||'')}; }
function validClientId(id){ return /^[A-Za-z0-9._:-]{8,128}$/.test(id); }
function rowFor(clientId){ return db.prepare('SELECT * FROM subscriptions WHERE client_id=?').get(clientId); }
function authorize(req){ const c=credentials(req); if(!validClientId(c.clientId)||c.token.length<32) return null; const row=rowFor(c.clientId); if(!row||!safeEqual(row.token_hash,hash(c.token))) return null; return {c,row}; }
function cleanSubscription(sub){
  if(!sub || typeof sub!=='object' || typeof sub.endpoint!=='string' || !sub.endpoint.startsWith('https://')) throw Object.assign(new Error('INVALID_SUBSCRIPTION'),{status:400});
  const p256dh=String(sub.keys?.p256dh||''), auth=String(sub.keys?.auth||'');
  if(!p256dh||!auth||sub.endpoint.length>4096||p256dh.length>512||auth.length>512) throw Object.assign(new Error('INVALID_SUBSCRIPTION'),{status:400});
  return {endpoint:sub.endpoint,p256dh,auth};
}
function cleanTimezone(zone){ const z=String(zone||'UTC'); try { new Intl.DateTimeFormat('en-US',{timeZone:z}).format(new Date()); return z.slice(0,100); } catch { return 'UTC'; } }
function webPushSubscription(row){ return {endpoint:row.endpoint, keys:{p256dh:row.p256dh,auth:row.auth}}; }
async function deliver(row,kind,slotKey){
  const inserted=db.prepare('INSERT OR IGNORE INTO deliveries(client_id,kind,slot_key,sent_at,status) VALUES(?,?,?,?,?)').run(row.client_id,kind,slotKey,new Date().toISOString(),'PENDING');
  if(!inserted.changes) return false;
  try {
    await webpush.sendNotification(webPushSubscription(row), JSON.stringify(notificationPayload(kind)), {TTL:300,urgency:'normal'});
    db.prepare('UPDATE deliveries SET status=? WHERE client_id=? AND kind=? AND slot_key=?').run('SENT',row.client_id,kind,slotKey); return true;
  } catch(error){
    const code=Number(error?.statusCode||0);
    db.prepare('UPDATE deliveries SET status=? WHERE client_id=? AND kind=? AND slot_key=?').run(`FAILED_${code||'ERR'}`,row.client_id,kind,slotKey);
    if(code===404||code===410) db.prepare('UPDATE subscriptions SET disabled=1,updated_at=? WHERE client_id=?').run(new Date().toISOString(),row.client_id);
    return false;
  }
}
async function runDue(now=new Date()){
  const rows=db.prepare('SELECT * FROM subscriptions WHERE disabled=0').all(); let due=0,sent=0;
  for(const row of rows){ let prefs={}; try{prefs=JSON.parse(row.preferences_json)}catch{}; for(const r of dueReminders({now,timeZone:row.timezone,preferences:prefs})){ due++; if(await deliver(row,r.kind,r.slotKey)) sent++; } }
  return {subscriptions:rows.length,due,sent};
}

const server=http.createServer(async(req,res)=>{
  const origin=String(req.headers.origin||''); if(!cors(req,res)) return;
  const ip=req.socket.remoteAddress||'unknown'; if(!rateAllowed(ip)){ json(res,429,{error:'RATE_LIMITED'},origin); return; }
  const u=new URL(req.url,'http://localhost');
  try{
    if(req.method==='GET'&&u.pathname==='/api/push/health'){ json(res,200,{ok:true,service:'tazkiyah-push'},origin); return; }
    if(req.method==='GET'&&u.pathname==='/api/push/public-key'){ json(res,200,{publicKey:VAPID_PUBLIC_KEY},origin); return; }
    if(req.method==='POST'&&u.pathname==='/api/push/subscribe'){
      const c=credentials(req); if(!validClientId(c.clientId)||c.token.length<32){json(res,400,{error:'INVALID_CLIENT'},origin);return;}
      const input=await body(req), sub=cleanSubscription(input.subscription), timezone=cleanTimezone(input.timezone), prefs=sanitizePreferences(input.preferences), existing=rowFor(c.clientId);
      if(existing&&!safeEqual(existing.token_hash,hash(c.token))){json(res,403,{error:'CLIENT_AUTH_FAILED'},origin);return;}
      const now=new Date().toISOString();
      db.prepare(`INSERT INTO subscriptions(client_id,token_hash,endpoint,p256dh,auth,timezone,preferences_json,disabled,created_at,updated_at)
       VALUES(?,?,?,?,?,?,?,0,?,?) ON CONFLICT(client_id) DO UPDATE SET endpoint=excluded.endpoint,p256dh=excluded.p256dh,auth=excluded.auth,timezone=excluded.timezone,preferences_json=excluded.preferences_json,disabled=0,updated_at=excluded.updated_at`)
       .run(c.clientId,hash(c.token),sub.endpoint,sub.p256dh,sub.auth,timezone,JSON.stringify(prefs),now,now);
      json(res,200,{ok:true},origin);return;
    }
    if(req.method==='PUT'&&u.pathname==='/api/push/preferences'){
      const auth=authorize(req); if(!auth){json(res,401,{error:'UNAUTHORIZED'},origin);return;} const input=await body(req);
      db.prepare('UPDATE subscriptions SET timezone=?,preferences_json=?,updated_at=? WHERE client_id=?').run(cleanTimezone(input.timezone),JSON.stringify(sanitizePreferences(input.preferences)),new Date().toISOString(),auth.c.clientId);
      json(res,200,{ok:true},origin);return;
    }
    if(req.method==='POST'&&u.pathname==='/api/push/test'){
      const auth=authorize(req); if(!auth){json(res,401,{error:'UNAUTHORIZED'},origin);return;}
      const slot=`test:${Date.now()}`; const sent=await deliver(auth.row,'general',slot); json(res,sent?200:502,{ok:sent},origin);return;
    }
    if(req.method==='DELETE'&&u.pathname==='/api/push/subscription'){
      const auth=authorize(req); if(!auth){json(res,401,{error:'UNAUTHORIZED'},origin);return;} db.prepare('UPDATE subscriptions SET disabled=1,updated_at=? WHERE client_id=?').run(new Date().toISOString(),auth.c.clientId); json(res,200,{ok:true},origin);return;
    }
    if(req.method==='POST'&&u.pathname==='/api/push/run-due'){
      if(!CRON_SECRET||!safeEqual(String(req.headers.authorization||''),`Bearer ${CRON_SECRET}`)){json(res,401,{error:'UNAUTHORIZED'},origin);return;} json(res,200,{ok:true,...await runDue()},origin);return;
    }
    json(res,404,{error:'NOT_FOUND'},origin);
  }catch(error){ json(res,error.status||500,{error:error.message||'INTERNAL_ERROR'},origin); }
});
server.listen(PORT,()=>console.log(`Tazkiyah push service listening on :${PORT}`));
if(SCHEDULER_ENABLED) setInterval(()=>runDue().catch(()=>{}),30_000).unref();
