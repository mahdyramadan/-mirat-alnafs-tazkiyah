# Tazkiyah AI Service — Part 7.3

Server-side boundary for the optional AI assistant.

## Guarantees
- The browser never receives the provider API key.
- Only the selected situation is required; feelings, current trait, and current rule are optional.
- No full history, mirrors, backups, adhkar, or unrelated local state is accepted by the provider endpoint.
- The service does not persist request text.
- Logs contain request id, status, error code, and duration only — never the situation text or provider response body.
- Provider output must match a strict proposal schema and always requires human confirmation.
- The AI cannot write to Tazkiyah core data; the browser stores proposals separately until the user accepts/edits/rejects them.
- The provider prompt forbids diagnosis, moral scoring, certainty about motives, and generated Qur'an/Hadith/fiqh content.

## Run
1. Copy `.env.example` values into your host's environment variables.
2. Set `TAZKIYAH_ALLOWED_ORIGIN` to the exact deployed PWA origin.
3. Set `OPENAI_API_KEY` only on the server.
4. Optionally change `TAZKIYAH_AI_MODEL`.
5. Run `npm test` then `npm start`.

## Endpoints
- `GET /api/ai/health` — reports configured/provider/model without exposing secrets.
- `POST /api/ai/proposal` — accepts `{ "context": { "situation", "feelings?", "trait?", "rule?" } }`.

The service uses the OpenAI Responses API with Structured Outputs, `store:false`, a strict JSON schema, and a bounded timeout.
