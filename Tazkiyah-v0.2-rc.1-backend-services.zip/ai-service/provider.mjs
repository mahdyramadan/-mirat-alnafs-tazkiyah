import { proposalJsonSchema, SYSTEM_INSTRUCTIONS, validateProposal } from './policy.mjs';

function providerError(code, status = 502) {
  return Object.assign(new Error(code), { status });
}

function collectOutputText(response) {
  if (typeof response?.output_text === 'string' && response.output_text.trim()) return response.output_text.trim();
  const parts = [];
  for (const item of response?.output || []) {
    for (const content of item?.content || []) {
      if (content?.type === 'refusal') throw providerError('AI_PROVIDER_REFUSED', 422);
      if (content?.type === 'output_text' && typeof content.text === 'string') parts.push(content.text);
    }
  }
  return parts.join('\n').trim();
}

export async function generateOpenAIProposal({ context, apiKey, model, timeoutMs = 25000, fetchImpl = fetch }) {
  if (!apiKey) throw Object.assign(new Error('AI_PROVIDER_NOT_CONFIGURED'), { status: 503 });
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    let response;
    try {
      response = await fetchImpl('https://api.openai.com/v1/responses', {
        method: 'POST',
        headers: {
          authorization: `Bearer ${apiKey}`,
          'content-type': 'application/json'
        },
        signal: controller.signal,
        body: JSON.stringify({
          model,
          store: false,
          instructions: SYSTEM_INSTRUCTIONS,
          input: [{
            role: 'user',
            content: [{ type: 'input_text', text: JSON.stringify({ task: 'اقترح مساعدة تأملية واحدة فقط', context }) }]
          }],
          text: {
            format: {
              type: 'json_schema',
              name: 'tazkiyah_proposal',
              description: 'اقتراح تأملي واحد، يحتاج تأكيد المستخدم دائمًا.',
              schema: proposalJsonSchema,
              strict: true
            }
          },
          max_output_tokens: 500
        })
      });
    } catch (error) {
      if (error?.name === 'AbortError') throw error;
      throw providerError('AI_PROVIDER_UNAVAILABLE', 502);
    }

    let payload = null;
    try { payload = await response.json(); } catch {}
    if (!response.ok) {
      if (response.status === 429) throw Object.assign(new Error('AI_RATE_LIMITED'), { status: 429 });
      throw providerError('AI_PROVIDER_FAILED', 502);
    }
    const rawText = collectOutputText(payload);
    if (!rawText) throw providerError('AI_PROVIDER_EMPTY', 502);
    let parsed;
    try { parsed = JSON.parse(rawText); } catch { throw providerError('AI_PROVIDER_INVALID_JSON', 502); }
    return { proposal: validateProposal(parsed), provider: 'openai', model, providerResponseId: String(payload?.id || '') };
  } catch (error) {
    if (error?.name === 'AbortError') throw Object.assign(new Error('AI_TIMEOUT'), { status: 504 });
    throw error;
  } finally {
    clearTimeout(timer);
  }
}
