import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';

const port = 18889;
const origin = 'https://example.test';
const child = spawn(process.execPath, ['server.mjs'], {
  cwd: new URL('.', import.meta.url),
  env: { ...process.env, PORT:String(port), TAZKIYAH_ALLOWED_ORIGIN:origin, OPENAI_API_KEY:'' },
  stdio:['ignore','pipe','pipe']
});

async function waitForServer() {
  const deadline = Date.now()+5000;
  while (Date.now()<deadline) {
    try { const r=await fetch(`http://127.0.0.1:${port}/api/ai/health`); if(r.ok) return; } catch {}
    await new Promise(r=>setTimeout(r,50));
  }
  throw new Error('server did not start');
}

try {
  await waitForServer();
  let r = await fetch(`http://127.0.0.1:${port}/api/ai/health`);
  assert.equal(r.status, 200);
  let j = await r.json();
  assert.equal(j.configured, false);

  r = await fetch(`http://127.0.0.1:${port}/api/ai/proposal`, {
    method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({context:{situation:'x'}})
  });
  assert.equal(r.status, 403);
  j = await r.json();
  assert.equal(j.error, 'ORIGIN_REQUIRED');

  r = await fetch(`http://127.0.0.1:${port}/api/ai/proposal`, {
    method:'POST', headers:{origin,'content-type':'text/plain'}, body:'{}'
  });
  assert.equal(r.status, 415);
  j = await r.json();
  assert.equal(j.error, 'CONTENT_TYPE_REQUIRED');

  r = await fetch(`http://127.0.0.1:${port}/api/ai/proposal`, {
    method:'POST', headers:{origin,'content-type':'application/json'}, body:JSON.stringify({context:{situation:'x'}})
  });
  assert.equal(r.status, 503);
  j = await r.json();
  assert.equal(j.error, 'AI_PROVIDER_NOT_CONFIGURED');
  assert.ok(j.requestId);

  r = await fetch(`http://127.0.0.1:${port}/api/ai/proposal`, {
    method:'POST', headers:{origin:'https://evil.test','content-type':'application/json'}, body:'{}'
  });
  assert.equal(r.status, 403);
  j = await r.json();
  assert.equal(j.error, 'ORIGIN_DENIED');

  console.log('AI HTTP boundary tests: PASS');
} finally {
  child.kill('SIGTERM');
}
