import http from 'node:http';
import crypto from 'node:crypto';
import { sanitizeContext } from './policy.mjs';
import { generateOpenAIProposal } from './provider.mjs';

const PORT = Number(process.env.PORT || 8789);
const ALLOWED_ORIGIN = String(process.env.TAZKIYAH_ALLOWED_ORIGIN || '').replace(/\/$/, '');
const PROVIDER = String(process.env.TAZKIYAH_AI_PROVIDER || 'openai').toLowerCase();
const MODEL = String(process.env.TAZKIYAH_AI_MODEL || 'gpt-5.6-luna');
const OPENAI_API_KEY = String(process.env.OPENAI_API_KEY || '');
const TIMEOUT_MS = Math.min(Math.max(Number(process.env.TAZKIYAH_AI_TIMEOUT_MS || 25000), 5000), 45000);
const RATE_LIMIT = Math.min(Math.max(Number(process.env.TAZKIYAH_AI_RATE_LIMIT_PER_MINUTE || 20), 1), 120);
const GLOBAL_RATE_LIMIT = Math.min(Math.max(Number(process.env.TAZKIYAH_AI_GLOBAL_RATE_LIMIT_PER_MINUTE || 60), 1), 600);
const NODE_ENV = String(process.env.NODE_ENV || 'development');

if (!ALLOWED_ORIGIN) throw new Error('TAZKIYAH_ALLOWED_ORIGIN is required');
if (PROVIDER !== 'openai') throw new Error('Unsupported TAZKIYAH_AI_PROVIDER');
if (NODE_ENV === 'production' && !ALLOWED_ORIGIN.startsWith('https://')) throw new Error('Production TAZKIYAH_ALLOWED_ORIGIN must use HTTPS');

const rates = new Map();
let globalRate = { start: Date.now(), count: 0 };
function rateAllowed(key) {
  const now = Date.now();
  if (now - globalRate.start > 60_000) globalRate = { start: now, count: 0 };
  globalRate.count += 1;
  if (globalRate.count > GLOBAL_RATE_LIMIT) return false;

  const current = rates.get(key);
  if (!current || now - current.start > 60_000) {
    rates.set(key, { start: now, count: 1 });
    return true;
  }
  current.count += 1;
  return current.count <= RATE_LIMIT;
}

function requestId() { return crypto.randomUUID(); }
function json(res, status, payload, origin = '') {
  const headers = {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'no-referrer',
    'cross-origin-resource-policy': 'same-site'
  };
  if (origin === ALLOWED_ORIGIN) {
    headers['access-control-allow-origin'] = origin;
    headers.vary = 'Origin';
  }
  res.writeHead(status, headers);
  res.end(JSON.stringify(payload));
}

function cors(req, res) {
  const origin = String(req.headers.origin || '');
  if (origin && origin !== ALLOWED_ORIGIN) {
    json(res, 403, { error: 'ORIGIN_DENIED' });
    return false;
  }
  if (req.method === 'OPTIONS') {
    if (origin !== ALLOWED_ORIGIN) {
      json(res, 403, { error: 'ORIGIN_DENIED' });
      return false;
    }
    res.writeHead(204, {
      'access-control-allow-origin': ALLOWED_ORIGIN,
      'access-control-allow-methods': 'GET,POST,OPTIONS',
      'access-control-allow-headers': 'content-type',
      'access-control-max-age': '600',
      vary: 'Origin'
    });
    res.end();
    return false;
  }
  return true;
}

function requireBrowserOrigin(req) {
  if (String(req.headers.origin || '') !== ALLOWED_ORIGIN) {
    throw Object.assign(new Error('ORIGIN_REQUIRED'), { status: 403 });
  }
}

function requireJson(req) {
  const type = String(req.headers['content-type'] || '').toLowerCase();
  if (!type.startsWith('application/json')) throw Object.assign(new Error('CONTENT_TYPE_REQUIRED'), { status: 415 });
}

async function body(req) {
  const declared = Number(req.headers['content-length'] || 0);
  if (Number.isFinite(declared) && declared > 12_288) throw Object.assign(new Error('BODY_TOO_LARGE'), { status: 413 });
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 12_288) throw Object.assign(new Error('BODY_TOO_LARGE'), { status: 413 });
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try {
    const value = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error();
    return value;
  } catch {
    throw Object.assign(new Error('INVALID_JSON'), { status: 400 });
  }
}

async function generate(context) {
  if (PROVIDER === 'openai') {
    return generateOpenAIProposal({ context, apiKey: OPENAI_API_KEY, model: MODEL, timeoutMs: TIMEOUT_MS });
  }
  throw Object.assign(new Error('AI_PROVIDER_NOT_CONFIGURED'), { status: 503 });
}

const server = http.createServer(async (req, res) => {
  const origin = String(req.headers.origin || '');
  if (!cors(req, res)) return;
  const id = requestId();
  const url = new URL(req.url, 'http://localhost');
  const started = Date.now();
  try {
    if (req.method === 'GET' && url.pathname === '/api/ai/health') {
      json(res, 200, { ok: true, service: 'tazkiyah-ai', configured: Boolean(OPENAI_API_KEY), provider: PROVIDER, model: MODEL }, origin);
      return;
    }
    if (req.method === 'POST' && url.pathname === '/api/ai/proposal') {
      requireBrowserOrigin(req);
      requireJson(req);
      const ip = req.socket.remoteAddress || 'unknown';
      if (!rateAllowed(ip)) {
        json(res, 429, { error: 'AI_RATE_LIMITED', requestId: id }, origin);
        return;
      }
      if (!OPENAI_API_KEY) {
        json(res, 503, { error: 'AI_PROVIDER_NOT_CONFIGURED', requestId: id }, origin);
        return;
      }
      const input = await body(req);
      const context = sanitizeContext(input.context);
      const result = await generate(context);
      json(res, 200, {
        ok: true,
        requestId: id,
        proposal: result.proposal,
        provider: result.provider,
        model: result.model
      }, origin);
      return;
    }
    json(res, 404, { error: 'NOT_FOUND', requestId: id }, origin);
  } catch (error) {
    const status = Number(error?.status || 500);
    const safeStatuses = new Set([400, 403, 413, 415, 422, 429, 502, 503, 504]);
    const safeCode = safeStatuses.has(status) ? String(error.message || 'AI_FAILED') : 'AI_FAILED';
    // Deliberately log no request body, situation text, feelings, trait, rule, or provider payload.
    console.error(JSON.stringify({ event: 'ai_request_failed', requestId: id, status, code: safeCode, durationMs: Date.now() - started }));
    json(res, status, { error: safeCode, requestId: id }, origin);
  }
});

server.listen(PORT, () => console.log(`Tazkiyah AI service listening on :${PORT}`));
